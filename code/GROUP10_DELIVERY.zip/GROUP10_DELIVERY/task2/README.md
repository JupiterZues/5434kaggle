# GROUP10 · COMP5434 Task 2 — Final Code and Reproduction Guide

This package contains the final Task 2 pipeline for Amazon review rating
prediction. The best Public RMSE is **0.46326**.

## Package contents

```text
README.md
code/                  final reproducible pipeline source
figures/               report-ready visualisations
metrics/               final metric manifest
submission/            final scored candidate and validation record
data/                  data acquisition and integrity instructions
```

## Environment

```bash
python -m pip install -r code/requirements.txt
sudo apt-get install -y openjdk-17-jre-headless
```

The main runtime used Python 3.12, PyTorch 2.12.1, Transformers 5.22.2,
Spark 4.0.1, and an NVIDIA RTX 4090.

## Data required

The archive does not redistribute course data, Amazon Reviews 2023, models, or
credentials. Expected paths are documented in `data/README.md`.

## Final reproduction sequence

1. Match train/test rows to the Amazon review source.
2. Replace matched training labels with source ratings.
3. Build leak-safe Spark relational features.
4. Fine-tune DeBERTa-v3-large on the 2M clean sample.
5. Predict the test set with the selected checkpoint.
6. Fit the cross-fitted side-feature stack.
7. Blend the six selected streams using nested simplex weights.
8. Apply bounded exact-star postprocessing.
9. Run submission validation.

The exact command sequence is available in `RUN_COMMANDS.md`. GROUP10 is
already set; replace member names, student IDs and contribution percentages
in the external report before submission.

The final Public RMSE is 0.46326. The six-stream
nested OOF values on identical rows are
0.46786 and
0.46811.

## External presentation files

Report and slides are not included in this delivery package; they live in the workspace root with the `TASK2_GROUP10_` prefix.
