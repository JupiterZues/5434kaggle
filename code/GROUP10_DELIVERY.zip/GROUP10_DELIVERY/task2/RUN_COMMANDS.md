# Task 2 reproduction commands

Run from the directory that contains this README. The commands assume data and
models are placed under `input/` and `models/pretrained/`.

## 1. Match all training and test rows to the public source

```bash
python code/match_amazon_source.py   --source input/external/amazon2023/Grocery_and_Gourmet_Food.jsonl   --target-csv input/train.csv   --output oof/source_match_full_train.csv   --report logs/source_match_full_train_report.json

python code/match_amazon_source.py   --source input/external/amazon2023/Grocery_and_Gourmet_Food.jsonl   --target-csv input/test.csv   --output oof/source_match_test.csv   --report logs/source_match_test_report.json
```

## 2. Construct the final 2M clean-label sample

The final r5 sample was derived from source-matched clean labels and stored as
`input/model_sample_source_2m.csv`. If rebuilding the sample, use the matching
and sampling scripts in `code/` and preserve the same clean-source and
validation-user exclusion rules.

## 3. Build distributed relational features with Spark

```bash
python code/spark_build_prior_features.py   --matched-train oof/source_match_full_train.csv   --sample input/model_sample_source_2m.csv   --test input/test.csv   --test-match oof/source_match_test.csv   --source-report logs/source_match_full_train_report.json   --output-dir oof/prior_features_rich2   --master 'local[4]'   --driver-memory 12g   --shuffle-partitions 64   --report logs/spark_prior_features.json
```

## 4. Fine-tune the final r5 DeBERTa-v3-large model

```bash
python code/train_transformer.py   --sample-csv input/model_sample_source_2m.csv   --sample-report logs/model_sample_source_report.json   --output-dir models/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5   --oof-dir oof   --log-dir logs   --model-name models/pretrained/deberta-v3-large   --max-length 192   --epochs 1   --train-batch-size 32   --eval-batch-size 64   --gradient-accumulation 2   --learning-rate 8e-6   --head-learning-rate 8e-4   --weight-decay 0.01   --warmup-ratio 0.05   --log-steps 200   --num-workers 8   --seed 13201   --eval-random-cap-per-class 2500   --eval-group-cap-per-class 3000   --max-train-per-class 0   --pooling-strategy mean   --pooling-dropout 0.1   --train-target-col rating   --class-weighting natural   --selection-metric natural   --text-window full   --save-every-steps 0
```

## 5. Predict the 10,000 test rows

```bash
python code/predict_transformer.py   --model-dir models/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5/best   --test input/test.csv   --sample-submission input/sampleSubmission.csv   --output submissions/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5_candidate.csv   --max-length 192   --batch-size 128   --num-workers 8   --bf16
```

## 6. Fit the side-feature stack

```bash
python code/stack_side_features.py   --random-oof oof/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5_epoch1_random.csv   --group-oof oof/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5_epoch1_group.csv   --random-features oof/prior_features_rich2/prior_features_val_random.csv   --group-features oof/prior_features_rich2/prior_features_val_group.csv   --test-features oof/prior_features_rich2/prior_features_test_with_source.csv   --metadata-features input/external/amazon2023/meta_features.csv   --test-base-prediction submissions/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5_candidate.csv   --output submissions/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5_side_candidate.csv   --oof-output oof/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5_side_oof.csv   --report logs/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5_side.json   --sample-report logs/model_sample_source_report.json
```

## 7. Rebuild the six-stream blend

Use the five original streams documented in the project logs and the new r5
side stream:

```bash
python code/audit_blend_streams.py   --stream old_side=oof/sourceclean_adv_864k_4model_side_oof.csv=submissions/sourceclean_adv_864k_4model_side_candidate.csv   --stream seed2m_side=oof/source2m_seedavg_4model_side_oof.csv=submissions/source2m_seedavg_4model_side_candidate.csv   --stream large1_side=oof/large_sourceclean_500k_4model_side_oof.csv=submissions/large_sourceclean_500k_4model_side_candidate.csv   --stream large2_side=oof/large_sourceclean_500k_r2_4model_side_oof.csv=submissions/large_sourceclean_500k_r2_4model_side_candidate.csv   --stream large3_len192=oof/large_sourceclean_500k_r3_len192_4model_side_oof.csv=submissions/large_sourceclean_500k_r3_len192_4model_side_candidate.csv   --stream large2m_r5=oof/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5_side_oof.csv=submissions/deberta_v3_large_sourceclean_2m_lr8e6_len192_r5_side_candidate.csv   --report logs/final_blend_audit.json   --output submissions/final_blend_candidate.csv
```

## 8. Apply bounded exact-star postprocessing and validate

```bash
python code/postprocess_exact_stars.py   --prediction submissions/final_blend_candidate.csv   --test input/test.csv   --sample-submission input/sampleSubmission.csv   --max-distance 1.0   --output submissions/final_candidate.csv   --report logs/final_star_postprocess.json

python code/validate_submission.py   --prediction submissions/final_candidate.csv   --sample-submission input/sampleSubmission.csv
```
