# Code map and implementation notes

The code is organized as a producer/consumer pipeline. Run the exact commands
from `RUN_COMMANDS.md` at the package root.

| File | Responsibility |
| --- | --- |
| `match_amazon_source.py` | Match each supplied row to Amazon Reviews 2023 by timestamp, title, and normalized text. |
| `build_source_clean_dataset.py` | Build the clean-label training table from source matches. |
| `augment_source_sample.py` | Create the reproducible clean-label sample used for transformer training. |
| `spark_build_prior_features.py` | Distributed Spark aggregation of user, product, parent-product, and temporal history. |
| `build_prior_features.py` | Local reference/feature utilities and validation checks. |
| `build_product_meta_features.py` | Product metadata side features. |
| `train_transformer.py` | Fine-tune the clean-label DeBERTa-v3-large model with BF16 and checkpointing. |
| `predict_transformer.py` | Batched test inference and submission-format output. |
| `stack_side_features.py` | Cross-fitted ridge, LightGBM, CatBoost, and XGBoost side-feature stack. |
| `audit_blend_streams.py` | Nested simplex blend audit and final six-stream candidate generation. |
| `postprocess_exact_stars.py` | Bounded exact-star title adjustment. |
| `validate_spark_features.py` | Guard checks for leaking validation IDs/users into aggregates. |
| `validate_submission.py` | Fail-fast row, ID, finite-value, range, and hash validation. |

## Reproducibility rules

- Raw course data and Amazon Reviews 2023 files are read-only inputs.
- Validation users and validation IDs are excluded before aggregate features
  are built.
- Side models are cross-fitted; blend weights are selected in nested folds.
- The source-label test proxy is diagnostic only and is not used for fitting
  or weight selection.
- The final candidate is not regenerated from a different checkpoint or seed
  without updating `metrics/final_metrics.json` and the submission record.

## Required course evidence

The report and slides include the hardware, Spark-based distributed processing,
training time per epoch, total offline time, test inference time, ablation
results, error analysis, risks, contribution table, and reproducibility notes.
