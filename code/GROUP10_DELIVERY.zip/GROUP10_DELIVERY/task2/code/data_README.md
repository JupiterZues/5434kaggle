Place input/ and external data under code/input/ or update paths in the commands. Course data, Amazon Reviews 2023, and model checkpoints are not redistributed.
