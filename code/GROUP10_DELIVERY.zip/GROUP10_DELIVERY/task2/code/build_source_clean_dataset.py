"""Replace noisy provided labels with matched public Amazon source labels."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--matched", required=True)
    parser.add_argument("--match-report", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    frame = pd.read_csv(args.matched)
    if "source_rating" not in frame:
        raise RuntimeError("Matched input is missing source_rating.")
    frame["rating_provided"] = frame["rating"].astype(np.float32)
    matched = frame["source_rating"].notna()
    frame.loc[matched, "rating"] = frame.loc[matched, "source_rating"].astype(
        np.float32
    )
    frame["rating_matched_to_source"] = matched

    match_report = json.loads(Path(args.match_report).read_text())
    source_counts = {
        int(rating): int(count)
        for rating, count in match_report["source"]["rating_counts"].items()
    }
    total_source = sum(source_counts.values())
    natural_prior = {
        rating: source_counts[rating] / total_source for rating in range(1, 6)
    }

    changes = frame.loc[matched, "rating_provided"].astype(float) - frame.loc[
        matched, "rating"
    ].astype(float)
    report: dict[str, object] = {
        "matched_input": args.matched,
        "output": args.output,
        "rows": int(len(frame)),
        "matched_rows": int(matched.sum()),
        "matched_share": float(matched.mean()),
        "changed_label_rows": int(np.sum(changes != 0)),
        "changed_label_share_of_matched": float(np.mean(changes != 0)),
        "provided_label_rmse_against_source": float(
            np.sqrt(np.mean(np.square(changes)))
        ),
        "source_rating_counts": {
            str(rating): count for rating, count in source_counts.items()
        },
        "source_rating_prior": {
            str(rating): prior for rating, prior in natural_prior.items()
        },
        "splits": {},
    }

    for split, group in frame.groupby("split"):
        split_matched = group["rating_matched_to_source"]
        split_report: dict[str, object] = {
            "rows": int(len(group)),
            "matched_rows": int(split_matched.sum()),
            "matched_share": float(split_matched.mean()),
            "rating_counts": {
                str(rating): int(count)
                for rating, count in group["rating"]
                .round()
                .astype(int)
                .value_counts()
                .sort_index()
                .items()
            },
        }
        split_changes = (
            group.loc[split_matched, "rating_provided"].astype(float)
            - group.loc[split_matched, "rating"].astype(float)
        )
        if len(split_changes):
            split_report["changed_label_rows"] = int(
                np.sum(split_changes != 0)
            )
            split_report["provided_label_rmse_against_source"] = float(
                np.sqrt(np.mean(np.square(split_changes)))
            )
        report["splits"][str(split)] = split_report

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output_path, index=False)
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
