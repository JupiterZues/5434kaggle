"""Shared competition paths and constants."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "input"
MODEL_DIR = ROOT / "models"
OOF_DIR = ROOT / "oof"
SUBMISSION_DIR = ROOT / "submissions"
LOG_DIR = ROOT / "logs"
CONFIG_DIR = ROOT / "configs"
KAGGLE_KERNEL_DIR = ROOT / "kaggle_kernels"
KAGGLE_DATASET_DIR = ROOT / "kaggle_datasets"
REMOTE_OUTPUT_DIR = ROOT / "remote_outputs"

SEED = 42
FOLD_COL = "fold"
TARGET_COL = "target"
ID_COL = "id"
