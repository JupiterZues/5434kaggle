"""Audit and cross-fit an OOF ensemble for Task 2.

The report deliberately separates model selection from test-label evidence.
Weights are selected with nested folds over validation rows, while the Amazon
source-rating proxy is reported only as a diagnostic and is never used to fit
or choose ensemble weights.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import lsq_linear, minimize
from sklearn.model_selection import StratifiedKFold


def natural_weights(labels: np.ndarray, prior: dict[int, float]) -> np.ndarray:
    """Reweight a class-balanced validation sample to the natural prior."""
    labels = np.asarray(labels, dtype=np.int64)
    counts = np.bincount(labels, minlength=6)[1:].astype(np.float64)
    shares = counts / counts.sum()
    mapping = np.asarray(
        [
            prior[rating] / share if share > 0.0 else 0.0
            for rating, share in enumerate(shares, start=1)
        ],
        dtype=np.float64,
    )
    mapping /= mapping.sum()
    return mapping[labels - 1]


def split_natural_weights(
    frame: pd.DataFrame,
    prior: dict[int, float],
) -> np.ndarray:
    """Rebalance each validation split independently to the natural prior."""
    labels = frame["rating"].to_numpy(dtype=np.int64)
    random_mask = frame["validation_split"].eq("val_random").to_numpy()
    output = np.ones(len(frame), dtype=np.float64)
    output[random_mask] = natural_weights(labels[random_mask], prior)
    output[~random_mask] = natural_weights(labels[~random_mask], prior)
    return output


def weighted_rmse(
    target: np.ndarray,
    prediction: np.ndarray,
    weights: np.ndarray,
) -> float:
    return float(
        np.sqrt(
            np.average(
                (np.clip(prediction, 1.0, 5.0) - target) ** 2,
                weights=weights,
            )
        )
    )


def split_scores(
    frame: pd.DataFrame,
    prediction: np.ndarray,
    weights: np.ndarray,
) -> dict[str, float]:
    target = frame["rating"].to_numpy(dtype=np.float64)
    random_mask = frame["validation_split"].eq("val_random").to_numpy()
    group_mask = ~random_mask
    random_score = weighted_rmse(
        target[random_mask], prediction[random_mask], weights[random_mask]
    )
    group_score = weighted_rmse(
        target[group_mask], prediction[group_mask], weights[group_mask]
    )
    return {
        "random": random_score,
        "group": group_score,
        "objective": (random_score + group_score) / 2.0,
        "combined": weighted_rmse(target, prediction, weights),
    }


def optimize_simplex(
    prediction: np.ndarray,
    target: np.ndarray,
    weights: np.ndarray,
    x0: np.ndarray | None = None,
) -> np.ndarray:
    count = prediction.shape[1]

    def objective(values: np.ndarray) -> float:
        return weighted_rmse(target, prediction @ values, weights)

    if x0 is None:
        x0 = np.full(count, 1.0 / count)
    result = minimize(
        objective,
        x0,
        method="SLSQP",
        bounds=[(0.0, 1.0)] * count,
        constraints={"type": "eq", "fun": lambda values: values.sum() - 1.0},
        options={"ftol": 1e-12, "maxiter": 2000},
    )
    if not result.success:
        raise RuntimeError(f"Simplex optimization failed: {result.message}")
    return result.x


def predict_nonnegative_affine(
    train_prediction: np.ndarray,
    train_target: np.ndarray,
    train_weights: np.ndarray,
    prediction: np.ndarray,
) -> tuple[np.ndarray, dict[str, object]]:
    """Fit nonnegative model weights plus an unconstrained intercept."""
    root_weights = np.sqrt(train_weights)
    design = np.column_stack([train_prediction, np.ones(len(train_prediction))])
    response = train_target
    lower = np.r_[np.zeros(train_prediction.shape[1]), -np.inf]
    upper = np.full(design.shape[1], np.inf)
    fit = lsq_linear(
        design * root_weights[:, None],
        response * root_weights,
        bounds=(lower, upper),
        lsmr_tol="auto",
        max_iter=1000,
    )
    parameters = fit.x
    output = np.clip(
        prediction @ parameters[:-1] + parameters[-1], 1.0, 5.0
    )
    metadata = {
        "model_weights": parameters[:-1].tolist(),
        "intercept": float(parameters[-1]),
        "optimizer_status": int(fit.status),
        "optimality": float(fit.optimality),
    }
    return output, metadata


def make_fold_ids(
    frame: pd.DataFrame,
    sample: pd.DataFrame,
    folds: int,
    seed: int,
) -> np.ndarray:
    """Use stratified random folds and user-grouped folds, then union them."""
    output = np.full(len(frame), -1, dtype=np.int16)
    random_mask = frame["validation_split"].eq("val_random").to_numpy()
    random_indices = np.flatnonzero(random_mask)
    labels = frame.loc[random_mask, "rating"].to_numpy(dtype=np.int64)
    splitter = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    for fold, (_, held_out) in enumerate(splitter.split(random_indices, labels)):
        output[random_indices[held_out]] = fold

    group_mask = ~random_mask
    group_indices = np.flatnonzero(group_mask)
    user_ids = (
        frame.loc[group_mask, "id"]
        .map(sample.set_index("id")["user_id"])
        .fillna("<MISSING>")
        .astype(str)
    )
    hashed = pd.util.hash_pandas_object(user_ids, index=False).to_numpy()
    output[group_indices] = (hashed % folds).astype(np.int16)
    if np.any(output < 0):
        raise RuntimeError("Some OOF rows did not receive a nested fold.")
    return output


def crossfit_metrics(
    frame: pd.DataFrame,
    prediction: np.ndarray,
    weights: np.ndarray,
    fold_ids: np.ndarray,
    folds: int,
) -> dict[str, object]:
    target = frame["rating"].to_numpy(dtype=np.float64)
    fold_scores: list[dict[str, float]] = []
    fold_weights: list[list[float]] = []
    for fold in range(folds):
        fit_mask = fold_ids != fold
        eval_mask = ~fit_mask
        blend_weights = optimize_simplex(
            prediction[fit_mask], target[fit_mask], weights[fit_mask]
        )
        fold_prediction = prediction[eval_mask] @ blend_weights
        scores = split_scores(
            frame.loc[eval_mask].reset_index(drop=True),
            fold_prediction,
            weights[eval_mask],
        )
        fold_scores.append(scores)
        fold_weights.append(blend_weights.tolist())

    values = np.asarray(
        [[score["objective"] for score in fold_scores]], dtype=np.float64
    ).ravel()
    weights_array = np.asarray(fold_weights)
    return {
        "fold_scores": fold_scores,
        "objective_mean": float(values.mean()),
        "objective_std": float(values.std(ddof=1)),
        "weight_mean": weights_array.mean(axis=0).tolist(),
        "weight_std": weights_array.std(axis=0, ddof=1).tolist(),
        "weight_min": weights_array.min(axis=0).tolist(),
        "weight_max": weights_array.max(axis=0).tolist(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--stream",
        action="append",
        required=True,
        help="name=oof_csv=test_prediction_csv",
    )
    parser.add_argument(
        "--sample",
        default="input/model_sample_200k_per_class.csv",
    )
    parser.add_argument(
        "--sample-report",
        default="logs/model_sample_source_report.json",
    )
    parser.add_argument(
        "--test-proxy",
        default="oof/source_match_test.csv",
        help="Diagnostic source-rating test proxy; never used for fitting.",
    )
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20261112)
    parser.add_argument("--report", required=True)
    parser.add_argument(
        "--output",
        help="Optional candidate CSV. Omit to run an audit with no submission.",
    )
    args = parser.parse_args()

    sample = pd.read_csv(
        args.sample,
        usecols=["id", "user_id", "rating", "split"],
    )
    split_lookup = sample.set_index("id")["split"]
    report = json.loads(Path(args.sample_report).read_text())
    source_counts = {
        int(rating): int(count)
        for rating, count in report["source_rating_counts"].items()
    }
    total_source = sum(source_counts.values())
    prior = {
        rating: source_counts[rating] / total_source for rating in range(1, 6)
    }

    names: list[str] = []
    oof_frames: list[pd.DataFrame] = []
    test_frames: list[pd.DataFrame] = []
    clean_labels: pd.DataFrame | None = None
    for stream_index, specification in enumerate(args.stream):
        name, oof_path, test_path = specification.split("=", 2)
        names.append(name)
        oof = pd.read_csv(oof_path, usecols=["id", "rating", "prediction"])
        if stream_index == 0:
            clean_labels = oof[["id", "rating"]].copy()
        oof_frames.append(
            oof[["id", "prediction"]].rename(columns={"prediction": name})
        )
        test_frames.append(
            pd.read_csv(test_path, usecols=["id", "rating"]).rename(
                columns={"rating": name}
            )
        )

    frame = oof_frames[0]
    for oof_frame in oof_frames[1:]:
        frame = frame.merge(oof_frame, on="id", how="inner", validate="one_to_one")
    if clean_labels is None:
        raise RuntimeError("At least one OOF stream is required.")
    frame["rating"] = frame["id"].map(
        clean_labels.set_index("id")["rating"]
    )
    frame["validation_split"] = frame["id"].map(split_lookup)
    if frame[names + ["rating", "validation_split"]].isna().any().any():
        raise RuntimeError("OOF rows could not all be aligned to validation rows.")
    frame = frame.sort_values("id").reset_index(drop=True)
    prediction = frame[names].to_numpy(dtype=np.float64)
    target = frame["rating"].to_numpy(dtype=np.float64)
    weights = split_natural_weights(frame, prior)

    test = test_frames[0]
    for test_frame in test_frames[1:]:
        test = test.merge(
            test_frame, on="id", how="inner", validate="one_to_one"
        )
    proxy = pd.read_csv(args.test_proxy)
    expected_test = pd.read_csv("input/test.csv", usecols=["id"])
    if set(test["id"]) != set(expected_test["id"]):
        raise RuntimeError("Test ensemble rows do not cover the full test set.")
    test = test.set_index("id").loc[expected_test["id"]].reset_index()
    proxy = proxy.set_index("id").loc[test["id"]].reset_index()

    individual: dict[str, object] = {}
    for index, name in enumerate(names):
        individual[name] = split_scores(
            frame, prediction[:, index], weights
        )

    equal_prediction = np.clip(prediction.mean(axis=1), 1.0, 5.0)
    equal_scores = split_scores(frame, equal_prediction, weights)
    full_weights = optimize_simplex(prediction, target, weights)
    full_prediction = np.clip(prediction @ full_weights, 1.0, 5.0)
    full_scores = split_scores(frame, full_prediction, weights)

    fold_ids = make_fold_ids(frame, sample, args.folds, args.seed)
    nested = crossfit_metrics(
        frame, prediction, weights, fold_ids, args.folds
    )
    equal_nested_scores = []
    for fold in range(args.folds):
        eval_mask = fold_ids == fold
        equal_nested_scores.append(
            split_scores(
                frame.loc[eval_mask].reset_index(drop=True),
                np.clip(prediction[eval_mask].mean(axis=1), 1.0, 5.0),
                weights[eval_mask],
            )
        )
    equal_nested = np.asarray(
        [score["objective"] for score in equal_nested_scores]
    )

    diagnostic_test_prediction = np.clip(
        test[names].to_numpy(dtype=np.float64) @ full_weights, 1.0, 5.0
    )
    proxy_mask = proxy["source_rating"].notna().to_numpy()
    proxy_target = (
        proxy.loc[proxy_mask, "source_rating"].to_numpy(dtype=np.float64)
    )
    proxy_score = weighted_rmse(
        proxy_target,
        diagnostic_test_prediction[proxy_mask],
        np.ones(proxy_mask.sum(), dtype=np.float64),
    )

    correlations = pd.DataFrame(prediction, columns=names).corr().to_dict()
    diagnostics = {
        "rows": int(len(frame)),
        "random_rows": int(
            frame["validation_split"].eq("val_random").sum()
        ),
        "group_rows": int(
            (~frame["validation_split"].eq("val_random")).sum()
        ),
        "folds": args.folds,
        "seed": args.seed,
        "individual": individual,
        "equal": {
            "full": equal_scores,
            "nested_objective_mean": float(equal_nested.mean()),
            "nested_objective_std": float(equal_nested.std(ddof=1)),
            "fold_scores": equal_nested_scores,
        },
        "simplex": {
            "full_weights": dict(zip(names, full_weights.tolist())),
            "full": full_scores,
            "nested": nested,
        },
        "prediction_correlations": correlations,
        "test_proxy": {
            "rows": int(proxy_mask.sum()),
            "rmse": proxy_score,
            "note": "Diagnostic only; not used for fitting or selection.",
        },
    }
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(diagnostics, indent=2) + "\n")

    if args.output:
        output = pd.DataFrame(
            {"id": test["id"], "rating": diagnostic_test_prediction}
        )
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output.to_csv(output_path, index=False)
        diagnostics["candidate_output"] = str(output_path)
    print(json.dumps(diagnostics, indent=2))


if __name__ == "__main__":
    main()
