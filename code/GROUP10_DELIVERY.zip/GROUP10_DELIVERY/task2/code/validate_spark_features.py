"""Compare Spark-produced features with the local reference implementation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


DIRECT_COLUMNS = [
    "title_length",
    "comment_length",
    "combined_length",
    "log_votes",
    "purchased_int",
    "year",
    "month",
    "dayofweek",
    "year_month_index",
]

STAT_COLUMNS = [
    "user_count",
    "user_te",
    "user_p5",
    "product_count",
    "product_te",
    "product_p5",
    "parent_count",
    "parent_te",
    "parent_p5",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--spark-report", default="logs/spark_prior_features.json")
    parser.add_argument(
        "--reference-dir", default="oof/prior_features_rich2"
    )
    parser.add_argument("--output", default="logs/spark_feature_validation.json")
    args = parser.parse_args()

    spark_report = json.loads(Path(args.spark_report).read_text())
    results: dict[str, object] = {
        "spark_elapsed_seconds": spark_report["elapsed_seconds"],
        "matched_train_rows": spark_report["matched_train_rows"],
        "splits": {},
    }
    for split in ("val_random", "val_group"):
        spark = pd.read_csv(spark_report["outputs"][split]).set_index("id")
        reference = pd.read_csv(
            Path(args.reference_dir) / f"prior_features_{split}.csv"
        ).set_index("id")
        common_ids = spark.index.intersection(reference.index)
        if len(common_ids) != len(spark) or len(common_ids) != len(reference):
            raise RuntimeError(f"{split} row IDs do not match the reference.")

        direct: dict[str, object] = {}
        for column in DIRECT_COLUMNS:
            difference = (
                pd.to_numeric(spark.loc[common_ids, column], errors="coerce")
                - pd.to_numeric(reference.loc[common_ids, column], errors="coerce")
            ).abs()
            direct[column] = {
                "max_abs_difference": float(difference.max()),
                "nonmatching_rows": int((difference > 1e-9).sum()),
            }

        statistics: dict[str, object] = {}
        for column in STAT_COLUMNS:
            difference = (
                pd.to_numeric(spark.loc[common_ids, column], errors="coerce")
                - pd.to_numeric(reference.loc[common_ids, column], errors="coerce")
            ).abs()
            statistics[column] = {
                "mean_abs_difference": float(difference.mean()),
                "p99_abs_difference": float(difference.quantile(0.99)),
                "max_abs_difference": float(difference.max()),
            }
        results["splits"][split] = {
            "rows": int(len(common_ids)),
            "label_agreement": float(
                (
                    spark.loc[common_ids, "rating"]
                    == reference.loc[common_ids, "rating"]
                ).mean()
            ),
            "direct_features": direct,
            "aggregate_differences": statistics,
            "note": (
                "Aggregate differences are expected because Spark excludes every "
                "training row for validation users, a stricter group guard than "
                "the local bucket reference."
            ),
        }

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
