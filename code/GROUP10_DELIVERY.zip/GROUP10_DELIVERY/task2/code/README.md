# Task 2 Source Code

Run the commands in the parent `RUN_COMMANDS.md` from the package root. This
directory contains the implementation modules; paths such as `input/`,
`oof/`, `logs/`, and `models/` are intentionally relative to that package
root so the pipeline remains reproducible.

The final scored submission is `../submission/final_submission.csv`. Its
format and SHA-256 are recorded in `../submission/final_validation.json`.
