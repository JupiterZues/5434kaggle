"""Generate Task 2 predictions with one or more fine-tuned transformer models."""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from transformers import DataCollatorWithPadding
from rating_model import (
    load_mean_pooling_regressor,
    load_multilayer_attention_regressor,
    load_multilayer_head_attention_regressor,
)


os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")


class ReviewTextDataset(Dataset):
    def __init__(
        self,
        frame: pd.DataFrame,
        tokenizer: AutoTokenizer,
        max_length: int,
        window: str = "full",
    ) -> None:
        self.ids = frame["id"].to_numpy()
        self.texts = []
        for title, comment in zip(frame["title"], frame["comment"]):
            title_text = "" if pd.isna(title) else str(title)
            comment_text = "" if pd.isna(comment) else str(comment)
            if window not in {"full"} and len(comment_text) > max_length * 4:
                crop_length = max_length * 4
                if window == "tail":
                    comment_text = comment_text[-crop_length:]
                elif window == "head":
                    comment_text = comment_text[:crop_length]
                elif window == "head_tail":
                    half = crop_length // 2
                    comment_text = (
                        f"{comment_text[:half]} ... {comment_text[-half:]}"
                    )
                else:
                    raise ValueError(f"Unsupported window={window!r}")
            self.texts.append(f"{title_text}\n{comment_text}".strip())
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.window = window

    def __len__(self) -> int:
        return len(self.texts)

    def __getitem__(self, index: int) -> dict[str, object]:
        encoded = self.tokenizer(
            self.texts[index],
            truncation=True,
            max_length=self.max_length,
            add_special_tokens=True,
        )
        encoded["id"] = int(self.ids[index])
        return encoded


@torch.inference_mode()
def predict_one_model(
    model_dir: Path,
    test: pd.DataFrame,
    max_length: int,
    batch_size: int,
    num_workers: int,
    use_bf16: bool,
    windows: list[str],
) -> np.ndarray:
    tokenizer = AutoTokenizer.from_pretrained(model_dir)
    config_path = model_dir / "config.json"
    model_config = json.loads(config_path.read_text()) if config_path.exists() else {}
    if model_config.get("pooling_strategy") == "mean":
        model = load_mean_pooling_regressor(model_dir, load_head=True)
    elif model_config.get("pooling_strategy") == "multilayer_attention":
        model = load_multilayer_attention_regressor(model_dir, load_head=True)
    elif model_config.get("pooling_strategy") == "multilayer_head_attention":
        model = load_multilayer_head_attention_regressor(
            model_dir, load_head=True
        )
    else:
        model = AutoModelForSequenceClassification.from_pretrained(
            model_dir,
            num_labels=1,
            problem_type="regression",
        )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()

    window_predictions = []
    for window in windows:
        dataset = ReviewTextDataset(
            test, tokenizer, max_length, window=window
        )
        loader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
            persistent_workers=num_workers > 0,
            collate_fn=DataCollatorWithPadding(tokenizer=tokenizer),
        )
        predictions: list[np.ndarray] = []
        for batch in loader:
            ids = batch.pop("id")
            inputs = {
                key: value.to(device, non_blocking=True)
                for key, value in batch.items()
            }
            with torch.autocast(
                device_type=device.type,
                dtype=torch.bfloat16,
                enabled=use_bf16 and device.type == "cuda",
            ):
                logits = model(**inputs).logits.squeeze(-1)
            if logits.shape[0] != ids.shape[0]:
                raise RuntimeError(
                    "Prediction batch shape does not match input IDs."
                )
            predictions.append(logits.float().cpu().numpy())
        window_predictions.append(np.concatenate(predictions))

    result = np.clip(
        np.mean(np.stack(window_predictions, axis=0), axis=0), 1.0, 5.0
    )
    if len(result) != len(test):
        raise RuntimeError(
            f"Prediction row count mismatch: got {len(result)} expected {len(test)}"
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", nargs="+", required=True)
    parser.add_argument("--weight", nargs="+", type=float, default=None)
    parser.add_argument("--test", default="input/test.csv")
    parser.add_argument("--sample-submission", default="input/sampleSubmission.csv")
    parser.add_argument("--output", required=True)
    parser.add_argument("--oof-output", default=None)
    parser.add_argument("--max-length", type=int, default=192)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--num-workers", type=int, default=8)
    parser.add_argument("--bf16", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--tta", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument(
        "--window",
        choices=["full", "head", "tail", "head_tail"],
        default="full",
    )
    args = parser.parse_args()

    started = pd.Timestamp.now(tz="UTC").isoformat()
    start_time = time.monotonic()
    test = pd.read_csv(args.test)
    sample = pd.read_csv(args.sample_submission)

    if len(test) != len(sample):
        raise RuntimeError(
            f"Test/sample row count mismatch: {len(test)} vs {len(sample)}"
        )
    if not np.array_equal(test["id"].to_numpy(), sample["id"].to_numpy()):
        raise RuntimeError("Test and sample submission ID order do not match.")
    if test["id"].duplicated().any():
        raise RuntimeError("Duplicate IDs found in the test set.")

    model_results = []
    for model_dir_string in args.model_dir:
        model_dir = Path(model_dir_string)
        print(f"predicting with {model_dir}", flush=True)
        prediction = predict_one_model(
            model_dir=model_dir,
            test=test,
            max_length=args.max_length,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            use_bf16=args.bf16,
            windows=(
                ["full", "tail", "head"] if args.tta else [args.window]
            ),
        )
        model_results.append(prediction)

    prediction_matrix = np.stack(model_results, axis=0)
    if args.weight is None:
        weights = np.ones(len(model_results), dtype=np.float64)
    else:
        weights = np.asarray(args.weight, dtype=np.float64)
        if len(weights) != len(model_results):
            raise RuntimeError("--weight count must match --model-dir count.")
        if np.any(weights < 0) or weights.sum() <= 0:
            raise RuntimeError("Weights must be nonnegative with a positive sum.")
    weights = weights / weights.sum()
    final_prediction = np.clip(
        np.tensordot(weights, prediction_matrix, axes=(0, 0)), 1.0, 5.0
    )

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output = pd.DataFrame({"id": sample["id"], "rating": final_prediction})
    output.to_csv(output_path, index=False)

    if args.oof_output:
        oof_path = Path(args.oof_output)
        oof_path.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(
            {
                "id": sample["id"],
                **{
                    f"model_{index}": values
                    for index, values in enumerate(model_results)
                },
                "rating": final_prediction,
            }
        ).to_csv(oof_path, index=False)

    report = {
        "status": "complete",
        "started_at": started,
        "finished_at": pd.Timestamp.now(tz="UTC").isoformat(),
        "elapsed_seconds": time.monotonic() - start_time,
        "model_dirs": args.model_dir,
        "weights": weights.tolist(),
        "tta": bool(args.tta),
        "rows": int(len(output)),
        "prediction_min": float(final_prediction.min()),
        "prediction_mean": float(final_prediction.mean()),
        "prediction_max": float(final_prediction.max()),
        "output": str(output_path),
    }
    report_path = output_path.with_suffix(".json")
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
