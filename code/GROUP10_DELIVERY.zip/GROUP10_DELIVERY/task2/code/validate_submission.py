"""Fail-fast validation for Task 2 submission files."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prediction", required=True)
    parser.add_argument(
        "--sample-submission", default="input/sampleSubmission.csv"
    )
    parser.add_argument("--report")
    args = parser.parse_args()

    prediction_path = Path(args.prediction)
    if not prediction_path.is_file() or prediction_path.stat().st_size == 0:
        raise RuntimeError(f"Submission is missing or empty: {prediction_path}")
    prediction = pd.read_csv(prediction_path)
    sample = pd.read_csv(args.sample_submission)
    if list(prediction.columns) != ["id", "rating"]:
        raise RuntimeError(
            f"Expected columns ['id', 'rating'], got {prediction.columns.tolist()}"
        )
    if len(prediction) != len(sample):
        raise RuntimeError(
            f"Row count mismatch: {len(prediction)} vs {len(sample)}"
        )
    if prediction["id"].duplicated().any():
        raise RuntimeError("Submission contains duplicate IDs.")
    if not np.array_equal(
        prediction["id"].to_numpy(), sample["id"].to_numpy()
    ):
        raise RuntimeError("Submission ID order does not match sample.")
    values = pd.to_numeric(prediction["rating"], errors="coerce").to_numpy(
        dtype=np.float64
    )
    if not np.isfinite(values).all():
        raise RuntimeError("Submission contains NaN or infinite ratings.")
    if values.min() < 1.0 or values.max() > 5.0:
        raise RuntimeError(
            f"Ratings outside [1, 5]: min={values.min()} max={values.max()}"
        )

    report = {
        "prediction": str(prediction_path),
        "sha256": sha256(prediction_path),
        "file_bytes": int(prediction_path.stat().st_size),
        "rows": int(len(prediction)),
        "id_order_matches_sample": True,
        "finite": True,
        "range_ok": True,
        "mean": float(values.mean()),
        "std": float(values.std()),
        "min": float(values.min()),
        "max": float(values.max()),
        "quantiles": {
            str(quantile): float(np.quantile(values, quantile))
            for quantile in (0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99)
        },
    }
    if args.report:
        report_path = Path(args.report)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
