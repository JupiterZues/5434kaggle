"""Extract compact product metadata from the public Amazon metadata file."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def sequence_length(value: object) -> int:
    if value is None:
        return 0
    if isinstance(value, list):
        return len(value)
    if isinstance(value, dict):
        return len(value)
    return 1 if str(value).strip() else 0


def sequence_chars(value: object) -> int:
    if value is None:
        return 0
    if isinstance(value, list):
        return sum(len(str(item)) for item in value)
    if isinstance(value, dict):
        return sum(len(str(item)) for item in value.values())
    return len(str(value))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    rows = []
    with Path(args.input).open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            record = json.loads(line)
            parent_asin = str(record.get("parent_asin") or "")
            if not parent_asin:
                continue
            categories = record.get("categories") or []
            leaf = categories[-1] if categories else ""
            price = record.get("price")
            try:
                price = float(price) if price is not None else None
            except (TypeError, ValueError):
                price = None
            rows.append(
                {
                    "source_parent_asin": parent_asin,
                    "meta_average_rating": record.get("average_rating"),
                    "meta_rating_number": record.get("rating_number"),
                    "meta_price": price,
                    "meta_title_length": len(str(record.get("title") or "")),
                    "meta_feature_count": sequence_length(
                        record.get("features")
                    ),
                    "meta_feature_chars": sequence_chars(
                        record.get("features")
                    ),
                    "meta_description_chars": sequence_chars(
                        record.get("description")
                    ),
                    "meta_image_count": sequence_length(record.get("images")),
                    "meta_video_count": sequence_length(record.get("videos")),
                    "meta_detail_count": sequence_length(record.get("details")),
                    "meta_category_leaf": leaf,
                    "meta_store": record.get("store"),
                }
            )
            if line_number % 100_000 == 0:
                print(
                    f"metadata_rows={line_number:,} kept={len(rows):,}",
                    flush=True,
                )

    frame = pd.DataFrame(rows)
    frame = frame.drop_duplicates(subset=["source_parent_asin"], keep="last")
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output_path, index=False)
    print(
        json.dumps(
            {
                "input": args.input,
                "output": str(output_path),
                "rows": int(len(frame)),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
