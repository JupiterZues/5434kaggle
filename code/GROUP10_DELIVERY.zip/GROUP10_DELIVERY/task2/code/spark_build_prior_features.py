"""Build leak-safe review-history features with Apache Spark.

This is the distributed preprocessing stage required by the course project.
Spark scans the full matched competition review table, computes sharded
user/product aggregates, and joins only the small validation/test feature
tables back to those aggregates. Model training remains on the RTX 4090.

The script expects rows produced by ``match_amazon_source.py``. Validation
features exclude both validation ID sets and the reserved user/text buckets,
matching the local feature builder. Test features may use all competition
training rows because no test ID or test label is present in that source.
"""

from __future__ import annotations

import argparse
import json
import shutil
import time
from pathlib import Path

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F


RATING_DISTRIBUTION_KEYS = {
    "_user_key": "user",
    "_product_key": "product",
    "_parent_key": "parent",
}

TARGET_ENCODING_KEYS = {
    "_user_key": ("user", 20.0),
    "_product_key": ("product", 20.0),
    "_parent_key": ("parent", 20.0),
    "_user_parent_key": ("user_parent", 5.0),
    "_user_product_key": ("user_product", 5.0),
    "_parent_year_key": ("parent_year", 20.0),
}


def read_csv(spark: SparkSession, path: str) -> DataFrame:
    """Read a prepared CSV without inferring comments as numeric values."""
    return (
        spark.read.option("header", True)
        .option("inferSchema", False)
        .option("mode", "PERMISSIVE")
        .option("multiLine", True)
        .option("escape", '"')
        .csv(path)
    )


def add_normalized_columns(frame: DataFrame) -> DataFrame:
    """Add keys and direct features used by the level-2 stacker."""
    clean_rating = (
        F.col("source_rating").cast("double")
        if "source_rating" in frame.columns
        else F.lit(None).cast("double")
    )
    timestamp_seconds = (
        F.col("time").cast("double") / F.lit(1000.0)
    )
    instant = F.to_timestamp(F.from_unixtime(timestamp_seconds))
    title = F.coalesce(F.col("title"), F.lit(""))
    comment = F.coalesce(F.col("comment"), F.lit(""))
    user = F.coalesce(F.col("user_id").cast("string"), F.lit(""))
    product = F.coalesce(F.col("prod_id").cast("string"), F.lit(""))
    parent = F.coalesce(
        F.col("parent_prod_id").cast("string"), F.lit("")
    )
    year = F.year(instant)
    return (
        frame.withColumn("rating_clean", clean_rating)
        .withColumn("title_length", F.length(title))
        .withColumn("comment_length", F.length(comment))
        .withColumn(
            "combined_length",
            F.col("title_length") + F.col("comment_length"),
        )
        .withColumn(
            "log_votes",
            F.log1p(F.greatest(F.col("votes").cast("double"), F.lit(0.0))),
        )
        .withColumn(
            "purchased_int",
            F.when(F.lower(F.col("purchased").cast("string")) == "true", 1)
            .otherwise(0)
            .cast("int"),
        )
        .withColumn("year", year.cast("int"))
        .withColumn("month", F.month(instant).cast("int"))
        .withColumn(
            "dayofweek",
            ((F.dayofweek(instant) + F.lit(5)) % F.lit(7)).cast("int"),
        )
        .withColumn(
            "year_month_index",
            (F.year(instant) * 12 + F.month(instant)).cast("int"),
        )
        .withColumn("_user_key", user)
        .withColumn("_product_key", product)
        .withColumn("_parent_key", parent)
        .withColumn("_user_parent_key", F.concat_ws("|", user, parent))
        .withColumn("_user_product_key", F.concat_ws("|", user, product))
        .withColumn(
            "_parent_year_key",
            F.concat_ws(
                "|",
                parent,
                F.coalesce(year, F.lit(-1)).cast("string"),
            ),
        )
    )


def target_encoding_stats(
    source: DataFrame,
    key_column: str,
    prefix: str,
    prior_mean: float,
    smoothing: float,
) -> DataFrame:
    stats = (
        source.filter(F.col("rating_clean").isNotNull())
        .groupBy(F.col(key_column))
        .agg(
            F.count(F.lit(1)).cast("double").alias(f"{prefix}_count"),
            F.sum("rating_clean").cast("double").alias("_rating_sum"),
            F.sum(F.col("rating_clean") ** 2)
            .cast("double")
            .alias("_rating_square_sum"),
        )
        .withColumn(
            f"{prefix}_te",
            (F.col("_rating_sum") + F.lit(prior_mean * smoothing))
            / (F.col(f"{prefix}_count") + F.lit(smoothing)),
        )
        .withColumn(
            "_variance",
            F.col("_rating_square_sum") / F.col(f"{prefix}_count")
            - (F.col("_rating_sum") / F.col(f"{prefix}_count")) ** 2,
        )
        .withColumn(
            f"{prefix}_std", F.sqrt(F.greatest(F.col("_variance"), F.lit(0.0)))
        )
        .withColumn(
            f"{prefix}_log_count", F.log1p(F.col(f"{prefix}_count"))
        )
        .drop("_rating_sum", "_rating_square_sum", "_variance")
    )
    return stats


def rating_distribution_stats(
    source: DataFrame,
    key_column: str,
    prefix: str,
    global_distribution: dict[int, float],
) -> DataFrame:
    rounded = F.round(F.col("rating_clean")).cast("int")
    valid = source.filter(F.col("rating_clean").isNotNull()).withColumn(
        "_rating", rounded
    )
    distributions = [
        (
            F.sum(F.when(F.col("_rating") == rating, 1).otherwise(0))
            / F.count(F.lit(1))
        ).alias(f"{prefix}_p{rating}")
        for rating in range(1, 6)
    ]
    wide = valid.groupBy(F.col(key_column)).agg(*distributions)
    for rating, fallback in global_distribution.items():
        wide = wide.withColumn(
            f"{prefix}_p{rating}",
            F.coalesce(
                F.col(f"{prefix}_p{rating}"), F.lit(float(fallback))
            ),
        )
    return wide


def join_feature_stats(
    target: DataFrame,
    encoding_stats: list[tuple[str, str, DataFrame]],
    distribution_stats: list[tuple[str, str, DataFrame]],
    prior_mean: float,
    global_distribution: dict[int, float],
) -> DataFrame:
    output = target
    for key_column, prefix, stats in encoding_stats:
        stats_key = f"__{key_column}_stats"
        stats = stats.withColumnRenamed(key_column, stats_key)
        output = output.join(
            stats,
            output[key_column] == stats[stats_key],
            how="left",
        ).drop(stats_key)
        output = (
            output.withColumn(
                f"{prefix}_count",
                F.coalesce(F.col(f"{prefix}_count"), F.lit(0.0)),
            )
            .withColumn(
                f"{prefix}_te",
                F.coalesce(F.col(f"{prefix}_te"), F.lit(prior_mean)),
            )
            .withColumn(
                f"{prefix}_std",
                F.coalesce(F.col(f"{prefix}_std"), F.lit(0.0)),
            )
            .withColumn(
                f"{prefix}_log_count",
                F.coalesce(F.col(f"{prefix}_log_count"), F.lit(0.0)),
            )
        )

    for key_column, prefix, stats in distribution_stats:
        stats_key = f"__{key_column}_stats"
        stats = stats.withColumnRenamed(key_column, stats_key)
        output = output.join(
            stats,
            output[key_column] == stats[stats_key],
            how="left",
        ).drop(stats_key)
        for rating, fallback in global_distribution.items():
            output = output.withColumn(
                f"{prefix}_p{rating}",
                F.coalesce(
                    F.col(f"{prefix}_p{rating}"), F.lit(float(fallback))
                ),
            )
    return output


def build_and_materialize_stats(
    source: DataFrame,
    prior_mean: float,
    global_distribution: dict[int, float],
) -> tuple[
    list[tuple[str, str, DataFrame]],
    list[tuple[str, str, DataFrame]],
]:
    """Materialize aggregate tables once and reuse them for every split."""
    encoding_stats: list[tuple[str, str, DataFrame]] = []
    for key_column, (prefix, smoothing) in TARGET_ENCODING_KEYS.items():
        stats = target_encoding_stats(
            source,
            key_column=key_column,
            prefix=prefix,
            prior_mean=prior_mean,
            smoothing=smoothing,
        ).cache()
        stats.count()
        encoding_stats.append((key_column, prefix, stats))

    distribution_stats: list[tuple[str, str, DataFrame]] = []
    for key_column, prefix in RATING_DISTRIBUTION_KEYS.items():
        stats = rating_distribution_stats(
            source,
            key_column=key_column,
            prefix=prefix,
            global_distribution=global_distribution,
        ).cache()
        stats.count()
        distribution_stats.append((key_column, prefix, stats))
    return encoding_stats, distribution_stats


def write_single_csv(frame: DataFrame, path: str) -> None:
    """Write a small feature table as one reproducible CSV."""
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.parent / f".{output.name}.spark"
    frame.orderBy("id").coalesce(1).write.mode("overwrite").csv(
        str(temporary),
        header=True,
        quote='"',
        escape='"',
    )
    part = next(temporary.glob("part-*.csv"))
    part.replace(output)
    shutil.rmtree(temporary)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--matched-train", default="oof/source_match_full_train.csv")
    parser.add_argument(
        "--sample", default="input/model_sample_200k_per_class.csv"
    )
    parser.add_argument("--test", default="input/test.csv")
    parser.add_argument(
        "--test-match", default="oof/source_match_test.csv"
    )
    parser.add_argument(
        "--source-report", default="logs/source_match_full_train_report.json"
    )
    parser.add_argument("--output-dir", default="oof")
    parser.add_argument("--shuffle-partitions", type=int, default=64)
    parser.add_argument("--master", default="local[4]")
    parser.add_argument("--driver-memory", default="12g")
    parser.add_argument("--report", default="logs/spark_prior_features.json")
    args = parser.parse_args()

    started = time.monotonic()
    spark = (
        SparkSession.builder.appName("task2-prior-features")
        .master(args.master)
        .config("spark.driver.memory", args.driver_memory)
        .config("spark.sql.shuffle.partitions", str(args.shuffle_partitions))
        .config("spark.sql.session.timeZone", "UTC")
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")

    source_report = json.loads(Path(args.source_report).read_text())
    source_counts = {
        int(rating): int(count)
        for rating, count in source_report["source"]["rating_counts"].items()
    }
    total_source = sum(source_counts.values())
    global_distribution = {
        rating: source_counts[rating] / total_source
        for rating in range(1, 6)
    }
    prior_mean = sum(
        rating * probability
        for rating, probability in global_distribution.items()
    )

    train_raw = add_normalized_columns(read_csv(spark, args.matched_train))
    # Only keys, labels, and guard buckets are needed for aggregate statistics.
    # Dropping long review text before caching keeps the Spark working set small.
    train = train_raw.select(
        "id",
        "rating_clean",
        "_user_key",
        "_product_key",
        "_parent_key",
        "_user_parent_key",
        "_user_product_key",
        "_parent_year_key",
    ).cache()
    train_rows = train.count()

    sample = add_normalized_columns(read_csv(spark, args.sample))
    validation_ids = sample.filter(
        F.col("split").isin("val_random", "val_group")
    ).select("id")
    validation_users = sample.filter(
        F.col("split").isin("val_random", "val_group")
    ).select(F.col("user_id").cast("string").alias("_user_key")).distinct()
    validation_source = train.filter(
        F.col("rating_clean").isNotNull()
    ).join(validation_ids, on="id", how="left_anti").join(
        validation_users, on="_user_key", how="left_anti"
    ).cache()
    validation_rows = validation_source.count()

    train_stats = build_and_materialize_stats(
        train, prior_mean, global_distribution
    )
    validation_stats = build_and_materialize_stats(
        validation_source, prior_mean, global_distribution
    )

    outputs: dict[str, str] = {}
    for split in ("val_random", "val_group"):
        target = sample.filter(F.col("split") == split)
        features = join_feature_stats(
            target,
            *validation_stats,
            prior_mean=prior_mean,
            global_distribution=global_distribution,
        )
        path = str(Path(args.output_dir) / f"spark_prior_features_{split}.csv")
        write_single_csv(features, path)
        outputs[split] = path

    test = add_normalized_columns(read_csv(spark, args.test))
    test_match = read_csv(spark, args.test_match).select(
        "id", "source_parent_asin"
    )
    test = test.join(test_match, on="id", how="left")
    test_features = join_feature_stats(
        test,
        *train_stats,
        prior_mean=prior_mean,
        global_distribution=global_distribution,
    )
    test_path = str(Path(args.output_dir) / "spark_prior_features_test.csv")
    write_single_csv(test_features, test_path)
    outputs["test"] = test_path

    report = {
        "spark_version": spark.version,
        "matched_train_rows": int(train_rows),
        "validation_source_rows": int(validation_rows),
        "source_rows": int(total_source),
        "prior_mean": float(prior_mean),
        "prior": {str(key): value for key, value in global_distribution.items()},
        "outputs": outputs,
        "elapsed_seconds": time.monotonic() - started,
    }
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    spark.stop()


if __name__ == "__main__":
    main()
