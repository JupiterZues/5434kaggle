"""Mean-pooled transformer regressor with explicit task-head persistence."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn as nn
from transformers import AutoModel


class MeanPoolingRegressor(nn.Module):
    def __init__(
        self,
        backbone: nn.Module,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.backbone = backbone
        hidden_size = int(backbone.config.hidden_size)
        self.dropout = nn.Dropout(dropout)
        self.regressor = nn.Linear(hidden_size, 1)
        self.config = backbone.config
        self.config.pooling_strategy = "mean"
        self.config.problem_type = "regression"
        self.config.num_labels = 1

    def gradient_checkpointing_enable(self) -> None:
        self.backbone.gradient_checkpointing_enable()

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor | None = None,
        token_type_ids: torch.Tensor | None = None,
    ) -> SimpleNamespace:
        outputs = self.backbone(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        hidden = outputs.last_hidden_state
        if attention_mask is None:
            pooled = hidden.mean(dim=1)
        else:
            mask = attention_mask.unsqueeze(-1).to(hidden.dtype)
            pooled = (hidden * mask).sum(dim=1) / mask.sum(dim=1).clamp_min(1.0)
        with torch.autocast(device_type=pooled.device.type, enabled=False):
            logits = self.regressor(self.dropout(pooled.float())).squeeze(-1)
        return SimpleNamespace(logits=logits.unsqueeze(-1))

    def save_pretrained(
        self,
        save_directory: str | Path,
        safe_serialization: bool = True,
    ) -> None:
        output_dir = Path(save_directory)
        output_dir.mkdir(parents=True, exist_ok=True)
        self.backbone.save_pretrained(
            output_dir,
            safe_serialization=safe_serialization,
        )
        torch.save(
            {
                "regressor": self.regressor.state_dict(),
                "dropout": self.dropout.p,
                "pooling_strategy": "mean",
            },
            output_dir / "regressor_head.pt",
        )


class MultiLayerAttentionPoolingRegressor(nn.Module):
    def __init__(
        self,
        backbone: nn.Module,
        num_layers: int = 4,
        dropout: float = 0.1,
        dropout_samples: int = 4,
    ) -> None:
        super().__init__()
        self.backbone = backbone
        self.num_layers = num_layers
        self.dropout_samples = dropout_samples
        hidden_size = int(backbone.config.hidden_size)
        self.attention_weights = nn.ModuleList(
            [nn.Linear(hidden_size, 1) for _ in range(num_layers)]
        )
        self.feature_norm = nn.LayerNorm(hidden_size * num_layers * 3)
        self.dropout = nn.Dropout(dropout)
        self.regressor = nn.Linear(hidden_size * num_layers * 3, 1)
        self.config = backbone.config
        self.config.pooling_strategy = "multilayer_attention"
        self.config.problem_type = "regression"
        self.config.num_labels = 1
        self.config.num_pool_layers = num_layers
        self.config.dropout_samples = dropout_samples

    def gradient_checkpointing_enable(self) -> None:
        self.backbone.gradient_checkpointing_enable()

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor | None = None,
        token_type_ids: torch.Tensor | None = None,
    ) -> SimpleNamespace:
        outputs = self.backbone(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            output_hidden_states=True,
        )
        hidden_states = outputs.hidden_states[-self.num_layers :]
        if attention_mask is None:
            attention_mask = torch.ones_like(input_ids)
        mask = attention_mask.unsqueeze(-1)
        pooled_layers = []
        for index, hidden in enumerate(hidden_states):
            hidden = hidden.float()
            float_mask = mask.to(hidden.dtype)
            mean_pooled = (hidden * float_mask).sum(dim=1) / float_mask.sum(
                dim=1
            ).clamp_min(1.0)
            max_pooled = hidden.masked_fill(float_mask == 0, -1e4).amax(dim=1)
            attention_logits = self.attention_weights[index](hidden).squeeze(-1)
            attention_logits = attention_logits.masked_fill(
                attention_mask == 0, -1e4
            )
            attention = attention_logits.softmax(dim=1).unsqueeze(-1)
            attention_pooled = (hidden * attention).sum(dim=1)
            pooled_layers.extend([mean_pooled, max_pooled, attention_pooled])
        pooled = self.feature_norm(torch.cat(pooled_layers, dim=1))
        with torch.autocast(device_type=pooled.device.type, enabled=False):
            if self.training and self.dropout_samples > 1:
                repeated = pooled.unsqueeze(1).expand(
                    -1, self.dropout_samples, -1
                )
                repeated = self.dropout(repeated)
                logits = self.regressor(repeated).squeeze(-1).mean(dim=1)
            else:
                logits = self.regressor(self.dropout(pooled)).squeeze(-1)
        return SimpleNamespace(logits=logits.unsqueeze(-1))

    def save_pretrained(
        self,
        save_directory: str | Path,
        safe_serialization: bool = True,
    ) -> None:
        output_dir = Path(save_directory)
        output_dir.mkdir(parents=True, exist_ok=True)
        self.backbone.save_pretrained(
            output_dir,
            safe_serialization=safe_serialization,
        )
        torch.save(
            {
                "regressor": self.regressor.state_dict(),
                "feature_norm": self.feature_norm.state_dict(),
                "attention_weights": self.attention_weights.state_dict(),
                "dropout": self.dropout.p,
                "dropout_samples": self.dropout_samples,
                "num_layers": self.num_layers,
                "pooling_strategy": "multilayer_attention",
            },
            output_dir / "regressor_head.pt",
        )


class MultiLayerHeadAttentionPoolingRegressor(nn.Module):
    """Pool the last layers with mean, max, and per-head token attention."""

    def __init__(
        self,
        backbone: nn.Module,
        num_layers: int = 4,
        num_heads: int = 12,
        dropout: float = 0.1,
        dropout_samples: int = 4,
    ) -> None:
        super().__init__()
        hidden_size = int(backbone.config.hidden_size)
        if hidden_size % num_heads:
            raise ValueError(
                f"hidden size {hidden_size} is not divisible by {num_heads} heads"
            )
        self.backbone = backbone
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.head_size = hidden_size // num_heads
        self.dropout_samples = dropout_samples
        self.attention_weights = nn.ModuleList(
            [nn.Linear(hidden_size, num_heads) for _ in range(num_layers)]
        )
        self.feature_norm = nn.LayerNorm(hidden_size * num_layers * 3)
        self.dropout = nn.Dropout(dropout)
        self.regressor = nn.Linear(hidden_size * num_layers * 3, 1)
        self.config = backbone.config
        self.config.pooling_strategy = "multilayer_head_attention"
        self.config.problem_type = "regression"
        self.config.num_labels = 1
        self.config.num_pool_layers = num_layers
        self.config.num_pool_heads = num_heads
        self.config.dropout_samples = dropout_samples

    def gradient_checkpointing_enable(self) -> None:
        self.backbone.gradient_checkpointing_enable()

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor | None = None,
        token_type_ids: torch.Tensor | None = None,
    ) -> SimpleNamespace:
        outputs = self.backbone(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            output_hidden_states=True,
        )
        hidden_states = outputs.hidden_states[-self.num_layers :]
        if attention_mask is None:
            attention_mask = torch.ones_like(input_ids)
        mask = attention_mask.unsqueeze(-1)
        pooled_layers = []
        batch_size, sequence_length, hidden_size = hidden_states[0].shape
        for index, hidden in enumerate(hidden_states):
            hidden = hidden.float()
            float_mask = mask.to(hidden.dtype)
            mean_pooled = (hidden * float_mask).sum(dim=1) / float_mask.sum(
                dim=1
            ).clamp_min(1.0)
            max_pooled = hidden.masked_fill(float_mask == 0, -1e4).amax(dim=1)

            head_values = hidden.view(
                batch_size,
                sequence_length,
                self.num_heads,
                self.head_size,
            ).transpose(1, 2)
            attention_logits = self.attention_weights[index](hidden).transpose(
                1, 2
            )
            attention_logits = attention_logits.masked_fill(
                attention_mask.unsqueeze(1) == 0, -1e4
            )
            attention = attention_logits.softmax(dim=-1).unsqueeze(-1)
            head_pooled = (head_values * attention).sum(dim=2).reshape(
                batch_size, hidden_size
            )
            pooled_layers.extend([mean_pooled, max_pooled, head_pooled])
        pooled = self.feature_norm(torch.cat(pooled_layers, dim=1))
        with torch.autocast(device_type=pooled.device.type, enabled=False):
            if self.training and self.dropout_samples > 1:
                repeated = pooled.unsqueeze(1).expand(
                    -1, self.dropout_samples, -1
                )
                repeated = self.dropout(repeated)
                logits = self.regressor(repeated).squeeze(-1).mean(dim=1)
            else:
                logits = self.regressor(self.dropout(pooled)).squeeze(-1)
        return SimpleNamespace(logits=logits.unsqueeze(-1))

    def save_pretrained(
        self,
        save_directory: str | Path,
        safe_serialization: bool = True,
    ) -> None:
        output_dir = Path(save_directory)
        output_dir.mkdir(parents=True, exist_ok=True)
        self.backbone.save_pretrained(
            output_dir,
            safe_serialization=safe_serialization,
        )
        torch.save(
            {
                "regressor": self.regressor.state_dict(),
                "feature_norm": self.feature_norm.state_dict(),
                "attention_weights": self.attention_weights.state_dict(),
                "dropout": self.dropout.p,
                "dropout_samples": self.dropout_samples,
                "num_layers": self.num_layers,
                "num_heads": self.num_heads,
                "pooling_strategy": "multilayer_head_attention",
            },
            output_dir / "regressor_head.pt",
        )


def load_mean_pooling_regressor(
    model_name_or_path: str | Path,
    dropout: float = 0.1,
    load_head: bool = False,
) -> MeanPoolingRegressor:
    backbone = AutoModel.from_pretrained(
        model_name_or_path,
        dtype=torch.float32,
    )
    model = MeanPoolingRegressor(backbone=backbone, dropout=dropout)
    head_path = Path(model_name_or_path) / "regressor_head.pt"
    if load_head and head_path.exists():
        state = torch.load(head_path, map_location="cpu", weights_only=False)
        model.regressor.load_state_dict(state["regressor"])
        model.dropout.p = float(state.get("dropout", dropout))
    return model


def load_multilayer_attention_regressor(
    model_name_or_path: str | Path,
    num_layers: int = 4,
    dropout: float = 0.1,
    dropout_samples: int = 4,
    load_head: bool = False,
) -> MultiLayerAttentionPoolingRegressor:
    backbone = AutoModel.from_pretrained(
        model_name_or_path,
        dtype=torch.float32,
    )
    head_path = Path(model_name_or_path) / "regressor_head.pt"
    state = None
    if load_head and head_path.exists():
        state = torch.load(head_path, map_location="cpu", weights_only=False)
        num_layers = int(state.get("num_layers", num_layers))
        dropout = float(state.get("dropout", dropout))
        dropout_samples = int(
            state.get("dropout_samples", dropout_samples)
        )
    model = MultiLayerAttentionPoolingRegressor(
        backbone=backbone,
        num_layers=num_layers,
        dropout=dropout,
        dropout_samples=dropout_samples,
    )
    if state is not None:
        model.regressor.load_state_dict(state["regressor"])
        model.feature_norm.load_state_dict(state["feature_norm"])
        model.attention_weights.load_state_dict(state["attention_weights"])
    return model


def load_multilayer_head_attention_regressor(
    model_name_or_path: str | Path,
    num_layers: int = 4,
    num_heads: int = 12,
    dropout: float = 0.1,
    dropout_samples: int = 4,
    load_head: bool = False,
) -> MultiLayerHeadAttentionPoolingRegressor:
    backbone = AutoModel.from_pretrained(
        model_name_or_path,
        dtype=torch.float32,
    )
    head_path = Path(model_name_or_path) / "regressor_head.pt"
    state = None
    if load_head and head_path.exists():
        state = torch.load(head_path, map_location="cpu", weights_only=False)
        num_layers = int(state.get("num_layers", num_layers))
        num_heads = int(state.get("num_heads", num_heads))
        dropout = float(state.get("dropout", dropout))
        dropout_samples = int(
            state.get("dropout_samples", dropout_samples)
        )
    model = MultiLayerHeadAttentionPoolingRegressor(
        backbone=backbone,
        num_layers=num_layers,
        num_heads=num_heads,
        dropout=dropout,
        dropout_samples=dropout_samples,
    )
    if state is not None:
        model.regressor.load_state_dict(state["regressor"])
        model.feature_norm.load_state_dict(state["feature_norm"])
        model.attention_weights.load_state_dict(state["attention_weights"])
    return model
