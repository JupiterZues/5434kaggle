"""Augment a clean source-label sample while preserving its validation rows."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


MODEL_COLUMNS = [
    "id",
    "title",
    "user_id",
    "comment",
    "prod_id",
    "parent_prod_id",
    "time",
    "votes",
    "purchased",
    "rating",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-sample", required=True)
    parser.add_argument("--full-matched", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--per-class", type=int, default=400_000)
    parser.add_argument("--group-val-bucket", type=int, default=0)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--label-col", default="source_rating")
    args = parser.parse_args()

    base = pd.read_csv(args.base_sample)
    base["rating"] = base["rating"].astype(np.float32)
    base_train = base[base["split"] == "train"]
    base_counts = {
        int(round(rating)): int(count)
        for rating, count in base_train["rating"].value_counts().sort_index().items()
    }

    full = pd.read_csv(
        args.full_matched,
        usecols=[
            *MODEL_COLUMNS,
            args.label_col,
        ],
    )
    full = full.dropna(subset=[args.label_col]).copy()
    full = full[full[args.label_col].between(1, 5)].copy()
    full["rating"] = full[args.label_col].astype(np.float32)
    full = full.drop(columns=[args.label_col])

    full["user_id"] = full["user_id"].fillna("").astype(str)
    full["user_bucket"] = (
        pd.util.hash_pandas_object(full["user_id"], index=False) % 20
    ).astype(np.int16)
    combined_text = (
        full["title"].fillna("").astype(str)
        + "\x1f"
        + full["comment"].fillna("").astype(str)
    )
    full["text_bucket"] = (
        pd.util.hash_pandas_object(combined_text, index=False) % 20
    ).astype(np.int16)

    base_ids = set(base["id"].astype(int).tolist())
    full = full[~full["id"].astype(int).isin(base_ids)]
    full = full[
        (full["user_bucket"] != args.group_val_bucket)
        & (full["text_bucket"] != args.group_val_bucket)
    ]

    extra_parts = []
    extra_counts: dict[int, int] = {}
    for rating, group in full.groupby("rating", sort=True):
        target = max(0, args.per_class - base_counts.get(int(rating), 0))
        take = min(target, len(group))
        if take:
            sampled = group.sample(n=take, random_state=args.seed + int(rating))
            extra_parts.append(sampled)
        extra_counts[int(rating)] = int(take)
        print(
            f"rating={int(rating)} available={len(group):,} "
            f"additional={take:,} base={base_counts.get(int(rating), 0):,}",
            flush=True,
        )

    extra = (
        pd.concat(extra_parts, ignore_index=True)
        if extra_parts
        else pd.DataFrame(columns=[*MODEL_COLUMNS, "user_bucket", "text_bucket"])
    )
    extra["split"] = "train"

    columns = [*MODEL_COLUMNS, "user_bucket", "text_bucket", "split"]
    output = pd.concat(
        [base[columns], extra[columns]],
        ignore_index=True,
    ).sort_values("id")
    output = output.drop_duplicates(subset=["id"], keep="first").reset_index(
        drop=True
    )

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(output_path, index=False)
    split_counts = (
        output.assign(rating_round=output["rating"].round().astype(int))
        .groupby(["split", "rating_round"])
        .size()
        .unstack(fill_value=0)
        .sort_index()
    )
    report = {
        "base_sample": args.base_sample,
        "full_matched": args.full_matched,
        "output": str(output_path),
        "per_class_target": args.per_class,
        "base_train_rating_counts": {
            str(key): value for key, value in base_counts.items()
        },
        "additional_train_rating_counts": {
            str(key): value for key, value in extra_counts.items()
        },
        "rows": int(len(output)),
        "split_counts_by_rating": {
            split: {str(key): int(value) for key, value in row.items()}
            for split, row in split_counts.iterrows()
        },
        "validation_ids_preserved": True,
        "additional_rows_exclude_group_bucket": args.group_val_bucket,
    }
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
