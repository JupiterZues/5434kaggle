"""Replace predictions with explicit numeric ratings in review titles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


STAR_PATTERNS = {
    "one star": 1,
    "1 star": 1,
    "two stars": 2,
    "2 stars": 2,
    "three stars": 3,
    "3 stars": 3,
    "four stars": 4,
    "4 stars": 4,
    "five stars": 5,
    "5 stars": 5,
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prediction", required=True)
    parser.add_argument("--test", default="input/test.csv")
    parser.add_argument("--sample-submission", default="input/sampleSubmission.csv")
    parser.add_argument("--output", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--max-distance", type=float, default=float("inf"))
    args = parser.parse_args()

    prediction = pd.read_csv(args.prediction)
    test = pd.read_csv(args.test, usecols=["id", "title"])
    sample = pd.read_csv(args.sample_submission)
    if not np.array_equal(prediction["id"].to_numpy(), sample["id"].to_numpy()):
        raise RuntimeError("Prediction ID order does not match sample submission.")

    frame = prediction.merge(test, on="id", how="left", validate="one_to_one")
    normalized = (
        frame["title"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.lower()
        .str.replace(r"\s+", " ", regex=True)
    )
    expected = normalized.map(STAR_PATTERNS)
    distance = (frame["rating"] - expected).abs()
    mask = expected.notna() & distance.le(args.max_distance)
    before = frame["rating"].to_numpy(dtype=np.float64).copy()
    frame.loc[mask, "rating"] = expected.loc[mask].astype(float)
    after = frame["rating"].to_numpy(dtype=np.float64)

    output = frame[["id", "rating"]]
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(output_path, index=False)
    report = {
        "prediction": args.prediction,
        "output": str(output_path),
        "rows": int(len(frame)),
        "exact_star_rows": int(mask.sum()),
        "exact_star_candidates": int(expected.notna().sum()),
        "max_distance": args.max_distance,
        "exact_star_share": float(mask.mean()),
        "changed_rows": int(np.sum(before != after)),
        "changed_row_share": float(np.mean(before != after)),
        "prediction_mean_before": float(np.mean(before)),
        "prediction_mean_after": float(np.mean(after)),
    }
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
