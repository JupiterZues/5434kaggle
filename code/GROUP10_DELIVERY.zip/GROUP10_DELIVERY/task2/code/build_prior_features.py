"""Build leak-safe historical-rating features for validation and test rows."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def add_target_encoding(
    source: pd.DataFrame,
    target: pd.DataFrame,
    key: str,
    prefix: str,
    prior_mean: float,
    smoothing: float,
    weights: np.ndarray | None = None,
) -> pd.DataFrame:
    values = source[[key, "rating"]].copy()
    values[key] = values[key].fillna("<MISSING>").astype(str)
    if weights is None:
        values["sample_weight"] = 1.0
    else:
        values["sample_weight"] = weights
    values["weighted_rating"] = values["rating"] * values["sample_weight"]
    values["weighted_squared_rating"] = (
        values["rating"] ** 2 * values["sample_weight"]
    )
    stats = (
        values.groupby(key, dropna=False)
        .agg(
            effective_count=("sample_weight", "sum"),
            weighted_rating=("weighted_rating", "sum"),
            weighted_squared_rating=("weighted_squared_rating", "sum"),
        )
        .reset_index()
    )
    stats["weighted_variance"] = (
        stats["weighted_squared_rating"] / stats["effective_count"].clip(lower=1e-8)
        - (stats["weighted_rating"] / stats["effective_count"].clip(lower=1e-8))
        ** 2
    ).clip(lower=0.0)
    stats[f"{prefix}_te"] = (
        stats["weighted_rating"] + prior_mean * smoothing
    ) / (stats["effective_count"] + smoothing)
    stats[f"{prefix}_count"] = stats["effective_count"]
    stats[f"{prefix}_std"] = np.sqrt(stats["weighted_variance"])
    stats = stats[
        [key, f"{prefix}_te", f"{prefix}_count", f"{prefix}_std"]
    ]

    merged = target.merge(stats, on=key, how="left")
    merged[f"{prefix}_count"] = merged[f"{prefix}_count"].fillna(0.0)
    merged[f"{prefix}_te"] = merged[f"{prefix}_te"].fillna(prior_mean)
    merged[f"{prefix}_std"] = merged[f"{prefix}_std"].fillna(0.0)
    merged[f"{prefix}_log_count"] = np.log1p(merged[f"{prefix}_count"])
    return merged


def add_direct_features(frame: pd.DataFrame) -> pd.DataFrame:
    output = frame.copy()
    title = output["title"].fillna("").astype(str)
    comment = output["comment"].fillna("").astype(str)
    output["title_length"] = title.str.len()
    output["comment_length"] = comment.str.len()
    output["combined_length"] = output["title_length"] + output["comment_length"]
    output["log_votes"] = np.log1p(output["votes"].clip(lower=0))
    output["purchased_int"] = output["purchased"].astype(bool).astype(np.int8)
    timestamps = pd.to_datetime(output["time"], unit="ms", errors="coerce")
    output["year"] = timestamps.dt.year
    output["month"] = timestamps.dt.month
    output["dayofweek"] = timestamps.dt.day_of_week
    output["year_month_index"] = (
        timestamps.dt.year * 12 + timestamps.dt.month
    )
    return output


def add_rating_distribution(
    source: pd.DataFrame,
    target: pd.DataFrame,
    key: str,
    prefix: str,
) -> pd.DataFrame:
    values = source[[key, "rating"]].copy()
    values[key] = values[key].fillna("<MISSING>").astype(str)
    global_prior = values["rating"].value_counts(normalize=True)
    for rating in range(1, 6):
        values[f"_rating_{rating}"] = (
            values["rating"].round().astype(int).eq(rating).astype(float)
        )
    stats = values.groupby(key, dropna=False).agg(
        {
            f"_rating_{rating}": "mean" for rating in range(1, 6)
        }
    ).reset_index()
    stats = stats.rename(
        columns={
            f"_rating_{rating}": f"{prefix}_p{rating}"
            for rating in range(1, 6)
        }
    )
    output = target.merge(stats, on=key, how="left")
    for rating in range(1, 6):
        column = f"{prefix}_p{rating}"
        output[column] = output[column].fillna(
            float(global_prior.get(rating, 0.2))
        )
    return output


def build_features(
    source: pd.DataFrame,
    target: pd.DataFrame,
    prior_mean: float,
    smoothing: float,
    weights: np.ndarray | None = None,
) -> pd.DataFrame:
    output = add_direct_features(target)
    source = add_direct_features(source)
    source["user_parent"] = (
        source["user_id"].fillna("").astype(str)
        + "|"
        + source["parent_prod_id"].fillna("").astype(str)
    )
    source["user_product"] = (
        source["user_id"].fillna("").astype(str)
        + "|"
        + source["prod_id"].fillna("").astype(str)
    )
    source["parent_year"] = (
        source["parent_prod_id"].fillna("").astype(str)
        + "|"
        + source["year"].fillna(-1).astype(int).astype(str)
    )
    output["user_parent"] = (
        output["user_id"].fillna("").astype(str)
        + "|"
        + output["parent_prod_id"].fillna("").astype(str)
    )
    output["user_product"] = (
        output["user_id"].fillna("").astype(str)
        + "|"
        + output["prod_id"].fillna("").astype(str)
    )
    output["parent_year"] = (
        output["parent_prod_id"].fillna("").astype(str)
        + "|"
        + output["year"].fillna(-1).astype(int).astype(str)
    )
    for key, prefix in (
        ("user_id", "user"),
        ("prod_id", "product"),
        ("parent_prod_id", "parent"),
        ("user_parent", "user_parent"),
        ("user_product", "user_product"),
        ("parent_year", "parent_year"),
    ):
        output[key] = output[key].fillna("<MISSING>").astype(str)
        output = add_target_encoding(
            source,
            output,
            key,
            prefix,
            prior_mean,
            5.0 if key in {"user_parent", "user_product"} else smoothing,
            weights,
        )
    for key, prefix in (
        ("user_id", "user"),
        ("prod_id", "product"),
        ("parent_prod_id", "parent"),
    ):
        output[key] = output[key].fillna("<MISSING>").astype(str)
        output = add_rating_distribution(source, output, key, prefix)
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", default="input/train.csv")
    parser.add_argument(
        "--sample", default="input/model_sample_200k_per_class.csv"
    )
    parser.add_argument("--test", default="input/test.csv")
    parser.add_argument(
        "--sample-report", default="logs/model_sample_report.json"
    )
    parser.add_argument("--output-dir", default="oof")
    parser.add_argument("--smoothing", type=float, default=20.0)
    parser.add_argument("--label-col", default="rating")
    parser.add_argument(
        "--test-source-match", default="oof/source_match_test.csv"
    )
    args = parser.parse_args()

    report = json.loads(Path(args.sample_report).read_text())
    source_counts = {
        int(rating): int(count)
        for rating, count in report["source_rating_counts"].items()
    }
    total_source = sum(source_counts.values())
    natural_ratings = np.arange(1, 6, dtype=np.float64)
    natural_weights = np.array(
        [source_counts[rating] / total_source for rating in range(1, 6)]
    )
    natural_mean = float(np.dot(natural_ratings, natural_weights))

    sample = pd.read_csv(args.sample)
    train = pd.read_csv(
        args.train,
        usecols=[
            "id",
            "title",
            "comment",
            "user_id",
            "prod_id",
            "parent_prod_id",
            "time",
            "votes",
            "purchased",
            args.label_col,
        ],
    )
    train = train.dropna(subset=[args.label_col]).copy()
    train["rating"] = train[args.label_col].astype(np.float32)
    if args.label_col != "rating":
        train = train.drop(columns=[args.label_col])
    train["user_bucket"] = (
        pd.util.hash_pandas_object(
            train["user_id"].fillna("").astype(str), index=False
        )
        % 20
    ).astype(np.int16)
    combined_text = (
        train["title"].fillna("").astype(str)
        + "\x1f"
        + train["comment"].fillna("").astype(str)
    )
    train["text_bucket"] = (
        pd.util.hash_pandas_object(combined_text, index=False) % 20
    ).astype(np.int16)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    validation_ids = set(
        sample.loc[sample["split"].isin(["val_random", "val_group"]), "id"].tolist()
    )
    validation_source = train[
        (~train["id"].isin(validation_ids))
        & (train["user_bucket"] != 0)
        & (train["text_bucket"] != 0)
    ].copy()
    for split in ("val_random", "val_group"):
        target = sample[sample["split"] == split].copy()
        features = build_features(
            validation_source,
            target,
            natural_mean,
            args.smoothing,
        )
        path = output_dir / f"prior_features_{split}.csv"
        features.to_csv(path, index=False)
        print(f"wrote {path} rows={len(features):,}", flush=True)

    test = pd.read_csv(args.test)
    test_source_path = Path(args.test_source_match)
    if test_source_path.exists() and "source_parent_asin" not in test:
        source_match = pd.read_csv(
            test_source_path, usecols=["id", "source_parent_asin"]
        )
        test = test.merge(
            source_match,
            on="id",
            how="left",
            validate="one_to_one",
        )
    test_features = build_features(
        train,
        test,
        natural_mean,
        args.smoothing,
    )
    test_path = output_dir / "prior_features_test.csv"
    test_features.to_csv(test_path, index=False)
    print(f"wrote {test_path} rows={len(test_features):,}", flush=True)


if __name__ == "__main__":
    main()
