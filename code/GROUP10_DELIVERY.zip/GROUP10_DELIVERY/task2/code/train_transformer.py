"""Fine-tune a transformer regressor for the COMP5434 rating task."""

from __future__ import annotations

import argparse
import json
import math
import os
import random
import subprocess
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import LambdaLR
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from transformers import DataCollatorWithPadding
from rating_model import (
    load_mean_pooling_regressor,
    load_multilayer_attention_regressor,
    load_multilayer_head_attention_regressor,
)


os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

STAR_PATTERNS = {
    "one star": 1,
    "1 star": 1,
    "two stars": 2,
    "2 stars": 2,
    "three stars": 3,
    "3 stars": 3,
    "four stars": 4,
    "4 stars": 4,
    "five stars": 5,
    "5 stars": 5,
}


@dataclass
class TrainConfig:
    sample_csv: str = "input/model_sample_100k_per_class.csv"
    sample_report: str = "logs/model_sample_report.json"
    output_dir: str = "models/deberta_v3_base_r1"
    oof_dir: str = "oof"
    log_dir: str = "logs"
    model_name: str = "microsoft/deberta-v3-base"
    max_length: int = 192
    epochs: int = 2
    train_batch_size: int = 32
    eval_batch_size: int = 64
    gradient_accumulation: int = 2
    learning_rate: float = 2e-5
    weight_decay: float = 0.01
    warmup_ratio: float = 0.06
    max_grad_norm: float = 1.0
    log_steps: int = 100
    num_workers: int = 8
    seed: int = 42
    eval_random_cap_per_class: int = 2_000
    eval_group_cap_per_class: int = 2_000
    max_train_per_class: int = 0
    bf16: bool = True
    gradient_checkpointing: bool = True
    class_weighting: str = "none"
    selection_metric: str = "balanced"
    pooling_strategy: str = "mean"
    head_learning_rate: float = 1e-3
    train_target_col: str = "rating"
    num_pool_layers: int = 4
    num_pool_heads: int = 12
    dropout_samples: int = 4
    pooling_dropout: float = 0.1
    random_crop: bool = False
    field_dropout: float = 0.0
    text_window: str = "full"
    save_every_steps: int = 0
    max_steps: int = 0


def parse_args() -> TrainConfig:
    parser = argparse.ArgumentParser()
    for field_name, field_value in asdict(TrainConfig()).items():
        option = "--" + field_name.replace("_", "-")
        if isinstance(field_value, bool):
            parser.add_argument(option, action=argparse.BooleanOptionalAction, default=field_value)
        else:
            parser.add_argument(option, type=type(field_value), default=field_value)
    return TrainConfig(**vars(parser.parse_args()))


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def hardware_metadata() -> dict[str, object]:
    """Capture the hardware fields required by the course report."""
    cpu_model = "unknown"
    try:
        cpu_info = subprocess.run(
            ["lscpu"],
            check=True,
            capture_output=True,
            text=True,
            timeout=10,
        ).stdout
        for line in cpu_info.splitlines():
            if line.startswith("Model name:"):
                cpu_model = line.split(":", 1)[1].strip()
                break
    except (OSError, subprocess.SubprocessError):
        pass

    output: dict[str, object] = {
        "cpu_model": cpu_model,
        "torch_threads": int(torch.get_num_threads()),
        "gpu_count": int(torch.cuda.device_count()),
        "gpu": [],
    }
    for index in range(torch.cuda.device_count()):
        properties = torch.cuda.get_device_properties(index)
        output["gpu"].append(
            {
                "index": index,
                "name": properties.name,
                "memory_gib": round(
                    properties.total_memory / 1024**3, 2
                ),
            }
        )
    return output


def review_text(title: object, comment: object) -> str:
    title_text = "" if pd.isna(title) else str(title)
    comment_text = "" if pd.isna(comment) else str(comment)
    return f"{title_text}\n{comment_text}".strip()


class ReviewDataset(Dataset):
    def __init__(
        self,
        frame: pd.DataFrame,
        tokenizer: AutoTokenizer,
        max_length: int,
        target_column: str = "rating",
        random_crop: bool = False,
        field_dropout: float = 0.0,
        text_window: str = "full",
    ) -> None:
        self.ids = frame["id"].to_numpy()
        self.titles = frame["title"].tolist()
        self.comments = frame["comment"].tolist()
        self.ratings = frame[target_column].to_numpy(dtype=np.float32)
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.random_crop = random_crop
        self.field_dropout = field_dropout
        if text_window not in {"full", "head", "tail", "head_tail"}:
            raise ValueError(f"Unsupported text_window={text_window!r}")
        self.text_window = text_window

    def __len__(self) -> int:
        return len(self.ratings)

    def __getitem__(self, index: int) -> dict[str, object]:
        title = "" if pd.isna(self.titles[index]) else str(self.titles[index])
        comment = (
            "" if pd.isna(self.comments[index]) else str(self.comments[index])
        )
        if self.field_dropout > 0 and random.random() < self.field_dropout:
            if random.random() < 0.5:
                title = ""
            else:
                comment = ""
        if self.random_crop and len(comment) > self.max_length * 4:
            window = self.max_length * 4
            if random.random() < 0.5:
                comment = comment[-window:]
            else:
                comment = comment[:window]
        elif self.text_window != "full" and len(comment) > self.max_length * 4:
            window = self.max_length * 4
            if self.text_window == "head":
                comment = comment[:window]
            elif self.text_window == "tail":
                comment = comment[-window:]
            else:
                half = window // 2
                comment = f"{comment[:half]} ... {comment[-half:]}"
        text = f"{title}\n{comment}".strip()
        encoded = self.tokenizer(
            text,
            truncation=True,
            max_length=self.max_length,
            add_special_tokens=True,
        )
        encoded["target"] = float(self.ratings[index])
        encoded["id"] = int(self.ids[index])
        return encoded


def limit_per_class(
    frame: pd.DataFrame, cap_per_class: int, seed: int
) -> pd.DataFrame:
    parts = []
    for rating, group in frame.groupby("rating", sort=True):
        if len(group) > cap_per_class:
            group = group.sample(
                n=cap_per_class,
                random_state=seed + int(rating) * 101,
            )
        parts.append(group)
    return pd.concat(parts, ignore_index=True)


def make_optimizer_and_scheduler(
    model: torch.nn.Module,
    total_steps: int,
    config: TrainConfig,
) -> tuple[AdamW, LambdaLR]:
    head_parameters = []
    backbone_parameters = []
    for name, parameter in model.named_parameters():
        is_head = (
            name.startswith("regressor")
            or name.startswith("feature_norm")
            or name.startswith("attention_weights")
            or ".classifier." in f".{name}."
            or ".pooler." in f".{name}."
        )
        if is_head:
            head_parameters.append(parameter)
        else:
            backbone_parameters.append(parameter)
    parameter_groups = [
        {
            "params": backbone_parameters,
            "lr": config.learning_rate,
            "weight_decay": config.weight_decay,
        }
    ]
    if head_parameters:
        parameter_groups.append(
            {
                "params": head_parameters,
                "lr": config.head_learning_rate,
                "weight_decay": config.weight_decay,
            }
        )
    optimizer = AdamW(
        parameter_groups,
        betas=(0.9, 0.999),
        eps=1e-8,
        fused=torch.cuda.is_available(),
    )
    warmup_steps = int(total_steps * config.warmup_ratio)

    def schedule(step: int) -> float:
        if step < warmup_steps:
            return float(step + 1) / max(1, warmup_steps)
        progress = float(step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 0.5 * (1.0 + math.cos(math.pi * min(1.0, progress)))

    return optimizer, LambdaLR(optimizer, schedule)


def autocast_context(enabled: bool):
    if enabled and torch.cuda.is_available():
        return torch.autocast(device_type="cuda", dtype=torch.bfloat16)
    return torch.autocast(device_type="cpu", enabled=False)


def move_batch(batch: dict[str, object], device: torch.device) -> dict[str, torch.Tensor]:
    return {
        key: value.to(device, non_blocking=True)
        for key, value in batch.items()
        if key not in {"id", "target"}
    }


@torch.inference_mode()
def evaluate(
    model: torch.nn.Module,
    loader: DataLoader,
    device: torch.device,
    use_bf16: bool,
    natural_prior: dict[int, float] | None = None,
) -> tuple[dict[str, float], pd.DataFrame]:
    model.eval()
    ids: list[np.ndarray] = []
    targets: list[np.ndarray] = []
    predictions: list[np.ndarray] = []

    for batch in loader:
        inputs = move_batch(batch, device)
        with autocast_context(use_bf16):
            logits = model(**inputs).logits.squeeze(-1)
        ids.append(batch["id"].cpu().numpy())
        targets.append(batch["target"].cpu().numpy())
        predictions.append(logits.float().cpu().numpy())

    id_array = np.concatenate(ids)
    target_array = np.concatenate(targets).astype(np.float64)
    prediction_array = np.concatenate(predictions).astype(np.float64)
    clipped = np.clip(prediction_array, 1.0, 5.0)
    rounded = np.clip(np.rint(prediction_array), 1, 5)
    errors = clipped - target_array
    if np.std(clipped) <= 1e-12 or np.std(target_array) <= 1e-12:
        pearson = 0.0
    else:
        pearson = float(np.corrcoef(clipped, target_array)[0, 1])
    metrics = {
        "rmse_raw": float(np.sqrt(np.mean((prediction_array - target_array) ** 2))),
        "rmse": float(np.sqrt(np.mean(errors**2))),
        "mae": float(np.mean(np.abs(errors))),
        "rounded_accuracy": float(np.mean(rounded == target_array)),
        "pearson": pearson,
        "mean_prediction": float(np.mean(clipped)),
        "mean_target": float(np.mean(target_array)),
    }
    if natural_prior:
        observed_counts = {
            rating: int(np.sum(target_array == rating)) for rating in range(1, 6)
        }
        valid_ratings = [
            rating
            for rating in range(1, 6)
            if observed_counts[rating] > 0 and natural_prior.get(rating, 0.0) > 0
        ]
        if valid_ratings:
            weights = np.array(
                [
                    natural_prior[rating] / observed_counts[rating]
                    for rating in valid_ratings
                ],
                dtype=np.float64,
            )
            squared_errors = np.array(
                [
                    np.mean(errors[target_array == rating] ** 2)
                    for rating in valid_ratings
                ],
                dtype=np.float64,
            )
            absolute_errors = np.array(
                [
                    np.mean(np.abs(errors[target_array == rating]))
                    for rating in valid_ratings
                ],
                dtype=np.float64,
            )
            weights = weights / weights.sum()
            metrics["rmse_natural_prior"] = float(
                np.sqrt(np.sum(weights * squared_errors))
            )
            metrics["mae_natural_prior"] = float(
                np.sum(weights * absolute_errors)
            )
    output = pd.DataFrame(
        {
            "id": id_array,
            "rating": target_array,
            "prediction": clipped,
        }
    )
    return metrics, output


def append_jsonl(path: Path, record: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def clean_star_ids(frame: pd.DataFrame) -> set[int]:
    titles = (
        frame["title"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.lower()
        .str.replace(r"\s+", " ", regex=True)
    )
    expected = titles.map(STAR_PATTERNS)
    mask = expected.notna() & (frame["rating"] == expected)
    return set(frame.loc[mask, "id"].astype(int).tolist())


def add_clean_star_metric(
    metrics: dict[str, float],
    oof: pd.DataFrame,
    clean_ids: set[int],
) -> None:
    mask = oof["id"].astype(int).isin(clean_ids)
    if mask.any():
        errors = oof.loc[mask, "prediction"] - oof.loc[mask, "rating"]
        metrics["clean_star_rows"] = float(mask.sum())
        metrics["rmse_clean_star"] = float(np.sqrt(np.mean(errors**2)))
    else:
        metrics["clean_star_rows"] = 0.0
        metrics["rmse_clean_star"] = float("nan")


def train(config: TrainConfig) -> None:
    set_seed(config.seed)
    output_dir = Path(config.output_dir)
    oof_dir = Path(config.oof_dir)
    log_dir = Path(config.log_dir)
    best_dir = output_dir / "best"
    output_dir.mkdir(parents=True, exist_ok=True)
    oof_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)

    metrics_path = log_dir / f"{output_dir.name}_metrics.jsonl"
    experiment_path = log_dir / f"{output_dir.name}_experiment_log.json"
    metrics_path.write_text("")

    metadata: dict[str, object] = {
        "run_id": output_dir.name,
        "status": "running",
        "config": asdict(config),
        "started_at": pd.Timestamp.now(tz="UTC").isoformat(),
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "hardware": hardware_metadata(),
    }
    experiment_path.write_text(json.dumps(metadata, indent=2) + "\n")

    try:
        frame = pd.read_csv(config.sample_csv)
        required = {"id", "title", "comment", "rating", "split"}
        missing = required - set(frame.columns)
        if missing:
            raise RuntimeError(f"Missing sample columns: {sorted(missing)}")

        train_frame = frame[frame["split"] == "train"].reset_index(drop=True)
        if config.max_train_per_class > 0:
            train_frame = limit_per_class(
                train_frame,
                config.max_train_per_class,
                config.seed + 7,
            ).reset_index(drop=True)
        random_val = limit_per_class(
            frame[frame["split"] == "val_random"].reset_index(drop=True),
            config.eval_random_cap_per_class,
            config.seed,
        )
        group_val = limit_per_class(
            frame[frame["split"] == "val_group"].reset_index(drop=True),
            config.eval_group_cap_per_class,
            config.seed + 1,
        )
        if train_frame.empty or random_val.empty or group_val.empty:
            raise RuntimeError("One or more required splits are empty.")
        clean_random_ids = clean_star_ids(random_val)
        clean_group_ids = clean_star_ids(group_val)

        natural_prior = None
        report_path = Path(config.sample_report)
        if report_path.exists():
            report = json.loads(report_path.read_text())
            source_counts = {
                int(rating): int(count)
                for rating, count in report.get("source_rating_counts", {}).items()
            }
            total_source_rows = sum(source_counts.values())
            if total_source_rows:
                natural_prior = {
                    rating: source_counts.get(rating, 0) / total_source_rows
                    for rating in range(1, 6)
                }
                metadata["natural_rating_prior"] = natural_prior

        if config.class_weighting not in {"none", "natural"}:
            raise ValueError(
                "--class-weighting must be either 'none' or 'natural'."
            )
        if config.class_weighting == "natural" and natural_prior is None:
            raise RuntimeError(
                "Natural class weighting requires a valid sample report with source counts."
            )
        if config.selection_metric not in {"balanced", "natural", "clean"}:
            raise ValueError(
                "--selection-metric must be one of "
                "'balanced', 'natural', or 'clean'."
            )
        if config.selection_metric == "natural" and natural_prior is None:
            raise RuntimeError(
                "Natural selection requires a valid sample report with source counts."
            )
        class_weights = None
        if config.class_weighting == "natural":
            class_weights = torch.tensor(
                [
                    natural_prior[rating] / 0.2
                    for rating in range(1, 6)
                ],
                dtype=torch.float32,
                device="cpu",
            )
            metadata["class_weights"] = class_weights.tolist()

        metadata["train_rows"] = int(len(train_frame))
        metadata["random_val_rows"] = int(len(random_val))
        metadata["group_val_rows"] = int(len(group_val))
        metadata["train_rating_counts"] = {
            str(k): int(v) for k, v in train_frame["rating"].value_counts().sort_index().items()
        }
        experiment_path.write_text(json.dumps(metadata, indent=2) + "\n")

        tokenizer = AutoTokenizer.from_pretrained(config.model_name)
        if config.pooling_strategy == "mean":
            checkpoint_head = Path(config.model_name) / "regressor_head.pt"
            model = load_mean_pooling_regressor(
                config.model_name,
                dropout=config.pooling_dropout,
                load_head=checkpoint_head.exists(),
            )
        elif config.pooling_strategy == "classifier":
            model = AutoModelForSequenceClassification.from_pretrained(
                config.model_name,
                num_labels=1,
                problem_type="regression",
            )
        elif config.pooling_strategy == "multilayer_attention":
            checkpoint_head = Path(config.model_name) / "regressor_head.pt"
            model = load_multilayer_attention_regressor(
                config.model_name,
                num_layers=config.num_pool_layers,
                dropout=config.pooling_dropout,
                dropout_samples=config.dropout_samples,
                load_head=checkpoint_head.exists(),
            )
        elif config.pooling_strategy == "multilayer_head_attention":
            checkpoint_head = Path(config.model_name) / "regressor_head.pt"
            model = load_multilayer_head_attention_regressor(
                config.model_name,
                num_layers=config.num_pool_layers,
                num_heads=config.num_pool_heads,
                dropout=config.pooling_dropout,
                dropout_samples=config.dropout_samples,
                load_head=checkpoint_head.exists(),
            )
        else:
            raise ValueError(
                "--pooling-strategy must be one of "
                "'mean', 'classifier', 'multilayer_attention', or "
                "'multilayer_head_attention'."
            )
        if config.gradient_checkpointing:
            model.gradient_checkpointing_enable()
            model.config.use_cache = False

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model.to(device)
        use_bf16 = config.bf16 and device.type == "cuda" and torch.cuda.is_bf16_supported()

        train_dataset = ReviewDataset(
            train_frame,
            tokenizer,
            config.max_length,
            target_column=config.train_target_col,
            random_crop=config.random_crop,
            field_dropout=config.field_dropout,
            text_window=config.text_window,
        )
        random_dataset = ReviewDataset(
            random_val,
            tokenizer,
            config.max_length,
            target_column="rating",
            text_window=config.text_window,
        )
        group_dataset = ReviewDataset(
            group_val,
            tokenizer,
            config.max_length,
            target_column="rating",
            text_window=config.text_window,
        )
        collator = DataCollatorWithPadding(tokenizer=tokenizer)
        generator = torch.Generator()
        generator.manual_seed(config.seed)

        train_loader = DataLoader(
            train_dataset,
            batch_size=config.train_batch_size,
            shuffle=True,
            num_workers=config.num_workers,
            pin_memory=True,
            persistent_workers=config.num_workers > 0,
            collate_fn=collator,
            generator=generator,
        )
        random_loader = DataLoader(
            random_dataset,
            batch_size=config.eval_batch_size,
            shuffle=False,
            num_workers=config.num_workers,
            pin_memory=True,
            persistent_workers=config.num_workers > 0,
            collate_fn=collator,
        )
        group_loader = DataLoader(
            group_dataset,
            batch_size=config.eval_batch_size,
            shuffle=False,
            num_workers=config.num_workers,
            pin_memory=True,
            persistent_workers=config.num_workers > 0,
            collate_fn=collator,
        )

        updates_per_epoch = math.ceil(
            len(train_loader) / config.gradient_accumulation
        )
        total_steps = updates_per_epoch * config.epochs
        if config.max_steps > 0:
            total_steps = min(total_steps, config.max_steps)
        optimizer, scheduler = make_optimizer_and_scheduler(model, total_steps, config)

        best_score = float("inf")
        global_step = 0
        for epoch in range(1, config.epochs + 1):
            model.train()
            epoch_start = time.monotonic()
            optimizer.zero_grad(set_to_none=True)
            running_loss = 0.0
            running_count = 0
            reached_step_limit = False

            for batch_index, batch in enumerate(train_loader, start=1):
                inputs = move_batch(batch, device)
                targets = batch["target"].to(device, non_blocking=True).float()
                with autocast_context(use_bf16):
                    logits = model(**inputs).logits.squeeze(-1)
                    squared_error = F.mse_loss(
                        logits.float(), targets, reduction="none"
                    )
                    if class_weights is None:
                        loss = squared_error.mean()
                    else:
                        label_indices = (
                            targets.round().long().sub(1).clamp(0, 4)
                        )
                        sample_weights = class_weights.to(
                            device=targets.device, non_blocking=True
                        )[label_indices]
                        loss = (
                            squared_error * sample_weights
                        ).sum() / sample_weights.sum().clamp_min(1e-8)
                scaled_loss = loss / config.gradient_accumulation
                scaled_loss.backward()
                running_loss += float(loss.detach()) * len(targets)
                running_count += len(targets)

                if (
                    batch_index % config.gradient_accumulation == 0
                    or batch_index == len(train_loader)
                ):
                    torch.nn.utils.clip_grad_norm_(
                        model.parameters(), config.max_grad_norm
                    )
                    optimizer.step()
                    scheduler.step()
                    optimizer.zero_grad(set_to_none=True)
                    global_step += 1

                    if global_step % config.log_steps == 0:
                        record = {
                            "event": "train",
                            "epoch": epoch,
                            "global_step": global_step,
                            "train_mse": float(loss.detach()),
                            "running_mse": running_loss / max(1, running_count),
                            "learning_rate": scheduler.get_last_lr()[0],
                            "elapsed_seconds": time.monotonic() - epoch_start,
                        }
                        append_jsonl(metrics_path, record)
                        print(json.dumps(record), flush=True)
                    if (
                        config.save_every_steps > 0
                        and global_step % config.save_every_steps == 0
                    ):
                        step_dir = output_dir / f"step-{global_step}"
                        step_dir.mkdir(parents=True, exist_ok=True)
                        model.save_pretrained(
                            step_dir, safe_serialization=True
                        )
                        tokenizer.save_pretrained(step_dir)
                        print(
                            json.dumps(
                                {
                                    "event": "checkpoint",
                                    "global_step": global_step,
                                    "directory": str(step_dir),
                                }
                            ),
                            flush=True,
                        )
                    if global_step >= total_steps:
                        reached_step_limit = True
                        break

            random_metrics, random_oof = evaluate(
                model, random_loader, device, use_bf16, natural_prior
            )
            group_metrics, group_oof = evaluate(
                model, group_loader, device, use_bf16, natural_prior
            )
            add_clean_star_metric(
                random_metrics, random_oof, clean_random_ids
            )
            add_clean_star_metric(
                group_metrics, group_oof, clean_group_ids
            )
            metric_key = {
                "natural": "rmse_natural_prior",
                "clean": "rmse_clean_star",
                "balanced": "rmse",
            }[config.selection_metric]
            selection_score = (
                random_metrics[metric_key] + group_metrics[metric_key]
            ) / 2.0
            epoch_record = {
                "event": "epoch",
                "epoch": epoch,
                "train_loss_mse": running_loss / max(1, running_count),
                "random": random_metrics,
                "group": group_metrics,
                "selection_score": selection_score,
                "elapsed_seconds": time.monotonic() - epoch_start,
            }
            append_jsonl(metrics_path, epoch_record)
            print(json.dumps(epoch_record, indent=2), flush=True)

            random_oof.to_csv(
                oof_dir / f"{output_dir.name}_epoch{epoch}_random.csv",
                index=False,
            )
            group_oof.to_csv(
                oof_dir / f"{output_dir.name}_epoch{epoch}_group.csv",
                index=False,
            )

            if selection_score < best_score:
                best_score = selection_score
                best_dir.mkdir(parents=True, exist_ok=True)
                model.save_pretrained(best_dir, safe_serialization=True)
                tokenizer.save_pretrained(best_dir)
                metadata["best_epoch"] = epoch
                metadata["best_selection_score"] = best_score
                metadata["best_random_metrics"] = random_metrics
                metadata["best_group_metrics"] = group_metrics
                experiment_path.write_text(json.dumps(metadata, indent=2) + "\n")
            if reached_step_limit:
                break

        metadata["status"] = "complete"
        metadata["finished_at"] = pd.Timestamp.now(tz="UTC").isoformat()
        metadata["best_model_dir"] = str(best_dir)
        experiment_path.write_text(json.dumps(metadata, indent=2) + "\n")
    except BaseException as exc:
        metadata["status"] = "failed"
        metadata["finished_at"] = pd.Timestamp.now(tz="UTC").isoformat()
        metadata["error_type"] = type(exc).__name__
        metadata["error"] = str(exc)
        experiment_path.write_text(json.dumps(metadata, indent=2) + "\n")
        raise


if __name__ == "__main__":
    train(parse_args())
