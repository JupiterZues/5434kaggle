"""Evaluate and fit a small OOF stacker using text predictions and side features."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
from catboost import CatBoostRegressor
from scipy.optimize import minimize
from xgboost import XGBRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


FEATURE_COLUMNS = [
    "base_prediction",
    "user_te",
    "user_std",
    "product_te",
    "product_std",
    "parent_te",
    "parent_std",
    "user_parent_te",
    "user_parent_count",
    "user_parent_log_count",
    "user_parent_std",
    "user_product_te",
    "user_product_count",
    "user_product_log_count",
    "user_product_std",
    "parent_year_te",
    "parent_year_count",
    "parent_year_log_count",
    "parent_year_std",
    "user_p1",
    "user_p2",
    "user_p3",
    "user_p4",
    "user_p5",
    "product_p1",
    "product_p2",
    "product_p3",
    "product_p4",
    "product_p5",
    "parent_p1",
    "parent_p2",
    "parent_p3",
    "parent_p4",
    "parent_p5",
    "meta_average_rating",
    "meta_rating_number_log",
    "meta_price_log",
    "meta_title_length",
    "meta_feature_count",
    "meta_feature_chars",
    "meta_description_chars",
    "meta_image_count",
    "meta_video_count",
    "meta_detail_count",
    "meta_store_frequency",
    "meta_category_frequency",
    "meta_store_hash",
    "meta_category_hash",
    "user_log_count",
    "product_log_count",
    "parent_log_count",
    "log_votes",
    "purchased_int",
    "title_length",
    "comment_length",
    "combined_length",
    "year",
    "month",
    "dayofweek",
    "year_month_index",
]


def natural_weights(labels: pd.Series, prior: dict[int, float]) -> np.ndarray:
    shares = labels.value_counts(normalize=True).to_dict()
    mapping = {
        rating: prior[rating] / shares[rating]
        for rating in range(1, 6)
        if shares.get(rating, 0) > 0
    }
    total = sum(mapping.values())
    return labels.map(lambda value: mapping[int(value)] / total).to_numpy()


def weighted_rmse(
    target: np.ndarray, prediction: np.ndarray, weights: np.ndarray
) -> float:
    return float(np.sqrt(np.average((prediction - target) ** 2, weights=weights)))


def merge_metadata(
    features: pd.DataFrame,
    metadata_path: str | None,
) -> pd.DataFrame:
    if not metadata_path:
        return features
    metadata = pd.read_csv(metadata_path)
    metadata["meta_rating_number_log"] = np.log1p(
        pd.to_numeric(metadata["meta_rating_number"], errors="coerce").clip(
            lower=0
        )
    )
    metadata["meta_price_log"] = np.log1p(
        pd.to_numeric(metadata["meta_price"], errors="coerce").clip(lower=0)
    )
    for source_column, prefix in (
        ("meta_store", "meta_store"),
        ("meta_category_leaf", "meta_category"),
    ):
        normalized = metadata[source_column].fillna("").astype(str)
        metadata[f"{prefix}_frequency"] = normalized.map(
            normalized.value_counts(normalize=True)
        ).fillna(0.0)
        metadata[f"{prefix}_hash"] = (
            pd.util.hash_pandas_object(normalized, index=False) % 100_003
        ).astype(np.int32)
    keep = [
        "source_parent_asin",
        *[
            column
            for column in FEATURE_COLUMNS
            if column.startswith("meta_")
        ],
    ]
    return features.merge(
        metadata[keep],
        on="source_parent_asin",
        how="left",
        validate="many_to_one",
    )


def load_split(
    base_path: str,
    feature_path: str,
    metadata_path: str | None = None,
) -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    base = pd.read_csv(base_path)
    features = pd.read_csv(feature_path)
    features = merge_metadata(features, metadata_path)
    frame = features.merge(
        base[["id", "prediction"]].rename(
            columns={"prediction": "base_prediction"}
        ),
        on="id",
        how="inner",
        validate="one_to_one",
    )
    if len(frame) != len(base):
        raise RuntimeError("Base OOF rows could not all be aligned to side features.")
    expected = [
        column
        for column in FEATURE_COLUMNS
        if metadata_path or not column.startswith("meta_")
    ]
    available = [column for column in expected if column in frame.columns]
    missing = set(expected) - set(available)
    if missing:
        raise RuntimeError(f"Missing stacker features: {sorted(missing)}")
    x = (
        frame[available]
        .replace([np.inf, -np.inf], np.nan)
        .fillna(frame[available].median(numeric_only=True))
    )
    return frame, x.to_numpy(dtype=np.float32), frame["rating"].to_numpy(dtype=np.float64)


def fit_and_score(
    model_name: str,
    train_x: np.ndarray,
    train_y: np.ndarray,
    train_weights: np.ndarray,
    eval_x: np.ndarray,
    eval_y: np.ndarray,
    eval_weights: np.ndarray,
    seed: int,
) -> tuple[float, object]:
    if model_name == "ridge":
        model = make_pipeline(StandardScaler(), Ridge(alpha=10.0))
        model.fit(train_x, train_y, ridge__sample_weight=train_weights)
    elif model_name == "lgbm":
        model = lgb.LGBMRegressor(
            objective="regression",
            n_estimators=400,
            learning_rate=0.025,
            num_leaves=15,
            min_child_samples=500,
            subsample=0.8,
            colsample_bytree=0.8,
            reg_lambda=5.0,
            random_state=seed,
            n_jobs=4,
            verbosity=-1,
        )
        model.fit(
            train_x,
            train_y,
            sample_weight=train_weights,
        )
    elif model_name == "cat":
        model = CatBoostRegressor(
            loss_function="RMSE",
            iterations=600,
            depth=6,
            learning_rate=0.03,
            l2_leaf_reg=5.0,
            random_seed=seed,
            thread_count=4,
            verbose=False,
            allow_writing_files=False,
        )
        model.fit(
            train_x,
            train_y,
            sample_weight=train_weights,
        )
    elif model_name == "xgb":
        model = XGBRegressor(
            objective="reg:squarederror",
            n_estimators=500,
            max_depth=6,
            learning_rate=0.03,
            subsample=0.8,
            colsample_bytree=0.8,
            min_child_weight=10,
            reg_lambda=5.0,
            random_state=seed,
            n_jobs=4,
            tree_method="hist",
        )
        model.fit(
            train_x,
            train_y,
            sample_weight=train_weights,
        )
    else:
        raise ValueError(model_name)
    prediction = np.clip(model.predict(eval_x), 1.0, 5.0)
    return weighted_rmse(eval_y, prediction, eval_weights), model


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--random-oof", required=True)
    parser.add_argument("--group-oof", required=True)
    parser.add_argument(
        "--random-features", default="oof/prior_features_val_random.csv"
    )
    parser.add_argument(
        "--group-features", default="oof/prior_features_val_group.csv"
    )
    parser.add_argument("--test-features", default="oof/prior_features_test.csv")
    parser.add_argument("--metadata-features")
    parser.add_argument("--test-base-prediction")
    parser.add_argument("--output")
    parser.add_argument("--oof-output")
    parser.add_argument("--report", default="logs/stack_side_features.json")
    parser.add_argument(
        "--sample-report", default="logs/model_sample_report.json"
    )
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    report = json.loads(Path(args.sample_report).read_text())
    source_counts = {
        int(rating): int(count)
        for rating, count in report["source_rating_counts"].items()
    }
    total_source = sum(source_counts.values())
    prior = {
        rating: source_counts[rating] / total_source for rating in range(1, 6)
    }

    random_frame, random_x, random_y = load_split(
        args.random_oof, args.random_features, args.metadata_features
    )
    group_frame, group_x, group_y = load_split(
        args.group_oof, args.group_features, args.metadata_features
    )
    random_weights = natural_weights(random_frame["rating"], prior)
    group_weights = natural_weights(group_frame["rating"], prior)

    base_random = weighted_rmse(
        random_y,
        np.clip(random_frame["base_prediction"].to_numpy(), 1.0, 5.0),
        random_weights,
    )
    base_group = weighted_rmse(
        group_y,
        np.clip(group_frame["base_prediction"].to_numpy(), 1.0, 5.0),
        group_weights,
    )

    results: dict[str, object] = {
        "base": {
            "random_natural_rmse": base_random,
            "group_natural_rmse": base_group,
            "average_natural_rmse": (base_random + base_group) / 2.0,
        },
        "rows": {
            "random": int(len(random_frame)),
            "group": int(len(group_frame)),
        },
        "models": {},
    }

    candidate_models: dict[str, object] = {}
    cross_models: dict[str, tuple[object, object]] = {}
    for model_name in ("ridge", "lgbm", "cat", "xgb"):
        random_to_group, random_to_group_model = fit_and_score(
            model_name,
            random_x,
            random_y,
            random_weights,
            group_x,
            group_y,
            group_weights,
            args.seed,
        )
        group_to_random, group_to_random_model = fit_and_score(
            model_name,
            group_x,
            group_y,
            group_weights,
            random_x,
            random_y,
            random_weights,
            args.seed,
        )
        results["models"][model_name] = {
            "fit_random_eval_group_natural_rmse": random_to_group,
            "fit_group_eval_random_natural_rmse": group_to_random,
            "average_natural_rmse": (random_to_group + group_to_random) / 2.0,
        }
        cross_models[model_name] = (
            random_to_group_model,
            group_to_random_model,
        )

        combined_frame = pd.concat(
            [random_frame, group_frame], ignore_index=True
        )
        combined_x = np.concatenate([random_x, group_x], axis=0)
        combined_y = np.concatenate([random_y, group_y], axis=0)
        combined_weights = natural_weights(combined_frame["rating"], prior)
        if model_name == "ridge":
            final_model = make_pipeline(StandardScaler(), Ridge(alpha=10.0))
            final_model.fit(
                combined_x, combined_y, ridge__sample_weight=combined_weights
            )
        elif model_name == "lgbm":
            final_model = lgb.LGBMRegressor(
                objective="regression",
                n_estimators=400,
                learning_rate=0.025,
                num_leaves=15,
                min_child_samples=500,
                subsample=0.8,
                colsample_bytree=0.8,
                reg_lambda=5.0,
                random_state=args.seed,
                n_jobs=4,
                verbosity=-1,
            )
            final_model.fit(
                combined_x, combined_y, sample_weight=combined_weights
            )
        elif model_name == "cat":
            final_model = CatBoostRegressor(
                loss_function="RMSE",
                iterations=600,
                depth=6,
                learning_rate=0.03,
                l2_leaf_reg=5.0,
                random_seed=args.seed,
                thread_count=4,
                verbose=False,
                allow_writing_files=False,
            )
            final_model.fit(
                combined_x,
                combined_y,
                sample_weight=combined_weights,
            )
        else:
            final_model = XGBRegressor(
                objective="reg:squarederror",
                n_estimators=500,
                max_depth=6,
                learning_rate=0.03,
                subsample=0.8,
                colsample_bytree=0.8,
                min_child_weight=10,
                reg_lambda=5.0,
                random_state=args.seed,
                n_jobs=4,
                tree_method="hist",
            )
            final_model.fit(
                combined_x,
                combined_y,
                sample_weight=combined_weights,
            )
        candidate_models[model_name] = final_model

    cross_predictions: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    for model_name, (
        random_to_group_model,
        group_to_random_model,
    ) in cross_models.items():
        cross_predictions[model_name] = (
            np.clip(random_to_group_model.predict(group_x), 1.0, 5.0),
            np.clip(group_to_random_model.predict(random_x), 1.0, 5.0),
        )
    blend_names = ["ridge", "lgbm", "cat", "xgb"]

    def blend_objective(weights_vector: np.ndarray) -> float:
        fold_scores = []
        for fold_index, (target, weights) in enumerate(
            ((group_y, group_weights), (random_y, random_weights))
        ):
            prediction = sum(
                weights_vector[index]
                * cross_predictions[model_name][fold_index]
                for index, model_name in enumerate(blend_names)
            )
            fold_scores.append(weighted_rmse(target, prediction, weights))
        return float(np.mean(fold_scores))

    optimization = minimize(
        blend_objective,
        np.ones(len(blend_names)) / len(blend_names),
        method="SLSQP",
        bounds=[(0.0, 1.0)] * len(blend_names),
        constraints={"type": "eq", "fun": lambda values: values.sum() - 1.0},
        options={"ftol": 1e-12, "maxiter": 1000},
    )
    if not optimization.success:
        raise RuntimeError(f"Blend optimization failed: {optimization.message}")
    blend_weights = optimization.x
    results["selected_model"] = "ridge_lgbm_cat_blend"
    results["blend_weights"] = {
        name: float(weight)
        for name, weight in zip(blend_names, blend_weights)
    }
    results["selected_average_natural_rmse"] = float(optimization.fun)
    results["base_average_natural_rmse"] = results["base"][
        "average_natural_rmse"
    ]
    results["relative_improvement"] = (
        results["base_average_natural_rmse"]
        - results["selected_average_natural_rmse"]
    ) / results["base_average_natural_rmse"]

    if args.oof_output:
        group_prediction = sum(
            blend_weights[index] * cross_predictions[model_name][0]
            for index, model_name in enumerate(blend_names)
        )
        random_prediction = sum(
            blend_weights[index] * cross_predictions[model_name][1]
            for index, model_name in enumerate(blend_names)
        )
        oof = pd.concat(
            [
                pd.DataFrame(
                    {
                        "id": random_frame["id"],
                        "rating": random_frame["rating"],
                        "prediction": random_prediction,
                    }
                ),
                pd.DataFrame(
                    {
                        "id": group_frame["id"],
                        "rating": group_frame["rating"],
                        "prediction": group_prediction,
                    }
                ),
            ],
            ignore_index=True,
        )
        oof_path = Path(args.oof_output)
        oof_path.parent.mkdir(parents=True, exist_ok=True)
        oof.to_csv(oof_path, index=False)
        results["oof_output"] = str(oof_path)

    if args.test_base_prediction:
        if not args.output:
            raise RuntimeError("--output is required with --test-base-prediction.")
        test_base = pd.read_csv(args.test_base_prediction)
        test_features = pd.read_csv(args.test_features)
        test_features = merge_metadata(
            test_features, args.metadata_features
        )
        test_frame = test_features.merge(
            test_base[["id", "rating"]].rename(
                columns={"rating": "base_prediction"}
            ),
            on="id",
            how="inner",
            validate="one_to_one",
        )
        if len(test_frame) != len(test_features) or len(test_frame) != len(test_base):
            raise RuntimeError("Test base prediction and feature alignment failed.")
        test_columns = [
            column
            for column in FEATURE_COLUMNS
            if args.metadata_features or not column.startswith("meta_")
        ]
        test_x = (
            test_frame[test_columns]
            .replace([np.inf, -np.inf], np.nan)
            .fillna(test_frame[test_columns].median(numeric_only=True))
            .to_numpy(dtype=np.float32)
        )
        test_prediction = np.clip(
            sum(
                blend_weights[index]
                * candidate_models[model_name].predict(test_x)
                for index, model_name in enumerate(blend_names)
            ),
            1.0,
            5.0,
        )
        output = pd.DataFrame(
            {"id": test_frame["id"].to_numpy(), "rating": test_prediction}
        )
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output.to_csv(output_path, index=False)
        results["candidate_output"] = str(output_path)
        results["candidate_prediction_summary"] = {
            "mean": float(test_prediction.mean()),
            "std": float(test_prediction.std()),
            "min": float(test_prediction.min()),
            "max": float(test_prediction.max()),
        }

    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
