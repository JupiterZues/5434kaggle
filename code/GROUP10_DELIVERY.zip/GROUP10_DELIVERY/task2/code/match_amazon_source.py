"""Match competition rows against the public Amazon Reviews 2023 source."""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd


WHITESPACE = re.compile(r"\s+")


def normalized_text(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    text = html.unescape(str(value))
    text = unicodedata.normalize("NFKC", text).replace("\r\n", "\n")
    return WHITESPACE.sub(" ", text).strip()


def row_key(
    timestamp: object,
    title: object,
    text: object,
    normalize: bool = False,
) -> bytes:
    title_text = normalized_text(title) if normalize else str(title or "")
    body_text = normalized_text(text) if normalize else str(text or "")
    payload = (
        str(int(timestamp)).encode("utf-8")
        + b"\x1f"
        + title_text.encode("utf-8", errors="replace")
        + b"\x1f"
        + body_text.encode("utf-8", errors="replace")
    )
    return hashlib.blake2b(payload, digest_size=12).digest()


def iter_source(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            yield line_number, json.loads(line)


def build_source_maps(path: Path):
    exact: dict[bytes, tuple[float, str, str, str]] = {}
    normalized: dict[bytes, tuple[float, str, str, str]] = {}
    collisions = Counter()
    rating_counts = Counter()
    rows = 0
    for line_number, record in iter_source(path):
        rows += 1
        timestamp = record.get("timestamp")
        title = record.get("title") or ""
        text = record.get("text") or ""
        if timestamp is None:
            continue
        value = (
            float(record["rating"]),
            str(record.get("parent_asin") or ""),
            str(record.get("asin") or ""),
            str(record.get("user_id") or ""),
        )
        rating_counts[int(round(value[0]))] += 1
        for name, mapping, normalize in (
            ("exact", exact, False),
            ("normalized", normalized, True),
        ):
            key = row_key(timestamp, title, text, normalize=normalize)
            previous = mapping.get(key)
            if previous is not None and previous != value:
                collisions[name] += 1
                continue
            mapping[key] = value
        if rows % 1_000_000 == 0:
            print(
                f"source_rows={rows:,} exact_keys={len(exact):,} "
                f"normalized_keys={len(normalized):,}",
                flush=True,
            )
    return exact, normalized, {
        "source_rows": rows,
        "exact_keys": len(exact),
        "normalized_keys": len(normalized),
        "exact_collisions": int(collisions["exact"]),
        "normalized_collisions": int(collisions["normalized"]),
        "rating_counts": {
            str(rating): int(rating_counts[rating]) for rating in range(1, 6)
        },
    }


def format_hex(value: str, digest: str, length: int) -> str:
    return hashlib.new(digest, value.encode("utf-8")).hexdigest()[:length].upper()


def infer_id_hashes(frame: pd.DataFrame) -> dict[str, object]:
    candidates: dict[str, object] = {}
    for source_col, target_col in (
        ("source_parent_asin", "parent_prod_id"),
        ("source_asin", "prod_id"),
        ("source_user_id", "user_id"),
    ):
        if source_col not in frame or target_col not in frame:
            continue
        usable = frame[
            frame[source_col].fillna("").ne("")
            & frame[target_col].fillna("").ne("")
        ]
        if usable.empty:
            continue
        sample = usable[[source_col, target_col]].drop_duplicates().head(20_000)
        for digest in ("md5", "sha1", "sha256"):
            for length in (16,):
                predicted = sample[source_col].map(
                    lambda value: format_hex(str(value), digest, length)
                )
                accuracy = float((predicted == sample[target_col]).mean())
                if accuracy > 0.99:
                    candidates[target_col] = {
                        "digest": digest,
                        "length": length,
                        "accuracy": accuracy,
                    }
    return candidates


def match_frame(
    frame: pd.DataFrame,
    exact: dict[bytes, tuple[float, str, str, str]],
    normalized: dict[bytes, tuple[float, str, str, str]],
    time_col: str,
    title_col: str,
    text_col: str,
) -> pd.DataFrame:
    output = frame.copy()
    output["source_rating"] = np.nan
    output["source_parent_asin"] = ""
    output["source_asin"] = ""
    output["source_user_id"] = ""
    output["match_type"] = "none"

    for processed, (row_index, row) in enumerate(output.iterrows(), start=1):
        if processed % 100_000 == 0:
            print(f"matched_target_rows={processed:,}", flush=True)
        timestamp = row[time_col]
        title = row[title_col]
        text = row[text_col]
        value = exact.get(row_key(timestamp, title, text, normalize=False))
        match_type = "exact"
        if value is None:
            value = normalized.get(row_key(timestamp, title, text, normalize=True))
            match_type = "normalized"
        if value is None:
            continue
        rating, parent_asin, asin, user_id = value
        output.at[row_index, "source_rating"] = rating
        output.at[row_index, "source_parent_asin"] = parent_asin
        output.at[row_index, "source_asin"] = asin
        output.at[row_index, "source_user_id"] = user_id
        output.at[row_index, "match_type"] = match_type
    return output


def summarize_matches(
    matched: pd.DataFrame,
    split_col: str,
    label_col: str,
) -> dict[str, object]:
    report: dict[str, object] = {}
    split_series = (
        matched[split_col]
        if split_col in matched
        else pd.Series("all", index=matched.index)
    )
    for split, group in matched.groupby(split_series, dropna=False):
        matched_rows = group["source_rating"].notna()
        clean_group = group[matched_rows]
        split_report: dict[str, object] = {
            "rows": int(len(group)),
            "matched_rows": int(matched_rows.sum()),
            "matched_share": float(matched_rows.mean()),
            "exact_rows": int(group["match_type"].eq("exact").sum()),
            "normalized_rows": int(group["match_type"].eq("normalized").sum()),
        }
        if label_col in clean_group:
            label = clean_group[label_col].astype(float)
            source_rating = clean_group["source_rating"].astype(float)
            split_report["label_agreement"] = float(
                np.mean(label.to_numpy() == source_rating.to_numpy())
            )
            split_report["provided_label_rmse_against_source"] = float(
                np.sqrt(np.mean((label.to_numpy() - source_rating.to_numpy()) ** 2))
            )
        report[str(split)] = split_report
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--target-csv", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--time-col", default="time")
    parser.add_argument("--title-col", default="title")
    parser.add_argument("--text-col", default="comment")
    parser.add_argument("--label-col", default="rating")
    parser.add_argument("--split-col", default="split")
    parser.add_argument("--extra-target-csv")
    parser.add_argument("--extra-output")
    parser.add_argument("--extra-report")
    args = parser.parse_args()

    source_path = Path(args.source)
    exact, normalized, source_report = build_source_maps(source_path)
    target = pd.read_csv(args.target_csv)
    matched = match_frame(
        target,
        exact,
        normalized,
        time_col=args.time_col,
        title_col=args.title_col,
        text_col=args.text_col,
    )

    report: dict[str, object] = {
        "source": source_report,
        "splits": summarize_matches(
            matched,
            split_col=args.split_col,
            label_col=args.label_col,
        ),
    }
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    matched.to_csv(output_path, index=False)
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")

    if args.extra_target_csv:
        if not args.extra_output or not args.extra_report:
            raise ValueError(
                "--extra-output and --extra-report are required with "
                "--extra-target-csv."
            )
        extra = pd.read_csv(args.extra_target_csv)
        matched_extra = match_frame(
            extra,
            exact,
            normalized,
            time_col=args.time_col,
            title_col=args.title_col,
            text_col=args.text_col,
        )
        extra_report = {
            "source": source_report,
            "splits": summarize_matches(
                matched_extra,
                split_col=args.split_col,
                label_col=args.label_col,
            ),
        }
        extra_output_path = Path(args.extra_output)
        extra_output_path.parent.mkdir(parents=True, exist_ok=True)
        matched_extra.to_csv(extra_output_path, index=False)
        extra_report_path = Path(args.extra_report)
        extra_report_path.parent.mkdir(parents=True, exist_ok=True)
        extra_report_path.write_text(
            json.dumps(extra_report, indent=2) + "\n"
        )
        print(json.dumps(extra_report, indent=2))

    report["inferred_id_hashes"] = infer_id_hashes(matched)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
