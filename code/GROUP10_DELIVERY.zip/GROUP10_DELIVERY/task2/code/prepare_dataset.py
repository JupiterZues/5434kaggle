"""Create a balanced, reproducible Task 2 modeling sample and validation splits."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


REQUIRED_COLUMNS = [
    "id",
    "title",
    "user_id",
    "comment",
    "prod_id",
    "parent_prod_id",
    "time",
    "votes",
    "purchased",
    "rating",
]


def _sample_indices(
    indices: np.ndarray, size: int, rng: np.random.Generator
) -> np.ndarray:
    if size >= len(indices):
        return indices.copy()
    return rng.choice(indices, size=size, replace=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", default="input/train.csv")
    parser.add_argument("--output", default="input/model_sample_100k_per_class.csv")
    parser.add_argument("--report", default="logs/model_sample_report.json")
    parser.add_argument("--per-class", type=int, default=100_000)
    parser.add_argument("--random-val-per-class", type=int, default=2_500)
    parser.add_argument("--group-buckets", type=int, default=20)
    parser.add_argument("--group-val-bucket", type=int, default=0)
    parser.add_argument("--text-group-buckets", type=int, default=20)
    parser.add_argument("--text-val-bucket", type=int, default=0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--chunksize", type=int, default=250_000)
    parser.add_argument("--label-col", default="rating")
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    sampled_parts: list[pd.DataFrame] = []
    source_rating_counts: dict[int, int] = {}

    for chunk_number, chunk in enumerate(
        pd.read_csv(
            args.train,
            usecols=list(dict.fromkeys([*REQUIRED_COLUMNS, args.label_col])),
            chunksize=args.chunksize,
        ),
        start=1,
    ):
        chunk = chunk.dropna(subset=[args.label_col]).copy()
        chunk = chunk[chunk[args.label_col].between(1, 5)].copy()
        chunk["rating"] = chunk[args.label_col].astype(np.int8)
        if args.label_col != "rating":
            chunk = chunk.drop(columns=[args.label_col])

        for rating, group in chunk.groupby("rating", sort=True):
            rating = int(rating)
            source_rating_counts[rating] = (
                source_rating_counts.get(rating, 0) + len(group)
            )
            remaining = args.per_class - sum(
                len(part) for part in sampled_parts if int(part["rating"].iloc[0]) == rating
            )
            if remaining <= 0:
                continue

            local_rng = np.random.default_rng(args.seed + rating * 10_007 + chunk_number)
            take = min(remaining, len(group))
            sampled_parts.append(
                group.sample(n=take, random_state=int(local_rng.integers(0, 2**31 - 1)))
            )

        if chunk_number % 8 == 0:
            print(
                f"scanned_rows={sum(source_rating_counts.values()):,} "
                f"sampled_rows={sum(len(part) for part in sampled_parts):,}",
                flush=True,
            )

    if not sampled_parts:
        raise RuntimeError("No rows were sampled from the training data.")

    sample = (
        pd.concat(sampled_parts, ignore_index=True)
        .drop_duplicates(subset=["id"])
        .sort_values("id")
        .reset_index(drop=True)
    )

    missing_columns = set(REQUIRED_COLUMNS) - set(sample.columns)
    if missing_columns:
        raise RuntimeError(f"Missing columns after sampling: {sorted(missing_columns)}")

    sample["user_bucket"] = (
        pd.util.hash_pandas_object(
            sample["user_id"].fillna("").astype(str), index=False
        )
        % args.group_buckets
    ).astype(np.int16)
    combined_text = (
        sample["title"].fillna("").astype(str)
        + "\x1f"
        + sample["comment"].fillna("").astype(str)
    )
    sample["text_bucket"] = (
        pd.util.hash_pandas_object(combined_text, index=False)
        % args.text_group_buckets
    ).astype(np.int16)
    sample["split"] = "train"

    for rating, group in sample.groupby("rating", sort=True):
        selected = _sample_indices(
            group.index.to_numpy(),
            args.random_val_per_class,
            rng,
        )
        sample.loc[selected, "split"] = "val_random"
        print(
            f"random_val rating={int(rating)} rows={len(selected):,}",
            flush=True,
        )

    group_mask = (
        (sample["split"] == "train")
        & (
            (sample["user_bucket"] == args.group_val_bucket)
            | (sample["text_bucket"] == args.text_val_bucket)
        )
    )
    sample.loc[group_mask, "split"] = "val_group"

    split_counts = (
        sample.groupby(["split", "rating"]).size().unstack(fill_value=0).sort_index()
    )
    if (split_counts.loc["train"] < 1000).any():
        raise RuntimeError(
            "The training split has fewer than 1,000 rows for at least one rating. "
            "Reduce the validation size or use a different group bucket."
        )

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sample.to_csv(output_path, index=False, compression="infer")

    report = {
        "seed": args.seed,
        "source_rating_counts": {
            str(k): int(v) for k, v in sorted(source_rating_counts.items())
        },
        "sample_rows": int(len(sample)),
        "sample_rating_counts": {
            str(k): int(v)
            for k, v in sample["rating"].value_counts().sort_index().items()
        },
        "split_counts_by_rating": {
            split: {str(k): int(v) for k, v in row.items()}
            for split, row in split_counts.iterrows()
        },
        "random_val_per_class": args.random_val_per_class,
        "group_buckets": args.group_buckets,
        "group_val_bucket": args.group_val_bucket,
        "text_group_buckets": args.text_group_buckets,
        "text_val_bucket": args.text_val_bucket,
        "output": str(output_path),
    }
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
