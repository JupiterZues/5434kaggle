# Data files

Do not commit or redistribute restricted course data.

Expected files:

- `input/train.csv` (7,684,645 rows)
- `input/test.csv` (10,000 rows)
- `input/sampleSubmission.csv`
- `input/external/amazon2023/Grocery_and_Gourmet_Food.jsonl`
- Optional: `input/external/amazon2023/meta_features.csv`

Verify source files before training. The final report documents exact paths and
matching statistics.
