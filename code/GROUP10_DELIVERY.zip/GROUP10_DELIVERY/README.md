# GROUP10 — COMP5434 Project Delivery

Task 1 and Task 2 are separated below:

- `task1/`: reproducible Task 1 code, metrics and final submission
- `task2/`: reproducible Task 2 code, metrics and final submission

Reports and slides are intentionally stored outside this package, in the workspace root:

- `TASK1_GROUP10_REPORT.docx`
- `TASK1_GROUP10_SLIDES.pptx`
- `TASK2_GROUP10_REPORT.docx`
- `TASK2_GROUP10_SLIDES.pptx`

Raw course data, external datasets, model checkpoints and credentials are not redistributed.
