# GROUP10 · COMP5434 Task 1

Final Public Macro-F1: **0.92488**  
Final submission ref: `58295750`  
Leaderboard position at query: approximately **9th**.

This package contains the reproducible Task 1 code, metrics and final
submission. It intentionally does **not** contain the report or slides.
The report and slides are stored separately in the workspace root.

## Package

```text
README.md
CODE_GUIDE.md
RUN_COMMANDS.md
code/                  training, specialist, ensemble and cycle scripts
metrics/final_metrics.json
submission/final_submission.csv
submission/final_validation.json
data/README.md
```

Raw course data, downloaded checkpoints and tabular source files are not
redistributed. Place them under `input/` using the names documented in
`data/README.md`.

## Environment

The final run used Python 3.12, PyTorch 2.12.1+cu130, TabPFN 9.2.0,
scikit-learn 1.9.1 and an RTX 4090. Install the packages with:

```bash
python -m pip install -r code/requirements.txt
```

## Reproduction

The exact sequence is in `RUN_COMMANDS.md`. The final candidate can be
rebuilt from the saved anchor and the four fixed row/class changes with
`code/build_cycle_candidate.py`.

Final SHA-256:

```text
c7dd8ea7f430067695d5f9c2d993a5f22432588af273c455879b7978c8ba5972
```

Replace the member placeholders in the accompanying report before course
submission.
