# GROUP10 Task 1 reproduction commands

Run from the directory containing `README.md`.

## 1. Install

```bash
python -m pip install -r code/requirements.txt
```

## 2. Build the CPU baseline and OOF streams

```bash
python code/train_ensemble.py
python code/train_diverse_models.py
python code/train_seed_bags.py
python code/train_ft_transformer.py
python code/train_pytabkit.py
```

## 3. Train TabPFN-3.5 GPU streams

```bash
python code/train_tabpfn.py   --model-path models/tabpfn35/tabpfn-v3.5-20260909_multiclass.safetensors   --feature-set engineered --n-estimators 16 --folds 10 --seed 2031   --output-prefix tabpfn35_eng10_n16   --report logs/weather_tabpfn35_eng10_n16.json

python code/train_tabpfn.py   --model-path models/tabpfn35/tabpfn-v3.5-20260909_multiclass.safetensors   --feature-set raw --n-estimators 16 --folds 10 --seed 2032   --output-prefix tabpfn35_raw10_n16   --report logs/weather_tabpfn35_raw10_n16.json
```

## 4. Train specialists

```bash
python code/train_tabpfn_binary.py   --pair 23 --feature-set custom --n-estimators 16 --folds 10   --seed 3110 --output-prefix specialist23_tabpfn35_c10   --report logs/weather_specialist23_tabpfn35_c10.json

python code/train_tabpfn_binary.py   --one-vs-rest --positive-class 2 --feature-set custom   --n-estimators 16 --folds 10 --seed 3130   --output-prefix class2_vs_rest_tabpfn35_c10   --report logs/weather_class2_vs_rest_tabpfn35_c10.json
```

## 5. Rebuild the final four-row cycle

The committed anchor and fixed cycle are:

```bash
python code/build_cycle_candidate.py   --anchor submissions/weather_tabpfn_swap10_candidate.csv   --sample input/sample_submission.csv   --output submissions/weather_specialist_cycle4_candidate.csv   --report logs/weather_specialist_cycle4_report.json
```

The final output must have 3,300 rows, exact sample ID order and counts
`825 / 825 / 825 / 825`.
