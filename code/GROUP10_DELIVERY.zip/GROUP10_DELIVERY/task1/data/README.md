# Data placement

This package does not redistribute course data or model checkpoints.

Expected input:

- `input/train.csv`: 9,900 rows, 12 columns
- `input/test.csv`: 3,300 rows, 11 columns
- `input/sample_submission.csv`: id/label order reference

Target definitions:

- 1 = Sunny
- 2 = Cloudy
- 3 = Rainy
- 4 = Snowy

The external `weather_classification_data.csv` test labels were not used in
training, candidate selection, postprocessing or submission.
