# GROUP10 Task 1 code map

| File | Purpose |
| --- | --- |
| `train_ensemble.py` | CPU 10-fold tree model baseline and feature definitions. |
| `train_diverse_models.py` | Additional tree-family diversity. |
| `train_seed_bags.py` | Seed-bagged ExtraTrees/RandomForest streams. |
| `train_ft_transformer.py` | Feature-token transformer experiments. |
| `train_pytabkit.py` | TabM / RealMLP-TD experiments. |
| `train_tabpfn.py` | TabPFN multiclass streams, engineered/raw/custom/clip features. |
| `train_tabpfn_binary.py` | Pairwise and one-vs-rest specialist models. |
| `train_tabpfn_stack.py` | TabPFN meta-stack over OOF-safe probabilities. |
| `audit_blend_nested.py` | Nested blend weight and class-bias audit. |
| `build_swap_candidate.py` | Anchor-preserving pairwise swap candidate. |
| `build_pair_swap_candidate.py` | Two-class specialist swap construction. |
| `build_cycle_candidate.py` | Exact final four-row class-quota-preserving cycle. |
| `tune_boosters.py`, `tune_catboost.py` | Hyperparameter searches. |

The final file is reproducible from the anchor, fixed cycle changes and the
validation checks. The report and slide generation code is deliberately not
included in this package.
