"""Train a CPU-only weather classification ensemble with fixed folds."""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from xgboost import XGBClassifier


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
OOF = ROOT / "oof"
SUBMISSIONS = ROOT / "submissions"
LOGS = ROOT / "logs"

ID_COL = "id"
TARGET_COL = "label"
CLASSES = np.array([1, 2, 3, 4])
CLASS_NAMES = {
    1: "Sunny",
    2: "Cloudy",
    3: "Rainy",
    4: "Snowy",
}
NUMERIC = [
    "Temperature",
    "Humidity",
    "Wind Speed",
    "Precipitation (%)",
    "Atmospheric Pressure",
    "UV Index",
    "Visibility (km)",
]
CATEGORICAL = ["Cloud Cover", "Season", "Location"]


def add_features(frame: pd.DataFrame) -> pd.DataFrame:
    output = frame.copy()
    output["temp_humidity"] = output["Temperature"] * output["Humidity"]
    output["precip_humidity"] = (
        output["Precipitation (%)"] * output["Humidity"]
    )
    output["wind_precip"] = output["Wind Speed"] * output["Precipitation (%)"]
    output["pressure_slope"] = (
        output["Atmospheric Pressure"] - 1013.25
    )
    output["cloud_precip"] = (
        output["Cloud Cover"].map(
            {"clear": 0, "partly cloudy": 1, "cloudy": 2, "overcast": 3}
        )
        * output["Precipitation (%)"]
    )
    output["cloud_code"] = output["Cloud Cover"].map(
        {"clear": 0, "partly cloudy": 1, "cloudy": 2, "overcast": 3}
    )
    output["visibility_humidity"] = (
        output["Visibility (km)"] / output["Humidity"].clip(lower=1)
    )
    output["season_code"] = output["Season"].map(
        {"Winter": 0, "Spring": 1, "Summer": 2, "Autumn": 3}
    )
    output["location_code"] = output["Location"].map(
        {"coastal": 0, "inland": 1, "mountain": 2}
    )
    output["season_sin"] = np.sin(
        2.0 * np.pi * output["season_code"] / 4.0
    )
    output["season_cos"] = np.cos(
        2.0 * np.pi * output["season_code"] / 4.0
    )
    return output


def make_models(seed: int) -> dict[str, object]:
    engineered_numeric = [
        *NUMERIC,
        "temp_humidity",
        "precip_humidity",
        "wind_precip",
        "pressure_slope",
        "cloud_precip",
        "cloud_code",
        "visibility_humidity",
        "season_code",
        "location_code",
        "season_sin",
        "season_cos",
    ]
    models = {
        "logistic": None,
        "lgbm": LGBMClassifier(
            objective="multiclass",
            num_class=4,
            n_estimators=650,
            learning_rate=0.025,
            num_leaves=31,
            min_child_samples=20,
            subsample=0.85,
            colsample_bytree=0.85,
            reg_lambda=2.0,
            random_state=seed,
            n_jobs=4,
            verbosity=-1,
        ),
        "cat": CatBoostClassifier(
            loss_function="MultiClass",
            iterations=700,
            depth=6,
            learning_rate=0.03,
            l2_leaf_reg=4.0,
            random_seed=seed,
            thread_count=4,
            verbose=False,
            allow_writing_files=False,
        ),
        "xgb": XGBClassifier(
            objective="multi:softprob",
            num_class=4,
            n_estimators=600,
            max_depth=6,
            learning_rate=0.03,
            subsample=0.85,
            colsample_bytree=0.85,
            min_child_weight=1.0,
            reg_lambda=2.0,
            random_state=seed,
            n_jobs=4,
            tree_method="hist",
            eval_metric="mlogloss",
        ),
        "rf": RandomForestClassifier(
            n_estimators=800,
            max_features="sqrt",
            min_samples_leaf=1,
            random_state=seed,
            n_jobs=4,
        ),
        "extra": ExtraTreesClassifier(
            n_estimators=800,
            max_features="sqrt",
            min_samples_leaf=1,
            random_state=seed,
            n_jobs=4,
        ),
        "hist": HistGradientBoostingClassifier(
            max_iter=500,
            learning_rate=0.04,
            max_leaf_nodes=31,
            l2_regularization=2.0,
            random_state=seed,
        ),
    }
    print(
        json.dumps(
            {
                "event": "feature_sets",
                "engineered_numeric": engineered_numeric,
            }
        ),
        flush=True,
    )
    return models


def fit_predict(
    model_name: str,
    model: object,
    train_x: pd.DataFrame,
    train_y: np.ndarray,
    valid_x: pd.DataFrame,
    test_x: pd.DataFrame,
) -> tuple[np.ndarray, np.ndarray]:
    numeric = [
        *NUMERIC,
        "temp_humidity",
        "precip_humidity",
        "wind_precip",
        "pressure_slope",
        "cloud_precip",
        "cloud_code",
        "visibility_humidity",
        "season_code",
        "location_code",
        "season_sin",
        "season_cos",
    ]
    if model_name == "logistic":
        pipeline = make_pipeline(
            StandardScaler(),
            LogisticRegression(
                C=2.0,
                max_iter=3000,
                n_jobs=4,
            ),
        )
        pipeline.fit(train_x[numeric], train_y)
        return (
            pipeline.predict_proba(valid_x[numeric]),
            pipeline.predict_proba(test_x[numeric]),
        )

    fit_x = train_x[numeric].copy()
    valid_frame = valid_x[numeric].copy()
    test_frame = test_x[numeric].copy()
    if model_name == "lgbm":
        model.fit(fit_x, train_y)
    elif model_name == "cat":
        model.fit(fit_x, train_y)
    else:
        fit_target = train_y - 1 if model_name == "xgb" else train_y
        model.fit(fit_x, fit_target)
        return (
            model.predict_proba(valid_frame),
            model.predict_proba(test_frame),
        )
    return model.predict_proba(valid_frame), model.predict_proba(test_frame)


def optimize_blend(oof: np.ndarray, target: np.ndarray, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    best_score = -1.0
    best_weights = np.ones(oof.shape[0]) / oof.shape[0]
    for _ in range(3000):
        weights = rng.dirichlet(np.ones(oof.shape[0]))
        prediction = np.einsum("m,mnc->nc", weights, oof)
        score = f1_score(
            target,
            CLASSES[prediction.argmax(axis=1)],
            average="macro",
        )
        if score > best_score:
            best_score = float(score)
            best_weights = weights
    return best_weights


def main() -> None:
    for directory in (OOF, SUBMISSIONS, LOGS):
        directory.mkdir(parents=True, exist_ok=True)
    train = add_features(pd.read_csv(INPUT / "train.csv"))
    test = add_features(pd.read_csv(INPUT / "test.csv"))
    target = train[TARGET_COL].to_numpy(dtype=int)
    folds = list(
        StratifiedKFold(
            n_splits=10,
            shuffle=True,
            random_state=42,
        ).split(train, target)
    )
    base_names = ["logistic", "lgbm", "cat", "xgb", "rf", "extra", "hist"]
    oof_probabilities = {}
    test_probabilities = {}
    reports: dict[str, object] = {}

    for model_name in base_names:
        started = time.monotonic()
        model_oof = np.zeros((len(train), 4), dtype=np.float64)
        model_test = np.zeros((len(test), 4), dtype=np.float64)
        for fold_index, (fit_indices, valid_indices) in enumerate(folds):
            model = make_models(42 + fold_index)[model_name]
            valid_probability, test_probability = fit_predict(
                model_name,
                model,
                train.iloc[fit_indices],
                target[fit_indices],
                train.iloc[valid_indices],
                test,
            )
            model_oof[valid_indices] = valid_probability
            model_test += test_probability / len(folds)
            print(
                json.dumps(
                    {
                        "event": "fold",
                        "model": model_name,
                        "fold": fold_index,
                    }
                ),
                flush=True,
            )
        prediction = CLASSES[model_oof.argmax(axis=1)]
        score = f1_score(target, prediction, average="macro")
        reports[model_name] = {
            "macro_f1": float(score),
            "elapsed_seconds": time.monotonic() - started,
        }
        oof_probabilities[model_name] = model_oof
        test_probabilities[model_name] = model_test
        np.save(OOF / f"{model_name}_oof_probabilities.npy", model_oof)
        np.save(OOF / f"{model_name}_test_probabilities.npy", model_test)
        print(json.dumps({"event": "model", **reports[model_name]}), flush=True)

    model_names = list(base_names)
    stacked_oof = np.stack([oof_probabilities[name] for name in model_names])
    weights = optimize_blend(stacked_oof, target, seed=2026)
    blend_oof = np.einsum("m,mnc->nc", weights, stacked_oof)
    stacked_test = np.stack([test_probabilities[name] for name in model_names])
    blend_test = np.einsum("m,mnc->nc", weights, stacked_test)
    blend_prediction = CLASSES[blend_oof.argmax(axis=1)]
    blend_score = f1_score(target, blend_prediction, average="macro")

    oof_frame = pd.DataFrame(
        {
            ID_COL: train[ID_COL],
            TARGET_COL: target,
            "prediction": blend_prediction,
        }
    )
    oof_frame.to_csv(OOF / "weather_ensemble_oof.csv", index=False)
    submission = pd.DataFrame(
        {
            ID_COL: test[ID_COL],
            "label": CLASSES[blend_test.argmax(axis=1)].astype(int),
        }
    )
    submission.to_csv(SUBMISSIONS / "weather_cpu_ensemble.csv", index=False)
    report = {
        "status": "complete",
        "models": reports,
        "blend_weights": dict(zip(model_names, weights.tolist())),
        "blend_oof_macro_f1": float(blend_score),
        "submission": str(SUBMISSIONS / "weather_cpu_ensemble.csv"),
    }
    (LOGS / "weather_cpu_ensemble.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
