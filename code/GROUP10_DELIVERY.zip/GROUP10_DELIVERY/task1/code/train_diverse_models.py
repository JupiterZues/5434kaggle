"""Train additional diverse CPU models on the frozen Task 1 folds."""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold
from xgboost import XGBClassifier

from train_ensemble import NUMERIC, add_features


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
OOF = ROOT / "oof"
LOGS = ROOT / "logs"
CLASSES = np.array([1, 2, 3, 4])


def make_model(name: str, seed: int) -> object:
    if name == "lgbm_dart":
        return LGBMClassifier(
            objective="multiclass",
            num_class=4,
            boosting_type="dart",
            n_estimators=900,
            learning_rate=0.02,
            num_leaves=31,
            min_child_samples=15,
            subsample=0.85,
            colsample_bytree=0.85,
            reg_lambda=1.0,
            drop_rate=0.1,
            max_drop=50,
            skip_drop=0.5,
            random_state=seed,
            n_jobs=4,
            verbosity=-1,
        )
    if name == "xgb_shallow":
        return XGBClassifier(
            objective="multi:softprob",
            num_class=4,
            n_estimators=1000,
            max_depth=4,
            learning_rate=0.015,
            subsample=0.85,
            colsample_bytree=0.8,
            min_child_weight=3.0,
            reg_lambda=3.0,
            random_state=seed,
            n_jobs=4,
            tree_method="hist",
            eval_metric="mlogloss",
        )
    if name == "cat_depth8":
        return CatBoostClassifier(
            loss_function="MultiClass",
            iterations=900,
            depth=8,
            learning_rate=0.02,
            l2_leaf_reg=6.0,
            random_seed=seed,
            thread_count=4,
            verbose=False,
            allow_writing_files=False,
        )
    if name == "extra_wide":
        return ExtraTreesClassifier(
            n_estimators=1800,
            max_features=0.6,
            min_samples_leaf=1,
            bootstrap=False,
            random_state=seed,
            n_jobs=4,
        )
    raise ValueError(name)


def main() -> None:
    OOF.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    train = add_features(pd.read_csv(INPUT / "train.csv"))
    test = add_features(pd.read_csv(INPUT / "test.csv"))
    target = train["label"].to_numpy(dtype=int)
    numeric = list(NUMERIC)
    numeric.extend(
        [
            "temp_humidity",
            "precip_humidity",
            "wind_precip",
            "pressure_slope",
            "cloud_precip",
            "cloud_code",
            "visibility_humidity",
            "season_code",
            "location_code",
            "season_sin",
            "season_cos",
        ]
    )
    folds = list(
        StratifiedKFold(
            n_splits=10,
            shuffle=True,
            random_state=42,
        ).split(train, target)
    )
    report: dict[str, object] = {"models": {}}
    for model_name in (
        "lgbm_dart",
        "xgb_shallow",
        "cat_depth8",
        "extra_wide",
    ):
        started = time.monotonic()
        oof_probability = np.zeros((len(train), 4), dtype=np.float64)
        test_probability = np.zeros((len(test), 4), dtype=np.float64)
        for fold_index, (fit_indices, valid_indices) in enumerate(folds):
            model = make_model(model_name, 20260 + fold_index)
            fit_target = (
                target[fit_indices] - 1
                if model_name == "xgb_shallow"
                else target[fit_indices]
            )
            model.fit(
                train.iloc[fit_indices][numeric],
                fit_target,
            )
            oof_probability[valid_indices] = model.predict_proba(
                train.iloc[valid_indices][numeric]
            )
            test_probability += model.predict_proba(
                test[numeric]
            ) / len(folds)
            print(
                json.dumps(
                    {
                        "event": "fold",
                        "model": model_name,
                        "fold": fold_index,
                    }
                ),
                flush=True,
            )
        prediction = CLASSES[oof_probability.argmax(axis=1)]
        score = float(f1_score(target, prediction, average="macro"))
        elapsed = time.monotonic() - started
        np.save(OOF / f"{model_name}_oof.npy", oof_probability)
        np.save(OOF / f"{model_name}_test.npy", test_probability)
        report["models"][model_name] = {
            "macro_f1": score,
            "elapsed_seconds": elapsed,
        }
        print(
            json.dumps(
                {"event": "model", "model": model_name, "macro_f1": score}
            ),
            flush=True,
        )
    (LOGS / "weather_diverse_models.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
