"""Train the best Task 1 CatBoost search trial with fixed 10-fold OOF."""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold

from train_ensemble import CATEGORICAL, NUMERIC, add_features


ROOT = Path(__file__).resolve().parents[1]
CLASSES = np.array([1, 2, 3, 4])
PARAMETERS = {
    "iterations": 1490,
    "depth": 8,
    "learning_rate": 0.027519313248704727,
    "l2_leaf_reg": 0.40408685897836655,
    "random_strength": 0.17832130445190858,
    "bagging_temperature": 0.5495968186900175,
    "border_count": 254,
}


def main() -> None:
    train = add_features(pd.read_csv(ROOT / "input/train.csv"))
    test = add_features(pd.read_csv(ROOT / "input/test.csv"))
    target = train["label"].to_numpy(dtype=int)
    columns = [
        *NUMERIC,
        "temp_humidity",
        "precip_humidity",
        "wind_precip",
        "pressure_slope",
        "cloud_precip",
        "cloud_code",
        "visibility_humidity",
        "season_code",
        "location_code",
        "season_sin",
        "season_cos",
        *CATEGORICAL,
    ]
    categorical_indices = [
        columns.index(column) for column in CATEGORICAL
    ]
    x = train[columns]
    test_x = test[columns]
    folds = list(
        StratifiedKFold(
            n_splits=10,
            shuffle=True,
            random_state=42,
        ).split(x, target)
    )
    oof_probability = np.zeros((len(train), 4), dtype=np.float64)
    test_probability = np.zeros((len(test), 4), dtype=np.float64)
    started = time.monotonic()
    for fold, (fit_indices, valid_indices) in enumerate(folds):
        model = CatBoostClassifier(
            loss_function="MultiClass",
            random_seed=2051 + fold,
            thread_count=4,
            verbose=False,
            allow_writing_files=False,
            cat_features=categorical_indices,
            **PARAMETERS,
        )
        model.fit(x.iloc[fit_indices], target[fit_indices])
        oof_probability[valid_indices] = model.predict_proba(
            x.iloc[valid_indices]
        )
        test_probability += model.predict_proba(test_x) / len(folds)
        print(json.dumps({"fold": fold}), flush=True)

    score = float(
        f1_score(
            target,
            CLASSES[oof_probability.argmax(axis=1)],
            average="macro",
        )
    )
    prefix = "cat_fixed2"
    np.save(ROOT / "oof" / f"{prefix}_oof.npy", oof_probability)
    np.save(ROOT / "oof" / f"{prefix}_test.npy", test_probability)
    report = {
        "parameters": PARAMETERS,
        "oof_macro_f1": score,
        "elapsed_seconds": time.monotonic() - started,
    }
    (ROOT / "logs" / f"weather_{prefix}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
