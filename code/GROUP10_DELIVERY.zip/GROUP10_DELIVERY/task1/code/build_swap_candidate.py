"""Build a quota-preserving candidate with high-confidence pairwise swaps."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--anchor",
        default="submissions/weather_balanced_search_plus_anchor_candidate.csv",
    )
    parser.add_argument(
        "--base-weights",
        default="logs/weather_balanced_weight_search_plus.json",
    )
    parser.add_argument("--tabpfn-stream", action="append", required=True)
    parser.add_argument("--tabpfn-weight", type=float, default=0.075)
    parser.add_argument(
        "--extra-stream",
        action="append",
        default=[],
        help="name=weight",
    )
    parser.add_argument(
        "--class-bias",
        nargs=4,
        type=float,
        default=[-0.12, 0.075, 0.0, 0.045],
    )
    parser.add_argument("--swaps", type=int, default=10)
    parser.add_argument(
        "--output",
        default="submissions/weather_tabpfn_swap10_candidate.csv",
    )
    parser.add_argument(
        "--report",
        default="logs/weather_tabpfn_swap10_report.json",
    )
    args = parser.parse_args()

    anchor = pd.read_csv(ROOT / args.anchor)
    sample = pd.read_csv(ROOT / "input/sample_submission.csv")
    if not np.array_equal(anchor["id"].to_numpy(), sample["id"].to_numpy()):
        raise RuntimeError("Anchor ID order does not match the sample submission.")

    base_report = json.loads((ROOT / args.base_weights).read_text())
    base_probability = sum(
        weight * np.load(ROOT / "oof" / f"{name}_test.npy")
        for name, weight in zip(
            base_report["names"], base_report["weights"]
        )
        if weight
    )
    tabpfn_probability = np.mean(
        [
            np.load(ROOT / "oof" / f"{stream}_test.npy")
            for stream in args.tabpfn_stream
        ],
        axis=0,
    )
    extra_probability = 0.0
    extra_weight_total = 0.0
    extra_streams = []
    for specification in args.extra_stream:
        name, weight_string = specification.split("=", 1)
        weight = float(weight_string)
        extra_probability = (
            extra_probability
            + weight * np.load(ROOT / "oof" / f"{name}_test.npy")
        )
        extra_weight_total += weight
        extra_streams.append({"name": name, "weight": weight})
    base_weight = (
        1.0 - args.tabpfn_weight - extra_weight_total
    )
    if base_weight < 0.0:
        raise RuntimeError("Model weights sum to more than one.")
    probability = (
        base_weight * base_probability
        + args.tabpfn_weight * tabpfn_probability
        + extra_probability
    )
    probability /= probability.sum(axis=1, keepdims=True)
    anchor_index = anchor["label"].to_numpy(dtype=int) - 1
    log_probability = np.log(
        np.clip(probability + np.asarray(args.class_bias), 1e-9, None)
    )

    candidates: list[tuple[float, int, int, int, int]] = []
    for source in range(4):
        for destination in range(source + 1, 4):
            source_rows = np.flatnonzero(anchor_index == source)
            destination_rows = np.flatnonzero(anchor_index == destination)
            for source_row in source_rows:
                gains = (
                    log_probability[source_row, destination]
                    - log_probability[source_row, source]
                    + log_probability[destination_rows, source]
                    - log_probability[destination_rows, destination]
                )
                for offset in np.flatnonzero(gains > 0):
                    candidates.append(
                        (
                            float(gains[offset]),
                            int(source_row),
                            int(destination_rows[offset]),
                            source,
                            destination,
                        )
                    )
    candidates.sort(reverse=True)

    prediction = anchor_index.copy()
    used_rows: set[int] = set()
    selected: list[dict[str, object]] = []
    for gain, source_row, destination_row, source, destination in candidates:
        if source_row in used_rows or destination_row in used_rows:
            continue
        prediction[source_row] = destination
        prediction[destination_row] = source
        used_rows.update((source_row, destination_row))
        selected.append(
            {
                "gain": gain,
                "source_row": source_row,
                "destination_row": destination_row,
                "source_class": source + 1,
                "destination_class": destination + 1,
            }
        )
        if len(selected) == args.swaps:
            break
    if len(selected) != args.swaps:
        raise RuntimeError(
            f"Only {len(selected)} non-overlapping positive swaps were found."
        )

    output_path = ROOT / args.output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(
        {"id": anchor["id"], "label": prediction + 1}
    ).to_csv(output_path, index=False)

    counts = (
        pd.Series(prediction + 1).value_counts().sort_index().to_dict()
    )
    if counts != {1: 825, 2: 825, 3: 825, 4: 825}:
        raise RuntimeError(f"Class counts changed unexpectedly: {counts}")
    report = {
        "anchor": args.anchor,
        "tabpfn_streams": args.tabpfn_stream,
        "tabpfn_weight": args.tabpfn_weight,
        "extra_streams": extra_streams,
        "class_bias": args.class_bias,
        "swaps": selected,
        "changed_rows": 2 * len(selected),
        "class_counts": counts,
        "output": args.output,
        "sha256": hashlib.sha256(output_path.read_bytes()).hexdigest(),
    }
    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
