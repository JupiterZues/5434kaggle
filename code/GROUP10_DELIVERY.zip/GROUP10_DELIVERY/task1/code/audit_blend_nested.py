"""Nested macro-F1 audit for Task 1 probability streams."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold


ROOT = Path(__file__).resolve().parents[1]
OOF = ROOT / "oof"
LOGS = ROOT / "logs"
SUBMISSIONS = ROOT / "submissions"
CLASSES = np.array([1, 2, 3, 4])


def score(
    prediction_streams: np.ndarray,
    weights: np.ndarray,
    target: np.ndarray,
    indices: np.ndarray,
    bias: np.ndarray,
) -> float:
    probability = np.einsum(
        "m,mnc->nc", weights, prediction_streams[:, indices]
    )
    predicted = CLASSES[(probability + bias).argmax(axis=1)]
    return float(f1_score(target[indices], predicted, average="macro"))


def coordinate_weights(
    streams: np.ndarray,
    target: np.ndarray,
    indices: np.ndarray,
    bias: np.ndarray,
) -> tuple[np.ndarray, float]:
    weights = np.full(streams.shape[0], 1.0 / streams.shape[0])
    best = score(streams, weights, target, indices, bias)
    for step in (0.20, 0.10, 0.05, 0.025, 0.01):
        improved = True
        while improved:
            improved = False
            for source in range(len(weights)):
                for destination in range(len(weights)):
                    if source == destination:
                        continue
                    trial = weights.copy()
                    moved = min(step, trial[source])
                    trial[source] -= moved
                    trial[destination] += moved
                    trial_score = score(
                        streams, trial, target, indices, bias
                    )
                    if trial_score > best + 1e-12:
                        weights, best, improved = trial, trial_score, True
    return weights, best


def coordinate_bias(
    streams: np.ndarray,
    target: np.ndarray,
    indices: np.ndarray,
    weights: np.ndarray,
    initial: np.ndarray | None = None,
) -> tuple[np.ndarray, float]:
    bias = (
        np.zeros(4, dtype=np.float64)
        if initial is None
        else initial.copy()
    )
    best = score(streams, weights, target, indices, bias)
    for step in (0.20, 0.10, 0.05, 0.025, 0.01, 0.005):
        improved = True
        while improved:
            improved = False
            for source in range(4):
                for destination in range(4):
                    if source == destination:
                        continue
                    trial = bias.copy()
                    trial[source] += step
                    trial[destination] -= step
                    trial_score = score(
                        streams, weights, target, indices, trial
                    )
                    if trial_score > best + 1e-12:
                        bias, best, improved = trial, trial_score, True
    return bias, best


def optimize(
    streams: np.ndarray,
    target: np.ndarray,
    indices: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, float]:
    weights, best = coordinate_weights(streams, target, indices, np.zeros(4))
    bias = np.zeros(4, dtype=np.float64)
    for _ in range(2):
        bias, best = coordinate_bias(streams, target, indices, weights, bias)
        weights, best = coordinate_weights(streams, target, indices, bias)
    bias, best = coordinate_bias(streams, target, indices, weights, bias)
    return weights, bias, best


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--stream", action="append", required=True, help="name"
    )
    parser.add_argument("--report", default="logs/weather_nested_blend.json")
    parser.add_argument(
        "--output", default="submissions/weather_nested_blend_candidate.csv"
    )
    args = parser.parse_args()

    target = pd.read_csv(ROOT / "input/train.csv")["label"].to_numpy(dtype=int)
    names = args.stream
    oof_streams = np.stack(
        [np.load(OOF / f"{name}_oof.npy") for name in names]
    )
    test_streams = np.stack(
        [np.load(OOF / f"{name}_test.npy") for name in names]
    )
    if oof_streams.shape[1] != len(target):
        raise RuntimeError("OOF row count does not match training target.")

    outer = StratifiedKFold(
        n_splits=5, shuffle=True, random_state=2026
    )
    fold_results = []
    for fold, (fit_indices, valid_indices) in enumerate(
        outer.split(target, target)
    ):
        weights, bias, fit_score = optimize(
            oof_streams, target, fit_indices
        )
        valid_score = score(
            oof_streams, weights, target, valid_indices, bias
        )
        fold_results.append(
            {
                "fold": fold,
                "fit_macro_f1": fit_score,
                "valid_macro_f1": valid_score,
                "weights": dict(zip(names, weights.tolist())),
                "class_bias": bias.tolist(),
            }
        )
        print(json.dumps(fold_results[-1]), flush=True)

    all_indices = np.arange(len(target))
    weights, bias, full_oof_score = optimize(oof_streams, target, all_indices)
    probability = np.einsum("m,mnc->nc", weights, test_streams)
    prediction = CLASSES[(probability + bias).argmax(axis=1)]
    sample = pd.read_csv(ROOT / "input/sample_submission.csv")
    submission = pd.DataFrame({"id": sample["id"], "label": prediction})
    output_path = ROOT / args.output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    submission.to_csv(output_path, index=False)

    report = {
        "streams": names,
        "outer_folds": fold_results,
        "nested_valid_mean": float(
            np.mean([row["valid_macro_f1"] for row in fold_results])
        ),
        "nested_valid_std": float(
            np.std(
                [row["valid_macro_f1"] for row in fold_results],
                ddof=1,
            )
        ),
        "full_weights": dict(zip(names, weights.tolist())),
        "full_class_bias": bias.tolist(),
        "full_oof_macro_f1": full_oof_score,
        "candidate": str(output_path),
    }
    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
