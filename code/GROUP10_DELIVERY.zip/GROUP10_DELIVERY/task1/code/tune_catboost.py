"""Tune CatBoost with native categorical features for Task 1."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold

from train_ensemble import CATEGORICAL, NUMERIC, add_features


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
OOF = ROOT / "oof"
LOGS = ROOT / "logs"
CLASSES = np.array([1, 2, 3, 4])


def feature_columns() -> list[str]:
    return [
        *NUMERIC,
        "temp_humidity",
        "precip_humidity",
        "wind_precip",
        "pressure_slope",
        "cloud_precip",
        "cloud_code",
        "visibility_humidity",
        "season_code",
        "location_code",
        "season_sin",
        "season_cos",
        *CATEGORICAL,
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--iterations", type=int, default=28)
    parser.add_argument("--seed", type=int, default=2029)
    args = parser.parse_args()

    train = add_features(pd.read_csv(INPUT / "train.csv"))
    test = add_features(pd.read_csv(INPUT / "test.csv"))
    target = train["label"].to_numpy(dtype=int)
    columns = feature_columns()
    x = train[columns]
    test_x = test[columns]
    categorical_indices = [
        columns.index(column) for column in CATEGORICAL
    ]

    search_cv = StratifiedKFold(
        n_splits=5, shuffle=True, random_state=73
    )
    started = time.monotonic()
    rng = np.random.default_rng(args.seed)
    best_score = -1.0
    best_params: dict[str, object] | None = None
    trials: list[dict[str, object]] = []
    for trial in range(args.iterations):
        parameters = {
            "iterations": int(rng.integers(450, 1700)),
            "depth": int(rng.integers(4, 10)),
            "learning_rate": float(
                np.exp(rng.uniform(np.log(0.015), np.log(0.08)))
            ),
            "l2_leaf_reg": float(
                np.exp(rng.uniform(np.log(0.3), np.log(20.0)))
            ),
            "random_strength": float(rng.uniform(0.1, 5.0)),
            "bagging_temperature": float(rng.uniform(0.1, 3.0)),
            "border_count": int(rng.choice([64, 128, 254])),
        }
        fold_scores = []
        for fit_indices, valid_indices in search_cv.split(x, target):
            model = CatBoostClassifier(
                loss_function="MultiClass",
                random_seed=args.seed + trial,
                thread_count=4,
                verbose=False,
                allow_writing_files=False,
                cat_features=categorical_indices,
                **parameters,
            )
            model.fit(x.iloc[fit_indices], target[fit_indices])
            prediction = model.predict(x.iloc[valid_indices]).astype(int).ravel()
            fold_scores.append(
                f1_score(
                    target[valid_indices],
                    prediction,
                    average="macro",
                )
            )
        mean_score = float(np.mean(fold_scores))
        trial_record = {
            "trial": trial,
            "mean_macro_f1": mean_score,
            "std_macro_f1": float(np.std(fold_scores, ddof=1)),
            "parameters": parameters,
        }
        trials.append(trial_record)
        print(json.dumps(trial_record), flush=True)
        if mean_score > best_score:
            best_score = mean_score
            best_params = parameters

    if best_params is None:
        raise RuntimeError("CatBoost search produced no valid parameters.")
    print(
        json.dumps(
            {
                "family": "catboost",
                "best_score": best_score,
                "best_params": best_params,
            }
        ),
        flush=True,
    )

    folds = list(
        StratifiedKFold(
            n_splits=10,
            shuffle=True,
            random_state=42,
        ).split(x, target)
    )
    oof_probability = np.zeros((len(train), 4), dtype=np.float64)
    test_probability = np.zeros((len(test), 4), dtype=np.float64)
    for fold, (fit_indices, valid_indices) in enumerate(folds):
        model = CatBoostClassifier(
            loss_function="MultiClass",
            random_seed=args.seed + fold,
            thread_count=4,
            verbose=False,
            allow_writing_files=False,
            cat_features=categorical_indices,
            **best_params,
        )
        model.fit(x.iloc[fit_indices], target[fit_indices])
        oof_probability[valid_indices] = model.predict_proba(
            x.iloc[valid_indices]
        )
        test_probability += (
            model.predict_proba(test_x) / len(folds)
        )
        print(json.dumps({"fold": fold}), flush=True)

    prediction = CLASSES[oof_probability.argmax(axis=1)]
    score = float(f1_score(target, prediction, average="macro"))
    prefix = "cat_tuned"
    np.save(OOF / f"{prefix}_oof.npy", oof_probability)
    np.save(OOF / f"{prefix}_test.npy", test_probability)
    report = {
        "family": "catboost",
        "search_best_score": best_score,
        "best_params": best_params,
        "trials": trials,
        "oof_macro_f1": score,
        "elapsed_seconds": time.monotonic() - started,
    }
    (LOGS / f"weather_{prefix}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
