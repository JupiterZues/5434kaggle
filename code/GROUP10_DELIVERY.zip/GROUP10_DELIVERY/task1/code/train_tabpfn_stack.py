"""Train a TabPFN-3.5 meta-classifier over OOF-safe base probabilities."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold
from tabpfn import TabPFNClassifier

from train_ensemble import NUMERIC
from train_tabpfn import add_custom_features


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
OOF = ROOT / "oof"
LOGS = ROOT / "logs"


def normalized_probability(name: str, split: str) -> np.ndarray:
    path = OOF / f"{name}_{split}.npy"
    if not path.exists():
        raise FileNotFoundError(path)
    value = np.clip(
        np.load(path).astype(np.float64), 1e-6, 1 - 1e-6
    )
    return value / value.sum(axis=1, keepdims=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base",
        action="append",
        required=True,
        help="Base OOF/test probability stream",
    )
    parser.add_argument(
        "--model-path",
        default="models/tabpfn35/tabpfn-v3.5-20260909_multiclass.safetensors",
    )
    parser.add_argument("--n-estimators", type=int, default=16)
    parser.add_argument("--folds", type=int, default=10)
    parser.add_argument("--seed", type=int, default=4100)
    parser.add_argument("--output-prefix", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("GPU is required.")
    torch.cuda.set_per_process_memory_fraction(0.45, 0)

    train = add_custom_features(pd.read_csv(INPUT / "train.csv"))
    test = add_custom_features(pd.read_csv(INPUT / "test.csv"))
    target = train["label"].to_numpy(dtype=int)
    numeric_features = [
        *NUMERIC,
        "temp_humidity",
        "precip_humidity",
        "wind_precip",
        "pressure_slope",
        "cloud_precip",
        "cloud_code",
        "visibility_humidity",
        "season_code",
        "location_code",
        "season_sin",
        "season_cos",
        "uv_visibility",
        "sun_index",
        "rain_index",
        "snow_index",
        "cloud_index",
        "wet_dry_ratio",
        "clear_ratio",
        "temperature_uv",
    ]
    train_features = train[numeric_features].copy()
    test_features = test[numeric_features].copy()
    for name in args.base:
        train_probability = normalized_probability(name, "oof")
        test_probability = normalized_probability(name, "test")
        train_features = pd.concat(
            [
                train_features,
                pd.DataFrame(
                    np.log(train_probability),
                    columns=[f"base_{name}_{i}" for i in range(4)],
                ),
            ],
            axis=1,
        )
        test_features = pd.concat(
            [
                test_features,
                pd.DataFrame(
                    np.log(test_probability),
                    columns=[f"base_{name}_{i}" for i in range(4)],
                ),
            ],
            axis=1,
        )

    folds = list(
        StratifiedKFold(
            n_splits=args.folds,
            shuffle=True,
            random_state=42,
        ).split(train_features, target)
    )
    oof_probability = np.zeros((len(train), 4), dtype=np.float64)
    test_probability = np.zeros((len(test), 4), dtype=np.float64)
    fold_scores = []
    started = time.monotonic()
    for fold, (fit_indices, valid_indices) in enumerate(folds):
        model = TabPFNClassifier(
            n_estimators=args.n_estimators,
            model_path=args.model_path,
            device="cuda",
            random_state=args.seed + fold,
            fit_mode="fit_preprocessors",
            memory_saving_mode="auto",
        )
        model.fit(
            train_features.iloc[fit_indices],
            target[fit_indices],
        )
        oof_probability[valid_indices] = model.predict_proba(
            train_features.iloc[valid_indices]
        )
        test_probability += model.predict_proba(test_features) / len(folds)
        score = f1_score(
            target[valid_indices],
            oof_probability[valid_indices].argmax(axis=1) + 1,
            average="macro",
        )
        fold_scores.append(float(score))
        print(json.dumps({"fold": fold, "macro_f1": score}), flush=True)

    np.save(OOF / f"{args.output_prefix}_oof.npy", oof_probability)
    np.save(OOF / f"{args.output_prefix}_test.npy", test_probability)
    report = {
        "status": "complete",
        "base_streams": args.base,
        "feature_count": train_features.shape[1],
        "n_estimators": args.n_estimators,
        "folds": args.folds,
        "seed": args.seed,
        "fold_scores": fold_scores,
        "fold_mean_macro_f1": float(np.mean(fold_scores)),
        "oof_macro_f1": float(
            f1_score(
                target,
                oof_probability.argmax(axis=1) + 1,
                average="macro",
            )
        ),
        "elapsed_seconds": time.monotonic() - started,
    }
    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
