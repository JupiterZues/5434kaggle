"""Train a compact feature-token transformer on Task 1 with shared GPU."""

from __future__ import annotations

import argparse
import copy
import json
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset

from train_ensemble import CATEGORICAL, NUMERIC, add_features


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
OOF = ROOT / "oof"
LOGS = ROOT / "logs"
CLASSES = np.array([1, 2, 3, 4])


class FeatureTokenizerTransformer(nn.Module):
    def __init__(
        self,
        numeric_count: int,
        category_sizes: list[int],
        width: int = 96,
        layers: int = 2,
        heads: int = 4,
    ) -> None:
        super().__init__()
        self.numeric_weights = nn.Parameter(
            torch.randn(numeric_count, width) * 0.02
        )
        self.numeric_bias = nn.Parameter(torch.zeros(numeric_count, width))
        self.category_embeddings = nn.ModuleList(
            [nn.Embedding(size, width) for size in category_sizes]
        )
        self.cls = nn.Parameter(torch.randn(1, 1, width) * 0.02)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=width,
            nhead=heads,
            dim_feedforward=width * 3,
            dropout=0.12,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=layers,
            enable_nested_tensor=False,
        )
        self.norm = nn.LayerNorm(width)
        self.head = nn.Linear(width, 4)

    def forward(
        self,
        numeric: torch.Tensor,
        categorical: torch.Tensor,
    ) -> torch.Tensor:
        numeric_tokens = (
            numeric.unsqueeze(-1) * self.numeric_weights.unsqueeze(0)
            + self.numeric_bias.unsqueeze(0)
        )
        category_tokens = torch.stack(
            [
                embedding(categorical[:, index])
                for index, embedding in enumerate(self.category_embeddings)
            ],
            dim=1,
        )
        tokens = torch.cat(
            [self.cls.expand(numeric.shape[0], -1, -1), numeric_tokens, category_tokens],
            dim=1,
        )
        encoded = self.encoder(tokens)
        return self.head(self.norm(encoded[:, 0]))


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--width", type=int, default=96)
    parser.add_argument("--layers", type=int, default=2)
    parser.add_argument("--heads", type=int, default=4)
    parser.add_argument("--epochs", type=int, default=35)
    parser.add_argument("--learning-rate", type=float, default=5e-4)
    parser.add_argument("--mixup-alpha", type=float, default=0.0)
    parser.add_argument("--seed-base", type=int, default=91)
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument("--output-prefix", default="ft_transformer")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("GPU is required for this experiment.")
    torch.set_num_threads(4)
    torch.cuda.set_per_process_memory_fraction(0.22, 0)
    device = torch.device("cuda")
    train = add_features(pd.read_csv(INPUT / "train.csv"))
    test = add_features(pd.read_csv(INPUT / "test.csv"))
    target = train["label"].to_numpy(dtype=int)
    numeric = list(NUMERIC)
    numeric.extend(
        [
            "temp_humidity",
            "precip_humidity",
            "wind_precip",
            "pressure_slope",
            "cloud_precip",
            "visibility_humidity",
            "season_sin",
            "season_cos",
        ]
    )
    category_maps: dict[str, dict[str, int]] = {}
    category_sizes: list[int] = []
    for column in CATEGORICAL:
        values = sorted(
            set(train[column].astype(str)) | set(test[column].astype(str))
        )
        category_maps[column] = {
            value: index for index, value in enumerate(values)
        }
        category_sizes.append(len(values))
    train_categorical = np.column_stack(
        [
            train[column].astype(str).map(category_maps[column]).to_numpy()
            for column in CATEGORICAL
        ]
    )
    test_categorical = np.column_stack(
        [
            test[column].astype(str).map(category_maps[column]).to_numpy()
            for column in CATEGORICAL
        ]
    )
    folds = list(
        StratifiedKFold(
            n_splits=10,
            shuffle=True,
            random_state=42,
        ).split(train, target)
    )
    seeds = [
        args.seed_base + index * 100 for index in range(args.seeds)
    ]
    oof_probability = np.zeros((len(train), 4), dtype=np.float64)
    test_probability = np.zeros((len(test), 4), dtype=np.float64)
    started = time.monotonic()
    for seed_index, seed in enumerate(seeds):
        for fold, (fit_indices, valid_indices) in enumerate(folds):
            set_seed(seed + fold)
            scaler = StandardScaler()
            fit_numeric = scaler.fit_transform(
                train.iloc[fit_indices][numeric]
            ).astype(np.float32)
            valid_numeric = scaler.transform(
                train.iloc[valid_indices][numeric]
            ).astype(np.float32)
            test_numeric = scaler.transform(test[numeric]).astype(np.float32)
            dataset = TensorDataset(
                torch.from_numpy(fit_numeric),
                torch.from_numpy(
                    train_categorical[fit_indices].astype(np.int64)
                ),
                torch.from_numpy(target[fit_indices] - 1),
            )
            loader = DataLoader(
                dataset,
                batch_size=192,
                shuffle=True,
                num_workers=0,
            )
            valid_numbers = torch.from_numpy(valid_numeric).to(device)
            valid_categories = torch.from_numpy(
                train_categorical[valid_indices].astype(np.int64)
            ).to(device)
            test_numbers = torch.from_numpy(test_numeric).to(device)
            test_categories = torch.from_numpy(
                test_categorical.astype(np.int64)
            ).to(device)
            model = FeatureTokenizerTransformer(
                len(numeric),
                category_sizes,
                width=args.width,
                layers=args.layers,
                heads=args.heads,
            ).to(device)
            optimizer = torch.optim.AdamW(
                model.parameters(),
                lr=args.learning_rate,
                weight_decay=2e-4,
            )
            epochs = args.epochs
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                optimizer, T_max=epochs
            )
            best_score = -1.0
            best_state = None
            for epoch in range(epochs):
                model.train()
                for batch_numeric, batch_categories, batch_target in loader:
                    batch_numeric = batch_numeric.to(
                        device, non_blocking=True
                    )
                    batch_categories = batch_categories.to(
                        device, non_blocking=True
                    )
                    batch_target = batch_target.to(
                        device, non_blocking=True
                    )
                    optimizer.zero_grad(set_to_none=True)
                    if args.mixup_alpha > 0.0:
                        mix = float(
                            np.random.beta(
                                args.mixup_alpha, args.mixup_alpha
                            )
                        )
                        permutation = torch.randperm(
                            batch_numeric.shape[0],
                            device=batch_numeric.device,
                        )
                        if mix >= 0.5:
                            batch_numeric_mixed = (
                                mix * batch_numeric
                                + (1.0 - mix)
                                * batch_numeric[permutation]
                            )
                            batch_categories_mixed = batch_categories
                        else:
                            batch_numeric_mixed = (
                                mix * batch_numeric[permutation]
                                + (1.0 - mix) * batch_numeric
                            )
                            batch_categories_mixed = batch_categories[
                                permutation
                            ]
                    else:
                        batch_numeric_mixed = batch_numeric
                        batch_categories_mixed = batch_categories
                    mixed_logits = model(
                        batch_numeric_mixed, batch_categories_mixed
                    )
                    loss = F.cross_entropy(mixed_logits, batch_target)
                    if args.mixup_alpha > 0.0:
                        loss = (
                            mix * loss
                            + (1.0 - mix)
                            * F.cross_entropy(
                                mixed_logits, batch_target[permutation]
                            )
                        )
                    loss.backward()
                    optimizer.step()
                scheduler.step()
                if epoch >= 12:
                    model.eval()
                    with torch.inference_mode():
                        valid_prediction = (
                            model(valid_numbers, valid_categories)
                            .argmax(dim=1)
                            .cpu()
                            .numpy()
                        )
                    score = f1_score(
                        target[valid_indices],
                        CLASSES[valid_prediction],
                        average="macro",
                    )
                    if score > best_score:
                        best_score = float(score)
                        best_state = copy.deepcopy(model.state_dict())
            if best_state is not None:
                model.load_state_dict(best_state)
            model.eval()
            with torch.inference_mode():
                valid_logits = model(valid_numbers, valid_categories)
                test_logits = model(test_numbers, test_categories)
            oof_probability[valid_indices] += (
                valid_logits.softmax(dim=1).cpu().numpy() / len(seeds)
            )
            test_probability += (
                test_logits.softmax(dim=1).cpu().numpy()
                / (len(seeds) * len(folds))
            )
            print(
                json.dumps(
                    {
                        "seed_index": seed_index,
                        "fold": fold,
                        "fold_macro_f1": best_score,
                    }
                ),
                flush=True,
            )
    prediction = CLASSES[oof_probability.argmax(axis=1)]
    score = float(f1_score(target, prediction, average="macro"))
    np.save(OOF / f"{args.output_prefix}_oof.npy", oof_probability)
    np.save(OOF / f"{args.output_prefix}_test.npy", test_probability)
    report = {
        "macro_f1": score,
        "elapsed_seconds": time.monotonic() - started,
    }
    (LOGS / f"{args.output_prefix}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
