"""Apply confidence-ordered swaps between two classes without changing quotas."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--anchor", required=True)
    parser.add_argument(
        "--signal",
        required=True,
        help="Test probability array with columns for source and destination class.",
    )
    parser.add_argument("--source-class", type=int, required=True)
    parser.add_argument("--destination-class", type=int, required=True)
    parser.add_argument("--swaps", type=int, required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    anchor = pd.read_csv(ROOT / args.anchor)
    sample = pd.read_csv(ROOT / "input/sample_submission.csv")
    if not np.array_equal(anchor["id"].to_numpy(), sample["id"].to_numpy()):
        raise RuntimeError("Anchor ID order does not match sample submission.")
    prediction = anchor["label"].to_numpy(dtype=int) - 1
    signal = np.load(ROOT / args.signal)
    if signal.ndim != 2 or signal.shape[1] != 2:
        raise RuntimeError("Signal must contain exactly two class columns.")
    log_signal = np.log(np.clip(signal, 1e-9, None))

    source = args.source_class - 1
    destination = args.destination_class - 1
    source_rows = np.flatnonzero(prediction == source)
    destination_rows = np.flatnonzero(prediction == destination)
    candidates = []
    for source_row in source_rows:
        gains = (
            log_signal[source_row, 1]
            - log_signal[source_row, 0]
            + log_signal[destination_rows, 0]
            - log_signal[destination_rows, 1]
        )
        for offset in np.flatnonzero(gains > 0):
            candidates.append(
                (
                    float(gains[offset]),
                    int(source_row),
                    int(destination_rows[offset]),
                )
            )
    candidates.sort(reverse=True)

    used_rows: set[int] = set()
    selected = []
    for gain, source_row, destination_row in candidates:
        if source_row in used_rows or destination_row in used_rows:
            continue
        prediction[source_row] = destination
        prediction[destination_row] = source
        used_rows.update((source_row, destination_row))
        selected.append(
            {
                "gain": gain,
                "source_row": source_row,
                "destination_row": destination_row,
            }
        )
        if len(selected) == args.swaps:
            break
    if len(selected) != args.swaps:
        raise RuntimeError(
            f"Only {len(selected)} non-overlapping positive swaps were found."
        )

    output_path = ROOT / args.output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(
        {"id": anchor["id"], "label": prediction + 1}
    ).to_csv(output_path, index=False)
    counts = (
        pd.Series(prediction + 1).value_counts().sort_index().to_dict()
    )
    if counts != {1: 825, 2: 825, 3: 825, 4: 825}:
        raise RuntimeError(f"Class counts changed unexpectedly: {counts}")
    report = {
        "anchor": args.anchor,
        "signal": args.signal,
        "source_class": args.source_class,
        "destination_class": args.destination_class,
        "swaps": selected,
        "changed_rows": 2 * len(selected),
        "class_counts": counts,
        "output": args.output,
        "sha256": hashlib.sha256(output_path.read_bytes()).hexdigest(),
    }
    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
