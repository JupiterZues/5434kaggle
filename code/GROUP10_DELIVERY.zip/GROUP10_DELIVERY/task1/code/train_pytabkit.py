"""Train official TabM or RealMLP streams with a fixed ten-fold split."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from pytabkit import (
    CatBoost_TD_Classifier,
    Ensemble_TD_Classifier,
    RealMLP_TD_Classifier,
    TabM_D_Classifier,
)
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold

from train_ensemble import CATEGORICAL, NUMERIC, add_features


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "family",
        choices=["tabm", "realmlp", "ensemble", "catboost"],
    )
    parser.add_argument(
        "--features", choices=["raw", "engineered"], default="raw"
    )
    parser.add_argument("--epochs", type=int, default=384)
    parser.add_argument("--n-ens", type=int, default=1)
    parser.add_argument("--time-to-fit", type=int, default=60)
    parser.add_argument("--seed", type=int, default=2250)
    parser.add_argument("--output-prefix", required=True)
    args = parser.parse_args()

    train = add_features(pd.read_csv(ROOT / "input/train.csv"))
    test = add_features(pd.read_csv(ROOT / "input/test.csv"))
    engineered = [
        "temp_humidity",
        "precip_humidity",
        "wind_precip",
        "pressure_slope",
        "cloud_precip",
        "cloud_code",
        "visibility_humidity",
        "season_code",
        "location_code",
        "season_sin",
        "season_cos",
    ]
    numeric = (
        [*NUMERIC, *engineered]
        if args.features == "engineered"
        else list(NUMERIC)
    )
    columns = [*numeric, *CATEGORICAL]
    x = train[columns]
    test_x = test[columns]
    target = train["label"].to_numpy(dtype=int)
    folds = list(
        StratifiedKFold(
            n_splits=10,
            shuffle=True,
            random_state=42,
        ).split(x, target)
    )
    oof_probability = np.zeros((len(train), 4), dtype=np.float64)
    test_probability = np.zeros((len(test), 4), dtype=np.float64)
    started = time.monotonic()
    for fold, (fit_indices, valid_indices) in enumerate(folds):
        common = {
            "device": "cuda",
            "random_state": args.seed + fold,
            "n_cv": 1,
            "n_refit": 0,
            "n_epochs": args.epochs,
            "batch_size": 256,
            "n_threads": 4,
            "val_metric_name": "cross_entropy",
            "verbosity": 0,
        }
        if args.family == "tabm":
            model = TabM_D_Classifier(**common)
        elif args.family == "realmlp":
            model = RealMLP_TD_Classifier(n_ens=args.n_ens, **common)
        elif args.family == "ensemble":
            model = Ensemble_TD_Classifier(
                device="cuda",
                random_state=args.seed + fold,
                n_cv=1,
                n_refit=0,
                n_threads=4,
                val_metric_name="cross_entropy",
                verbosity=0,
            )
        else:
            model = CatBoost_TD_Classifier(
                device="cpu",
                random_state=args.seed + fold,
                n_cv=1,
                n_refit=0,
                n_threads=4,
                val_metric_name="cross_entropy",
                verbosity=0,
            )
        fit_kwargs = {"cat_col_names": CATEGORICAL}
        if args.family == "ensemble":
            fit_kwargs["time_to_fit_in_seconds"] = args.time_to_fit
        model.fit(
            x.iloc[fit_indices],
            target[fit_indices],
            **fit_kwargs,
        )
        oof_probability[valid_indices] = model.predict_proba(
            x.iloc[valid_indices]
        )
        test_probability += model.predict_proba(test_x) / len(folds)
        print(json.dumps({"fold": fold}), flush=True)

    score = float(
        f1_score(
            target,
            oof_probability.argmax(axis=1) + 1,
            average="macro",
        )
    )
    np.save(
        ROOT / "oof" / f"{args.output_prefix}_oof.npy",
        oof_probability,
    )
    np.save(
        ROOT / "oof" / f"{args.output_prefix}_test.npy",
        test_probability,
    )
    report = {
        "family": args.family,
        "features": args.features,
        "epochs": args.epochs,
        "n_ens": args.n_ens,
        "macro_f1": score,
        "elapsed_seconds": time.monotonic() - started,
    }
    (ROOT / "logs" / f"weather_{args.output_prefix}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
