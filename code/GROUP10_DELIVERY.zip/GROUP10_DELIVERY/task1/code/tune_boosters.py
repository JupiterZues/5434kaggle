"""Randomized task-1 hyperparameter search followed by fixed-fold OOF training."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from scipy.stats import loguniform, randint, uniform
from sklearn.metrics import f1_score
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold
from xgboost import XGBClassifier

from train_ensemble import NUMERIC, add_features


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
OOF = ROOT / "oof"
LOGS = ROOT / "logs"
CLASSES = np.array([1, 2, 3, 4])


def feature_columns() -> list[str]:
    return [
        *NUMERIC,
        "temp_humidity",
        "precip_humidity",
        "wind_precip",
        "pressure_slope",
        "cloud_precip",
        "cloud_code",
        "visibility_humidity",
        "season_code",
        "location_code",
        "season_sin",
        "season_cos",
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--family", choices=["xgb", "lgbm"], required=True)
    parser.add_argument("--iterations", type=int, default=35)
    parser.add_argument("--seed", type=int, default=2027)
    args = parser.parse_args()

    train = add_features(pd.read_csv(INPUT / "train.csv"))
    test = add_features(pd.read_csv(INPUT / "test.csv"))
    target = train["label"].to_numpy(dtype=int)
    columns = feature_columns()
    x = train[columns]
    test_x = test[columns]
    search_cv = StratifiedKFold(
        n_splits=5, shuffle=True, random_state=73
    )
    if args.family == "xgb":
        estimator = XGBClassifier(
            objective="multi:softprob",
            num_class=4,
            tree_method="hist",
            eval_metric="mlogloss",
            random_state=args.seed,
            n_jobs=4,
        )
        parameters = {
            "n_estimators": randint(300, 1400),
            "learning_rate": loguniform(0.01, 0.08),
            "max_depth": randint(3, 10),
            "min_child_weight": loguniform(0.5, 20.0),
            "subsample": uniform(0.6, 0.4),
            "colsample_bytree": uniform(0.5, 0.5),
            "reg_lambda": loguniform(0.1, 20.0),
            "reg_alpha": loguniform(1e-3, 5.0),
            "gamma": uniform(0.0, 3.0),
        }
    else:
        estimator = LGBMClassifier(
            objective="multiclass",
            num_class=4,
            random_state=args.seed,
            n_jobs=4,
            verbosity=-1,
        )
        parameters = {
            "n_estimators": randint(300, 1400),
            "learning_rate": loguniform(0.01, 0.08),
            "num_leaves": randint(10, 80),
            "min_child_samples": randint(5, 80),
            "subsample": uniform(0.6, 0.4),
            "colsample_bytree": uniform(0.5, 0.5),
            "reg_lambda": loguniform(0.1, 30.0),
            "reg_alpha": loguniform(1e-3, 5.0),
        }
    search = RandomizedSearchCV(
        estimator,
        parameters,
        n_iter=args.iterations,
        cv=search_cv,
        scoring="f1_macro",
        random_state=args.seed,
        n_jobs=1,
        verbose=2,
    )
    started = time.monotonic()
    search_target = target - 1 if args.family == "xgb" else target
    search.fit(x, search_target)
    print(
        json.dumps(
            {
                "family": args.family,
                "best_score": search.best_score_,
                "best_params": search.best_params_,
            }
        ),
        flush=True,
    )

    folds = list(
        StratifiedKFold(
            n_splits=10, shuffle=True, random_state=42
        ).split(x, target)
    )
    oof_probability = np.zeros((len(train), 4), dtype=np.float64)
    test_probability = np.zeros((len(test), 4), dtype=np.float64)
    for fold, (fit_indices, valid_indices) in enumerate(folds):
        if args.family == "xgb":
            model = XGBClassifier(
                objective="multi:softprob",
                num_class=4,
                tree_method="hist",
                eval_metric="mlogloss",
                random_state=args.seed + fold,
                n_jobs=4,
                **search.best_params_,
            )
        else:
            model = LGBMClassifier(
                objective="multiclass",
                num_class=4,
                random_state=args.seed + fold,
                n_jobs=4,
                verbosity=-1,
                **search.best_params_,
            )
        fit_target = (
            target[fit_indices] - 1
            if args.family == "xgb"
            else target[fit_indices]
        )
        model.fit(x.iloc[fit_indices], fit_target)
        oof_probability[valid_indices] = model.predict_proba(
            x.iloc[valid_indices]
        )
        test_probability += model.predict_proba(test_x) / len(folds)
        print(json.dumps({"fold": fold}), flush=True)
    prediction = CLASSES[oof_probability.argmax(axis=1)]
    score = float(f1_score(target, prediction, average="macro"))
    name = f"{args.family}_tuned2"
    np.save(OOF / f"{name}_oof.npy", oof_probability)
    np.save(OOF / f"{name}_test.npy", test_probability)
    report = {
        "family": args.family,
        "search_best_score": float(search.best_score_),
        "best_params": search.best_params_,
        "oof_macro_f1": score,
        "elapsed_seconds": time.monotonic() - started,
    }
    (LOGS / f"weather_{name}.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
