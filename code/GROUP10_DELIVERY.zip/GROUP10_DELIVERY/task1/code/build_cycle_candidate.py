"""Rebuild the final four-row class-quota-preserving Task 1 candidate."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
CLASS_COUNTS = {1: 825, 2: 825, 3: 825, 4: 825}
CHANGES = {
    709: 3,
    1450: 4,
    292: 2,
    2631: 3,
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--anchor",
        default="submissions/weather_tabpfn_swap10_candidate.csv",
    )
    parser.add_argument(
        "--sample",
        default="input/sample_submission.csv",
    )
    parser.add_argument(
        "--output",
        default="submissions/weather_specialist_cycle4_candidate.csv",
    )
    parser.add_argument(
        "--report",
        default="logs/weather_specialist_cycle4_report.json",
    )
    args = parser.parse_args()

    anchor = pd.read_csv(ROOT / args.anchor)
    sample = pd.read_csv(ROOT / args.sample)
    if not np.array_equal(anchor["id"].to_numpy(), sample["id"].to_numpy()):
        raise RuntimeError("Anchor ID order does not match sample submission.")
    prediction = anchor.copy()
    for row, label in CHANGES.items():
        prediction.loc[row, "label"] = label
    counts = prediction["label"].value_counts().sort_index().to_dict()
    if counts != CLASS_COUNTS:
        raise RuntimeError(f"Class quota changed: {counts}")
    if prediction["id"].duplicated().any():
        raise RuntimeError("Final candidate contains duplicate ids.")

    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    prediction.to_csv(output, index=False)
    report = {
        "anchor": args.anchor,
        "changes": [
            {"row": row, "label": label}
            for row, label in CHANGES.items()
        ],
        "class_counts": counts,
        "output": args.output,
        "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    }
    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
