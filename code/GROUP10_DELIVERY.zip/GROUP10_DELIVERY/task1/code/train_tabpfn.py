"""Train a TabPFN v2 OOF stream for the small Task 1 dataset."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy.optimize import linear_sum_assignment
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold
from tabpfn import TabPFNClassifier

from train_ensemble import CATEGORICAL, NUMERIC, add_features


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
OOF = ROOT / "oof"
LOGS = ROOT / "logs"
CLASSES = np.array([1, 2, 3, 4])


def balanced_prediction(probability: np.ndarray, labels: np.ndarray) -> np.ndarray:
    counts = np.bincount(labels - 1, minlength=4)
    slots = np.repeat(np.arange(4), counts)
    cost = -np.log(np.clip(probability, 1e-9, None))[:, slots]
    rows, columns = linear_sum_assignment(cost)
    output = np.empty(len(probability), dtype=int)
    output[rows] = slots[columns]
    return CLASSES[output]


def add_custom_features(frame: pd.DataFrame) -> pd.DataFrame:
    """Add target-free weather-signature interactions.

    These features make the dominant wet/dry and warm/cold axes explicit
    without using any target information. They are intended as a diverse
    TabPFN view, not as a replacement for the raw/engineered streams.
    """
    output = add_features(frame)
    precipitation = output["Precipitation (%)"]
    humidity = output["Humidity"]
    visibility = output["Visibility (km)"]
    wind = output["Wind Speed"]
    cloud = output["cloud_code"]
    temperature = output["Temperature"]
    uv = output["UV Index"]

    output["uv_visibility"] = uv * visibility
    output["sun_index"] = (
        uv * visibility / (humidity.clip(lower=1) + precipitation.clip(lower=0) + 1)
    )
    output["rain_index"] = (
        precipitation * humidity * wind / (visibility.clip(lower=0) + 1)
    )
    output["snow_index"] = (
        (-temperature).clip(lower=0)
        * precipitation
        * humidity
        / (visibility.clip(lower=0) + 1)
    )
    output["cloud_index"] = (
        cloud * precipitation * humidity / (visibility.clip(lower=0) + 1)
    )
    output["wet_dry_ratio"] = humidity / (precipitation + 1)
    output["clear_ratio"] = visibility / (precipitation + 1)
    output["temperature_uv"] = temperature * uv
    return output


def add_clipped_features(frame: pd.DataFrame) -> pd.DataFrame:
    """Clip physically implausible values while retaining the row signal."""
    bounds = {
        "Temperature": (-20.0, 50.0),
        "Humidity": (0.0, 100.0),
        "Wind Speed": (0.0, 35.0),
        "Precipitation (%)": (0.0, 100.0),
        "Atmospheric Pressure": (970.0, 1060.0),
        "UV Index": (0.0, 11.0),
        "Visibility (km)": (0.0, 20.0),
    }
    clipped = frame.copy()
    for column, (lower, upper) in bounds.items():
        clipped[column] = clipped[column].clip(lower=lower, upper=upper)
    return add_features(clipped)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model-path",
        default="models/tabpfn/tabpfn-v2-classifier-finetuned-zk73skhh.ckpt",
    )
    parser.add_argument("--n-estimators", type=int, default=4)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--output-prefix", default="tabpfn")
    parser.add_argument("--report", default="logs/weather_tabpfn.json")
    parser.add_argument(
        "--feature-set",
        choices=[
            "raw",
            "engineered",
            "nopressure",
            "robust",
            "masked",
            "custom",
            "clip",
        ],
        default="raw",
    )
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("GPU is required.")
    torch.cuda.set_per_process_memory_fraction(0.45, 0)
    if args.feature_set == "custom":
        feature_builder = add_custom_features
    elif args.feature_set == "clip":
        feature_builder = add_clipped_features
    else:
        feature_builder = add_features
    train = feature_builder(pd.read_csv(INPUT / "train.csv"))
    test = feature_builder(pd.read_csv(INPUT / "test.csv"))
    target = train["label"].to_numpy(dtype=int)
    engineered = [
        "temp_humidity",
        "precip_humidity",
        "wind_precip",
        "pressure_slope",
        "cloud_precip",
        "cloud_code",
        "visibility_humidity",
        "season_code",
        "location_code",
        "season_sin",
        "season_cos",
    ]
    custom = [
        "uv_visibility",
        "sun_index",
        "rain_index",
        "snow_index",
        "cloud_index",
        "wet_dry_ratio",
        "clear_ratio",
        "temperature_uv",
    ]
    if args.feature_set in {"engineered", "custom", "clip"}:
        numeric_features = [*NUMERIC, *engineered]
        if args.feature_set == "custom":
            numeric_features.extend(custom)
    elif args.feature_set == "nopressure":
        numeric_features = [
            column
            for column in [*NUMERIC, *engineered]
            if column not in {"Atmospheric Pressure", "pressure_slope"}
        ]
    elif args.feature_set in {"robust", "masked"}:
        bounds = {
            "Temperature": (-20.0, 50.0),
            "Humidity": (0.0, 100.0),
            "Wind Speed": (0.0, 35.0),
            "Precipitation (%)": (0.0, 100.0),
            "Atmospheric Pressure": (970.0, 1060.0),
        }
        for frame in (train, test):
            for column, (lower, upper) in bounds.items():
                frame[f"{column}_outlier"] = (
                    (frame[column] < lower) | (frame[column] > upper)
                ).astype(np.int8)
                if args.feature_set == "masked":
                    frame.loc[
                        frame[f"{column}_outlier"].eq(1), column
                    ] = np.nan
            frame["outlier_count"] = sum(
                frame[f"{column}_outlier"] for column in bounds
            )
            if args.feature_set == "masked":
                frame.loc[
                    frame[["Temperature", "Humidity"]]
                    .isna()
                    .any(axis=1),
                    "temp_humidity",
                ] = np.nan
                frame.loc[
                    frame[["Precipitation (%)", "Humidity"]]
                    .isna()
                    .any(axis=1),
                    "precip_humidity",
                ] = np.nan
                frame.loc[
                    frame[["Wind Speed", "Precipitation (%)"]]
                    .isna()
                    .any(axis=1),
                    "wind_precip",
                ] = np.nan
                frame.loc[
                    frame["Atmospheric Pressure"].isna(),
                    "pressure_slope",
                ] = np.nan
        numeric_features = [
            *NUMERIC,
            *engineered,
            *[f"{column}_outlier" for column in bounds],
            "outlier_count",
        ]
    else:
        numeric_features = list(NUMERIC)
    features = [*numeric_features, *CATEGORICAL]
    train_x = train[features].copy()
    test_x = test[features].copy()
    for column in CATEGORICAL:
        categories = pd.Categorical(
            pd.concat([train_x[column], test_x[column]], ignore_index=True)
        ).categories
        train_x[column] = pd.Categorical(
            train_x[column], categories=categories
        ).codes
        test_x[column] = pd.Categorical(
            test_x[column], categories=categories
        ).codes
    categorical_indices = list(
        range(
            len(numeric_features),
            len(numeric_features) + len(CATEGORICAL),
        )
    )
    folds = list(
        StratifiedKFold(
            n_splits=args.folds,
            shuffle=True,
            random_state=42,
        ).split(train_x, target)
    )
    oof_probability = np.zeros((len(train), 4), dtype=np.float64)
    test_probability = np.zeros((len(test), 4), dtype=np.float64)
    fold_scores = []
    started = time.monotonic()
    for fold, (fit_indices, valid_indices) in enumerate(folds):
        model = TabPFNClassifier(
            n_estimators=args.n_estimators,
            categorical_features_indices=categorical_indices,
            model_path=args.model_path,
            device="cuda",
            random_state=args.seed + fold,
            n_jobs=4,
            fit_mode="fit_preprocessors",
            memory_saving_mode="auto",
        )
        model.fit(
            train_x.iloc[fit_indices],
            target[fit_indices],
        )
        valid_probability = model.predict_proba(train_x.iloc[valid_indices])
        oof_probability[valid_indices] = valid_probability
        test_probability += model.predict_proba(test_x) / len(folds)
        score = f1_score(
            target[valid_indices],
            CLASSES[valid_probability.argmax(axis=1)],
            average="macro",
        )
        balanced_score = f1_score(
            target[valid_indices],
            balanced_prediction(
                valid_probability, target[valid_indices]
            ),
            average="macro",
        )
        fold_scores.append(
            {
                "fold": fold,
                "macro_f1": float(score),
                "balanced_macro_f1": float(balanced_score),
            }
        )
        print(json.dumps(fold_scores[-1]), flush=True)

    argmax_prediction = CLASSES[oof_probability.argmax(axis=1)]
    oof_score = float(
        f1_score(target, argmax_prediction, average="macro")
    )
    np.save(OOF / f"{args.output_prefix}_oof.npy", oof_probability)
    np.save(OOF / f"{args.output_prefix}_test.npy", test_probability)
    report = {
        "status": "complete",
        "feature_set": args.feature_set,
        "feature_count": len(features),
        "n_estimators": args.n_estimators,
        "folds": fold_scores,
        "oof_macro_f1": oof_score,
        "fold_mean_macro_f1": float(
            np.mean([row["macro_f1"] for row in fold_scores])
        ),
        "fold_mean_balanced_macro_f1": float(
            np.mean(
                [row["balanced_macro_f1"] for row in fold_scores]
            )
        ),
        "elapsed_seconds": time.monotonic() - started,
    }
    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
