"""Train variance-reduced seed bags for Task 1."""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold

from train_ensemble import NUMERIC, add_features


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
OOF = ROOT / "oof"
LOGS = ROOT / "logs"
CLASSES = np.array([1, 2, 3, 4])


def main() -> None:
    train = add_features(pd.read_csv(INPUT / "train.csv"))
    test = add_features(pd.read_csv(INPUT / "test.csv"))
    target = train["label"].to_numpy(dtype=int)
    numeric = list(NUMERIC)
    numeric.extend(
        [
            "temp_humidity",
            "precip_humidity",
            "wind_precip",
            "pressure_slope",
            "cloud_precip",
            "cloud_code",
            "visibility_humidity",
            "season_code",
            "location_code",
            "season_sin",
            "season_cos",
        ]
    )
    folds = list(
        StratifiedKFold(
            n_splits=10,
            shuffle=True,
            random_state=42,
        ).split(train, target)
    )
    report: dict[str, object] = {"models": {}}
    for family in ("extra", "rf"):
        started = time.monotonic()
        oof_probability = np.zeros((len(train), 4), dtype=np.float64)
        test_probability = np.zeros((len(test), 4), dtype=np.float64)
        seeds = [42, 142, 242]
        for seed_index, seed in enumerate(seeds):
            for fold, (fit_indices, valid_indices) in enumerate(folds):
                if family == "extra":
                    model = ExtraTreesClassifier(
                        n_estimators=1000,
                        max_features="sqrt",
                        min_samples_leaf=1,
                        random_state=seed + fold,
                        n_jobs=4,
                    )
                else:
                    model = RandomForestClassifier(
                        n_estimators=1000,
                        max_features="sqrt",
                        min_samples_leaf=1,
                        random_state=seed + fold,
                        n_jobs=4,
                    )
                model.fit(
                    train.iloc[fit_indices][numeric],
                    target[fit_indices],
                )
                oof_probability[valid_indices] += model.predict_proba(
                    train.iloc[valid_indices][numeric]
                ) / len(seeds)
                test_probability += model.predict_proba(
                    test[numeric]
                ) / (len(seeds) * len(folds))
                print(
                    json.dumps(
                        {
                            "family": family,
                            "seed_index": seed_index,
                            "fold": fold,
                        }
                    ),
                    flush=True,
                )
        model_name = f"{family}_seedbag3"
        np.save(OOF / f"{model_name}_oof.npy", oof_probability)
        np.save(OOF / f"{model_name}_test.npy", test_probability)
        prediction = CLASSES[oof_probability.argmax(axis=1)]
        score = float(f1_score(target, prediction, average="macro"))
        report["models"][model_name] = {
            "macro_f1": score,
            "elapsed_seconds": time.monotonic() - started,
        }
        print(json.dumps({"model": model_name, "macro_f1": score}), flush=True)
    (LOGS / "weather_seed_bags.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
