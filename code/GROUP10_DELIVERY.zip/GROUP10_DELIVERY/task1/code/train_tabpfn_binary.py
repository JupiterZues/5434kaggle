"""Train a binary TabPFN-3.5 specialist for a selected class pair."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from tabpfn import TabPFNClassifier

from train_ensemble import CATEGORICAL, NUMERIC, add_features
from train_tabpfn import add_custom_features


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "input"
OOF = ROOT / "oof"
LOGS = ROOT / "logs"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pair", help="Two class ids, e.g. 23")
    parser.add_argument("--one-vs-rest", action="store_true")
    parser.add_argument("--positive-class", type=int, default=2)
    parser.add_argument(
        "--model-path",
        default="models/tabpfn35/tabpfn-v3.5-20260909_multiclass.safetensors",
    )
    parser.add_argument("--n-estimators", type=int, default=16)
    parser.add_argument("--folds", type=int, default=10)
    parser.add_argument("--seed", type=int, default=3100)
    parser.add_argument("--feature-set", choices=["engineered", "custom"], default="engineered")
    parser.add_argument("--output-prefix", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()

    if not args.one_vs_rest:
        if not args.pair or len(args.pair) != 2 or args.pair[0] == args.pair[1]:
            raise ValueError("--pair must contain two distinct class ids")
        pair_classes = np.array([int(args.pair[0]), int(args.pair[1])])
    if not torch.cuda.is_available():
        raise RuntimeError("GPU is required.")
    torch.cuda.set_per_process_memory_fraction(0.45, 0)

    feature_builder = (
        add_custom_features if args.feature_set == "custom" else add_features
    )
    train = feature_builder(pd.read_csv(INPUT / "train.csv"))
    test = feature_builder(pd.read_csv(INPUT / "test.csv"))
    target = train["label"].to_numpy(dtype=int)
    if args.one_vs_rest:
        if args.positive_class not in (1, 2, 3, 4):
            raise ValueError("--positive-class must be in [1, 4]")
        mask = np.ones(len(target), dtype=bool)
        pair_classes = np.array([-1, args.positive_class])
        pair_y = (target == args.positive_class).astype(int)
    else:
        mask = np.isin(target, pair_classes)
        pair_y = (target[mask] == pair_classes[1]).astype(int)

    engineered = [
        "temp_humidity",
        "precip_humidity",
        "wind_precip",
        "pressure_slope",
        "cloud_precip",
        "cloud_code",
        "visibility_humidity",
        "season_code",
        "location_code",
        "season_sin",
        "season_cos",
    ]
    custom = [
        "uv_visibility",
        "sun_index",
        "rain_index",
        "snow_index",
        "cloud_index",
        "wet_dry_ratio",
        "clear_ratio",
        "temperature_uv",
    ]
    numeric_features = [*NUMERIC, *engineered]
    if args.feature_set == "custom":
        numeric_features.extend(custom)
    features = [*numeric_features, *CATEGORICAL]
    train_x = train.loc[mask, features].copy()
    test_x = test[features].copy()
    for column in CATEGORICAL:
        categories = pd.Categorical(
            pd.concat([train_x[column], test_x[column]], ignore_index=True)
        ).categories
        train_x[column] = pd.Categorical(
            train_x[column], categories=categories
        ).codes
        test_x[column] = pd.Categorical(
            test_x[column], categories=categories
        ).codes
    categorical_indices = list(
        range(len(numeric_features), len(numeric_features) + len(CATEGORICAL))
    )
    folds = list(
        StratifiedKFold(
            n_splits=args.folds,
            shuffle=True,
            random_state=42,
        ).split(train_x, pair_y)
    )
    oof_pair = np.full((len(train_x), 2), np.nan, dtype=np.float64)
    oof = np.full((len(train), 2), np.nan, dtype=np.float64)
    test_probability = np.zeros((len(test), 2), dtype=np.float64)
    aucs = []
    started = time.monotonic()
    for fold, (fit_indices, valid_indices) in enumerate(folds):
        model = TabPFNClassifier(
            n_estimators=args.n_estimators,
            categorical_features_indices=categorical_indices,
            model_path=args.model_path,
            device="cuda",
            random_state=args.seed + fold,
            fit_mode="fit_preprocessors",
            memory_saving_mode="auto",
        )
        model.fit(train_x.iloc[fit_indices], pair_y[fit_indices])
        oof_pair[valid_indices] = model.predict_proba(
            train_x.iloc[valid_indices]
        )
        test_probability += model.predict_proba(test_x) / len(folds)
        auc = roc_auc_score(pair_y[valid_indices], oof_pair[valid_indices, 1])
        aucs.append(float(auc))
        print(json.dumps({"fold": fold, "auc": auc}), flush=True)

    oof[mask] = oof_pair
    np.save(OOF / f"{args.output_prefix}_oof.npy", oof)
    np.save(OOF / f"{args.output_prefix}_test.npy", test_probability)
    report = {
        "status": "complete",
        "pair": pair_classes.tolist(),
        "n_estimators": args.n_estimators,
        "folds": args.folds,
        "seed": args.seed,
        "feature_set": args.feature_set,
        "pair_rows": int(mask.sum()),
        "fold_auc": aucs,
        "mean_auc": float(np.mean(aucs)),
        "elapsed_seconds": time.monotonic() - started,
    }
    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
